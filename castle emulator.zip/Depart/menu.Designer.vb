﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormMenu
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormMenu))
        Me.ButtonResetO = New System.Windows.Forms.Button()
        Me.ButtonBack = New System.Windows.Forms.Button()
        Me.TextBoxMenuOr = New System.Windows.Forms.TextBox()
        Me.MenuStripFile = New System.Windows.Forms.MenuStrip()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ContactToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LogOutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitControlerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PictureBoxBr = New System.Windows.Forms.PictureBox()
        Me.PictureBoxLu = New System.Windows.Forms.PictureBox()
        Me.ButtonSO = New System.Windows.Forms.Button()
        Me.MenuStripFile.SuspendLayout()
        CType(Me.PictureBoxBr, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxLu, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ButtonResetO
        '
        Me.ButtonResetO.BackColor = System.Drawing.Color.Transparent
        Me.ButtonResetO.Location = New System.Drawing.Point(382, 419)
        Me.ButtonResetO.Name = "ButtonResetO"
        Me.ButtonResetO.Size = New System.Drawing.Size(74, 20)
        Me.ButtonResetO.TabIndex = 172
        Me.ButtonResetO.Tag = ""
        Me.ButtonResetO.Text = "Reset Order"
        Me.ButtonResetO.UseVisualStyleBackColor = False
        '
        'ButtonBack
        '
        Me.ButtonBack.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.ButtonBack.Location = New System.Drawing.Point(462, 420)
        Me.ButtonBack.Name = "ButtonBack"
        Me.ButtonBack.Size = New System.Drawing.Size(110, 25)
        Me.ButtonBack.TabIndex = 171
        Me.ButtonBack.Text = "Back"
        Me.ButtonBack.UseVisualStyleBackColor = True
        '
        'TextBoxMenuOr
        '
        Me.TextBoxMenuOr.BackColor = System.Drawing.Color.Silver
        Me.TextBoxMenuOr.Location = New System.Drawing.Point(27, 420)
        Me.TextBoxMenuOr.Multiline = True
        Me.TextBoxMenuOr.Name = "TextBoxMenuOr"
        Me.TextBoxMenuOr.Size = New System.Drawing.Size(272, 20)
        Me.TextBoxMenuOr.TabIndex = 170
        '
        'MenuStripFile
        '
        Me.MenuStripFile.BackColor = System.Drawing.Color.Transparent
        Me.MenuStripFile.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.MenuStripFile.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem1})
        Me.MenuStripFile.Location = New System.Drawing.Point(0, 0)
        Me.MenuStripFile.Name = "MenuStripFile"
        Me.MenuStripFile.ShowItemToolTips = True
        Me.MenuStripFile.Size = New System.Drawing.Size(584, 24)
        Me.MenuStripFile.TabIndex = 215
        Me.MenuStripFile.Text = "MenuStrip1"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ContactToolStripMenuItem, Me.HelpToolStripMenuItem, Me.AboutToolStripMenuItem, Me.LogOutToolStripMenuItem, Me.ExitControlerToolStripMenuItem})
        Me.ToolStripMenuItem1.ForeColor = System.Drawing.Color.Coral
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(37, 20)
        Me.ToolStripMenuItem1.Text = "File"
        '
        'ContactToolStripMenuItem
        '
        Me.ContactToolStripMenuItem.Name = "ContactToolStripMenuItem"
        Me.ContactToolStripMenuItem.Size = New System.Drawing.Size(145, 22)
        Me.ContactToolStripMenuItem.Text = "Contact"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(145, 22)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(145, 22)
        Me.AboutToolStripMenuItem.Text = "About"
        '
        'LogOutToolStripMenuItem
        '
        Me.LogOutToolStripMenuItem.Name = "LogOutToolStripMenuItem"
        Me.LogOutToolStripMenuItem.Size = New System.Drawing.Size(145, 22)
        Me.LogOutToolStripMenuItem.Text = "Log Out"
        '
        'ExitControlerToolStripMenuItem
        '
        Me.ExitControlerToolStripMenuItem.Name = "ExitControlerToolStripMenuItem"
        Me.ExitControlerToolStripMenuItem.Size = New System.Drawing.Size(145, 22)
        Me.ExitControlerToolStripMenuItem.Text = "Exit Controler"
        '
        'PictureBoxBr
        '
        Me.PictureBoxBr.BackgroundImage = CType(resources.GetObject("PictureBoxBr.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxBr.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxBr.Location = New System.Drawing.Point(0, 0)
        Me.PictureBoxBr.Name = "PictureBoxBr"
        Me.PictureBoxBr.Size = New System.Drawing.Size(584, 451)
        Me.PictureBoxBr.TabIndex = 216
        Me.PictureBoxBr.TabStop = False
        '
        'PictureBoxLu
        '
        Me.PictureBoxLu.BackgroundImage = CType(resources.GetObject("PictureBoxLu.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxLu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxLu.Location = New System.Drawing.Point(0, 0)
        Me.PictureBoxLu.Name = "PictureBoxLu"
        Me.PictureBoxLu.Size = New System.Drawing.Size(584, 451)
        Me.PictureBoxLu.TabIndex = 217
        Me.PictureBoxLu.TabStop = False
        '
        'ButtonSO
        '
        Me.ButtonSO.BackColor = System.Drawing.Color.Transparent
        Me.ButtonSO.Location = New System.Drawing.Point(305, 419)
        Me.ButtonSO.Name = "ButtonSO"
        Me.ButtonSO.Size = New System.Drawing.Size(74, 20)
        Me.ButtonSO.TabIndex = 218
        Me.ButtonSO.Tag = ""
        Me.ButtonSO.Text = "Send Order"
        Me.ButtonSO.UseVisualStyleBackColor = False
        '
        'FormMenu
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(584, 452)
        Me.Controls.Add(Me.ButtonSO)
        Me.Controls.Add(Me.ButtonResetO)
        Me.Controls.Add(Me.ButtonBack)
        Me.Controls.Add(Me.TextBoxMenuOr)
        Me.Controls.Add(Me.MenuStripFile)
        Me.Controls.Add(Me.PictureBoxBr)
        Me.Controls.Add(Me.PictureBoxLu)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "FormMenu"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Menu"
        Me.MenuStripFile.ResumeLayout(False)
        Me.MenuStripFile.PerformLayout()
        CType(Me.PictureBoxBr, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxLu, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ButtonResetO As System.Windows.Forms.Button
    Friend WithEvents ButtonBack As System.Windows.Forms.Button
    Friend WithEvents TextBoxMenuOr As System.Windows.Forms.TextBox
    Friend WithEvents MenuStripFile As System.Windows.Forms.MenuStrip
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ContactToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LogOutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitControlerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PictureBoxBr As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBoxLu As System.Windows.Forms.PictureBox
    Friend WithEvents ButtonSO As System.Windows.Forms.Button
End Class
