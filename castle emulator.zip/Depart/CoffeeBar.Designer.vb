﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormCoffeeBar
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormCoffeeBar))
        Me.LinkLabelBe = New System.Windows.Forms.LinkLabel()
        Me.LinkLabelCoc = New System.Windows.Forms.LinkLabel()
        Me.LinkLabelSp = New System.Windows.Forms.LinkLabel()
        Me.LinkLabelCof = New System.Windows.Forms.LinkLabel()
        Me.ButtonBackCBCust = New System.Windows.Forms.Button()
        Me.LinkLabelPa = New System.Windows.Forms.LinkLabel()
        Me.LinkLabelSna = New System.Windows.Forms.LinkLabel()
        Me.DomainUpDownSlcb = New System.Windows.Forms.DomainUpDown()
        Me.DomainUpDownMlcb = New System.Windows.Forms.DomainUpDown()
        Me.NumericUpDownaircb = New System.Windows.Forms.NumericUpDown()
        Me.LabelTempAcb = New System.Windows.Forms.Label()
        Me.LinkLabelAircb = New System.Windows.Forms.LinkLabel()
        Me.LinkLabelSeclicb = New System.Windows.Forms.LinkLabel()
        Me.LinkLabelMainLightscb = New System.Windows.Forms.LinkLabel()
        Me.MenuStripFile = New System.Windows.Forms.MenuStrip()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ContactToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LogOutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitControlerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DomainUpDownSScb = New System.Windows.Forms.DomainUpDown()
        Me.LinkLabelSScb = New System.Windows.Forms.LinkLabel()
        Me.DomainUpDownTVcb = New System.Windows.Forms.DomainUpDown()
        Me.LinkLabelTVcb = New System.Windows.Forms.LinkLabel()
        Me.ButtonBackCBStaf = New System.Windows.Forms.Button()
        Me.DomainUpDownPa = New System.Windows.Forms.DomainUpDown()
        Me.TextBoxPa = New System.Windows.Forms.TextBox()
        Me.ButtonPas = New System.Windows.Forms.Button()
        Me.HelpProvider1 = New System.Windows.Forms.HelpProvider()
        Me.PictureBoxTVcb = New System.Windows.Forms.PictureBox()
        Me.PictureBoxSScb = New System.Windows.Forms.PictureBox()
        Me.PictureBoxAircb = New System.Windows.Forms.PictureBox()
        Me.PictureBoxMainLightscb = New System.Windows.Forms.PictureBox()
        Me.PictureBoxSeclicb = New System.Windows.Forms.PictureBox()
        Me.PictureBoxPa = New System.Windows.Forms.PictureBox()
        Me.PictureBoxCof = New System.Windows.Forms.PictureBox()
        Me.PictureBoxSp = New System.Windows.Forms.PictureBox()
        Me.PictureBoxCoc = New System.Windows.Forms.PictureBox()
        Me.PictureBoxBe = New System.Windows.Forms.PictureBox()
        Me.PictureBoxSna = New System.Windows.Forms.PictureBox()
        CType(Me.NumericUpDownaircb, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStripFile.SuspendLayout()
        CType(Me.PictureBoxTVcb, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxSScb, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxAircb, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxMainLightscb, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxSeclicb, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxPa, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxCof, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxSp, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxCoc, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxBe, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxSna, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'LinkLabelBe
        '
        Me.LinkLabelBe.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelBe.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelBe.LinkColor = System.Drawing.Color.White
        Me.LinkLabelBe.Location = New System.Drawing.Point(349, 82)
        Me.LinkLabelBe.Name = "LinkLabelBe"
        Me.LinkLabelBe.Size = New System.Drawing.Size(105, 115)
        Me.LinkLabelBe.TabIndex = 161
        Me.LinkLabelBe.TabStop = True
        Me.LinkLabelBe.Text = "Beers"
        Me.LinkLabelBe.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'LinkLabelCoc
        '
        Me.LinkLabelCoc.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelCoc.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelCoc.LinkColor = System.Drawing.Color.Blue
        Me.LinkLabelCoc.Location = New System.Drawing.Point(142, 197)
        Me.LinkLabelCoc.Name = "LinkLabelCoc"
        Me.LinkLabelCoc.Size = New System.Drawing.Size(94, 90)
        Me.LinkLabelCoc.TabIndex = 160
        Me.LinkLabelCoc.TabStop = True
        Me.LinkLabelCoc.Text = "Cocktails"
        Me.LinkLabelCoc.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LinkLabelSp
        '
        Me.LinkLabelSp.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelSp.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelSp.LinkColor = System.Drawing.Color.White
        Me.LinkLabelSp.Location = New System.Drawing.Point(71, 68)
        Me.LinkLabelSp.Name = "LinkLabelSp"
        Me.LinkLabelSp.Size = New System.Drawing.Size(106, 85)
        Me.LinkLabelSp.TabIndex = 164
        Me.LinkLabelSp.TabStop = True
        Me.LinkLabelSp.Text = "Spirits"
        Me.LinkLabelSp.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'LinkLabelCof
        '
        Me.LinkLabelCof.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelCof.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelCof.LinkColor = System.Drawing.Color.White
        Me.LinkLabelCof.Location = New System.Drawing.Point(185, 68)
        Me.LinkLabelCof.Name = "LinkLabelCof"
        Me.LinkLabelCof.Size = New System.Drawing.Size(156, 121)
        Me.LinkLabelCof.TabIndex = 166
        Me.LinkLabelCof.TabStop = True
        Me.LinkLabelCof.Text = "Coffee"
        Me.LinkLabelCof.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'ButtonBackCBCust
        '
        Me.ButtonBackCBCust.Location = New System.Drawing.Point(462, 415)
        Me.ButtonBackCBCust.Name = "ButtonBackCBCust"
        Me.ButtonBackCBCust.Size = New System.Drawing.Size(110, 25)
        Me.ButtonBackCBCust.TabIndex = 167
        Me.ButtonBackCBCust.Text = "Back"
        Me.ButtonBackCBCust.UseVisualStyleBackColor = True
        '
        'LinkLabelPa
        '
        Me.LinkLabelPa.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelPa.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelPa.LinkColor = System.Drawing.Color.White
        Me.LinkLabelPa.Location = New System.Drawing.Point(416, 302)
        Me.LinkLabelPa.Name = "LinkLabelPa"
        Me.LinkLabelPa.Size = New System.Drawing.Size(156, 93)
        Me.LinkLabelPa.TabIndex = 169
        Me.LinkLabelPa.TabStop = True
        Me.LinkLabelPa.Text = "Pay"
        Me.LinkLabelPa.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        '
        'LinkLabelSna
        '
        Me.LinkLabelSna.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelSna.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelSna.LinkColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.LinkLabelSna.Location = New System.Drawing.Point(267, 195)
        Me.LinkLabelSna.Name = "LinkLabelSna"
        Me.LinkLabelSna.Size = New System.Drawing.Size(131, 90)
        Me.LinkLabelSna.TabIndex = 171
        Me.LinkLabelSna.TabStop = True
        Me.LinkLabelSna.Text = "Snacks"
        Me.LinkLabelSna.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'DomainUpDownSlcb
        '
        Me.DomainUpDownSlcb.Items.Add("Off")
        Me.DomainUpDownSlcb.Items.Add("On")
        Me.DomainUpDownSlcb.Location = New System.Drawing.Point(12, 168)
        Me.DomainUpDownSlcb.Name = "DomainUpDownSlcb"
        Me.DomainUpDownSlcb.ReadOnly = True
        Me.DomainUpDownSlcb.Size = New System.Drawing.Size(61, 20)
        Me.DomainUpDownSlcb.TabIndex = 172
        Me.DomainUpDownSlcb.Text = "ON/OFF"
        '
        'DomainUpDownMlcb
        '
        Me.DomainUpDownMlcb.Items.Add("Off")
        Me.DomainUpDownMlcb.Items.Add("On")
        Me.DomainUpDownMlcb.Location = New System.Drawing.Point(324, 8)
        Me.DomainUpDownMlcb.Name = "DomainUpDownMlcb"
        Me.DomainUpDownMlcb.ReadOnly = True
        Me.DomainUpDownMlcb.Size = New System.Drawing.Size(65, 20)
        Me.DomainUpDownMlcb.TabIndex = 173
        Me.DomainUpDownMlcb.Text = "ON/OFF"
        '
        'NumericUpDownaircb
        '
        Me.NumericUpDownaircb.Location = New System.Drawing.Point(74, 25)
        Me.NumericUpDownaircb.Maximum = New Decimal(New Integer() {28, 0, 0, 0})
        Me.NumericUpDownaircb.Minimum = New Decimal(New Integer() {16, 0, 0, 0})
        Me.NumericUpDownaircb.Name = "NumericUpDownaircb"
        Me.NumericUpDownaircb.ReadOnly = True
        Me.NumericUpDownaircb.Size = New System.Drawing.Size(67, 20)
        Me.NumericUpDownaircb.TabIndex = 180
        Me.NumericUpDownaircb.Value = New Decimal(New Integer() {16, 0, 0, 0})
        '
        'LabelTempAcb
        '
        Me.LabelTempAcb.AutoSize = True
        Me.LabelTempAcb.Location = New System.Drawing.Point(71, 10)
        Me.LabelTempAcb.Name = "LabelTempAcb"
        Me.LabelTempAcb.Size = New System.Drawing.Size(48, 13)
        Me.LabelTempAcb.TabIndex = 181
        Me.LabelTempAcb.Text = "Temp °C"
        '
        'LinkLabelAircb
        '
        Me.LinkLabelAircb.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelAircb.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelAircb.LinkColor = System.Drawing.Color.White
        Me.LinkLabelAircb.Location = New System.Drawing.Point(142, 16)
        Me.LinkLabelAircb.Name = "LinkLabelAircb"
        Me.LinkLabelAircb.Size = New System.Drawing.Size(122, 52)
        Me.LinkLabelAircb.TabIndex = 179
        Me.LinkLabelAircb.TabStop = True
        Me.LinkLabelAircb.Text = "Air"
        Me.LinkLabelAircb.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LinkLabelSeclicb
        '
        Me.LinkLabelSeclicb.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelSeclicb.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelSeclicb.LinkColor = System.Drawing.Color.White
        Me.LinkLabelSeclicb.Location = New System.Drawing.Point(6, 48)
        Me.LinkLabelSeclicb.Name = "LinkLabelSeclicb"
        Me.LinkLabelSeclicb.Size = New System.Drawing.Size(63, 119)
        Me.LinkLabelSeclicb.TabIndex = 176
        Me.LinkLabelSeclicb.TabStop = True
        Me.LinkLabelSeclicb.Text = "Sec Lights"
        Me.LinkLabelSeclicb.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'LinkLabelMainLightscb
        '
        Me.LinkLabelMainLightscb.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelMainLightscb.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelMainLightscb.LinkColor = System.Drawing.Color.Yellow
        Me.LinkLabelMainLightscb.Location = New System.Drawing.Point(385, 2)
        Me.LinkLabelMainLightscb.Name = "LinkLabelMainLightscb"
        Me.LinkLabelMainLightscb.Size = New System.Drawing.Size(199, 80)
        Me.LinkLabelMainLightscb.TabIndex = 175
        Me.LinkLabelMainLightscb.TabStop = True
        Me.LinkLabelMainLightscb.Text = "Main Lights"
        Me.LinkLabelMainLightscb.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'MenuStripFile
        '
        Me.MenuStripFile.BackColor = System.Drawing.Color.Transparent
        Me.MenuStripFile.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.MenuStripFile.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem1})
        Me.MenuStripFile.Location = New System.Drawing.Point(0, 0)
        Me.MenuStripFile.Name = "MenuStripFile"
        Me.MenuStripFile.ShowItemToolTips = True
        Me.MenuStripFile.Size = New System.Drawing.Size(584, 24)
        Me.MenuStripFile.TabIndex = 183
        Me.MenuStripFile.Text = "MenuStrip1"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ContactToolStripMenuItem, Me.HelpToolStripMenuItem, Me.AboutToolStripMenuItem, Me.LogOutToolStripMenuItem, Me.ExitControlerToolStripMenuItem})
        Me.ToolStripMenuItem1.ForeColor = System.Drawing.Color.Coral
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(37, 20)
        Me.ToolStripMenuItem1.Text = "File"
        '
        'ContactToolStripMenuItem
        '
        Me.ContactToolStripMenuItem.Name = "ContactToolStripMenuItem"
        Me.ContactToolStripMenuItem.Size = New System.Drawing.Size(145, 22)
        Me.ContactToolStripMenuItem.Text = "Contact"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(145, 22)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(145, 22)
        Me.AboutToolStripMenuItem.Text = "About"
        '
        'LogOutToolStripMenuItem
        '
        Me.LogOutToolStripMenuItem.Name = "LogOutToolStripMenuItem"
        Me.LogOutToolStripMenuItem.Size = New System.Drawing.Size(145, 22)
        Me.LogOutToolStripMenuItem.Text = "Log Out"
        '
        'ExitControlerToolStripMenuItem
        '
        Me.ExitControlerToolStripMenuItem.Name = "ExitControlerToolStripMenuItem"
        Me.ExitControlerToolStripMenuItem.Size = New System.Drawing.Size(145, 22)
        Me.ExitControlerToolStripMenuItem.Text = "Exit Controler"
        '
        'DomainUpDownSScb
        '
        Me.DomainUpDownSScb.Items.Add("Off")
        Me.DomainUpDownSScb.Items.Add("On")
        Me.DomainUpDownSScb.Location = New System.Drawing.Point(66, 210)
        Me.DomainUpDownSScb.Name = "DomainUpDownSScb"
        Me.DomainUpDownSScb.ReadOnly = True
        Me.DomainUpDownSScb.Size = New System.Drawing.Size(61, 20)
        Me.DomainUpDownSScb.TabIndex = 186
        Me.DomainUpDownSScb.Text = "ON/OFF"
        Me.DomainUpDownSScb.Visible = False
        '
        'LinkLabelSScb
        '
        Me.LinkLabelSScb.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelSScb.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelSScb.LinkColor = System.Drawing.Color.White
        Me.LinkLabelSScb.Location = New System.Drawing.Point(72, 154)
        Me.LinkLabelSScb.Name = "LinkLabelSScb"
        Me.LinkLabelSScb.Size = New System.Drawing.Size(103, 50)
        Me.LinkLabelSScb.TabIndex = 185
        Me.LinkLabelSScb.TabStop = True
        Me.LinkLabelSScb.Text = "Stereo"
        Me.LinkLabelSScb.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'DomainUpDownTVcb
        '
        Me.DomainUpDownTVcb.Items.Add("Off")
        Me.DomainUpDownTVcb.Items.Add("On")
        Me.DomainUpDownTVcb.Location = New System.Drawing.Point(523, 193)
        Me.DomainUpDownTVcb.Name = "DomainUpDownTVcb"
        Me.DomainUpDownTVcb.ReadOnly = True
        Me.DomainUpDownTVcb.Size = New System.Drawing.Size(61, 20)
        Me.DomainUpDownTVcb.TabIndex = 187
        Me.DomainUpDownTVcb.Text = "ON/OFF"
        '
        'LinkLabelTVcb
        '
        Me.LinkLabelTVcb.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelTVcb.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelTVcb.LinkColor = System.Drawing.Color.White
        Me.LinkLabelTVcb.Location = New System.Drawing.Point(507, 112)
        Me.LinkLabelTVcb.Name = "LinkLabelTVcb"
        Me.LinkLabelTVcb.Size = New System.Drawing.Size(95, 53)
        Me.LinkLabelTVcb.TabIndex = 189
        Me.LinkLabelTVcb.TabStop = True
        Me.LinkLabelTVcb.Text = "TV"
        Me.LinkLabelTVcb.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ButtonBackCBStaf
        '
        Me.ButtonBackCBStaf.Enabled = False
        Me.ButtonBackCBStaf.Location = New System.Drawing.Point(462, 415)
        Me.ButtonBackCBStaf.Name = "ButtonBackCBStaf"
        Me.ButtonBackCBStaf.Size = New System.Drawing.Size(110, 25)
        Me.ButtonBackCBStaf.TabIndex = 190
        Me.ButtonBackCBStaf.Text = "Back"
        Me.ButtonBackCBStaf.UseVisualStyleBackColor = True
        Me.ButtonBackCBStaf.Visible = False
        '
        'DomainUpDownPa
        '
        Me.DomainUpDownPa.Items.Add("Add to My Room Account")
        Me.DomainUpDownPa.Items.Add("Credit Card Instant Payment")
        Me.DomainUpDownPa.Location = New System.Drawing.Point(272, 370)
        Me.DomainUpDownPa.Name = "DomainUpDownPa"
        Me.DomainUpDownPa.ReadOnly = True
        Me.DomainUpDownPa.Size = New System.Drawing.Size(140, 20)
        Me.DomainUpDownPa.TabIndex = 191
        Me.DomainUpDownPa.Text = "<select payment>"
        '
        'TextBoxPa
        '
        Me.TextBoxPa.Location = New System.Drawing.Point(119, 376)
        Me.TextBoxPa.Name = "TextBoxPa"
        Me.TextBoxPa.Size = New System.Drawing.Size(129, 20)
        Me.TextBoxPa.TabIndex = 192
        Me.TextBoxPa.Visible = False
        '
        'ButtonPas
        '
        Me.ButtonPas.Location = New System.Drawing.Point(366, 396)
        Me.ButtonPas.Name = "ButtonPas"
        Me.ButtonPas.Size = New System.Drawing.Size(43, 22)
        Me.ButtonPas.TabIndex = 193
        Me.ButtonPas.Text = "Pay"
        Me.ButtonPas.UseVisualStyleBackColor = True
        '
        'HelpProvider1
        '
        Me.HelpProvider1.HelpNamespace = "C:\Users\Morpheus\Desktop\Dun.chm"
        '
        'PictureBoxTVcb
        '
        Me.PictureBoxTVcb.BackgroundImage = CType(resources.GetObject("PictureBoxTVcb.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxTVcb.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxTVcb.Location = New System.Drawing.Point(507, 115)
        Me.PictureBoxTVcb.Name = "PictureBoxTVcb"
        Me.PictureBoxTVcb.Size = New System.Drawing.Size(77, 50)
        Me.PictureBoxTVcb.TabIndex = 188
        Me.PictureBoxTVcb.TabStop = False
        '
        'PictureBoxSScb
        '
        Me.PictureBoxSScb.BackgroundImage = CType(resources.GetObject("PictureBoxSScb.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxSScb.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxSScb.Location = New System.Drawing.Point(72, 154)
        Me.PictureBoxSScb.Name = "PictureBoxSScb"
        Me.PictureBoxSScb.Size = New System.Drawing.Size(98, 50)
        Me.PictureBoxSScb.TabIndex = 184
        Me.PictureBoxSScb.TabStop = False
        '
        'PictureBoxAircb
        '
        Me.PictureBoxAircb.BackgroundImage = CType(resources.GetObject("PictureBoxAircb.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxAircb.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxAircb.Location = New System.Drawing.Point(142, 16)
        Me.PictureBoxAircb.Name = "PictureBoxAircb"
        Me.PictureBoxAircb.Size = New System.Drawing.Size(122, 52)
        Me.PictureBoxAircb.TabIndex = 178
        Me.PictureBoxAircb.TabStop = False
        '
        'PictureBoxMainLightscb
        '
        Me.PictureBoxMainLightscb.BackColor = System.Drawing.Color.Transparent
        Me.PictureBoxMainLightscb.BackgroundImage = CType(resources.GetObject("PictureBoxMainLightscb.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxMainLightscb.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxMainLightscb.Location = New System.Drawing.Point(398, 4)
        Me.PictureBoxMainLightscb.Name = "PictureBoxMainLightscb"
        Me.PictureBoxMainLightscb.Size = New System.Drawing.Size(74, 77)
        Me.PictureBoxMainLightscb.TabIndex = 174
        Me.PictureBoxMainLightscb.TabStop = False
        '
        'PictureBoxSeclicb
        '
        Me.PictureBoxSeclicb.BackColor = System.Drawing.Color.Transparent
        Me.PictureBoxSeclicb.BackgroundImage = CType(resources.GetObject("PictureBoxSeclicb.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxSeclicb.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxSeclicb.Location = New System.Drawing.Point(12, 89)
        Me.PictureBoxSeclicb.Name = "PictureBoxSeclicb"
        Me.PictureBoxSeclicb.Size = New System.Drawing.Size(32, 78)
        Me.PictureBoxSeclicb.TabIndex = 177
        Me.PictureBoxSeclicb.TabStop = False
        '
        'PictureBoxPa
        '
        Me.PictureBoxPa.BackColor = System.Drawing.Color.Transparent
        Me.PictureBoxPa.BackgroundImage = CType(resources.GetObject("PictureBoxPa.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxPa.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxPa.Location = New System.Drawing.Point(416, 315)
        Me.PictureBoxPa.Name = "PictureBoxPa"
        Me.PictureBoxPa.Size = New System.Drawing.Size(156, 80)
        Me.PictureBoxPa.TabIndex = 168
        Me.PictureBoxPa.TabStop = False
        '
        'PictureBoxCof
        '
        Me.PictureBoxCof.BackColor = System.Drawing.Color.Transparent
        Me.PictureBoxCof.BackgroundImage = CType(resources.GetObject("PictureBoxCof.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxCof.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxCof.Location = New System.Drawing.Point(239, 124)
        Me.PictureBoxCof.Name = "PictureBoxCof"
        Me.PictureBoxCof.Size = New System.Drawing.Size(84, 60)
        Me.PictureBoxCof.TabIndex = 165
        Me.PictureBoxCof.TabStop = False
        '
        'PictureBoxSp
        '
        Me.PictureBoxSp.BackColor = System.Drawing.Color.Transparent
        Me.PictureBoxSp.BackgroundImage = CType(resources.GetObject("PictureBoxSp.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxSp.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxSp.Location = New System.Drawing.Point(76, 99)
        Me.PictureBoxSp.Name = "PictureBoxSp"
        Me.PictureBoxSp.Size = New System.Drawing.Size(101, 54)
        Me.PictureBoxSp.TabIndex = 162
        Me.PictureBoxSp.TabStop = False
        '
        'PictureBoxCoc
        '
        Me.PictureBoxCoc.BackColor = System.Drawing.Color.Transparent
        Me.PictureBoxCoc.BackgroundImage = CType(resources.GetObject("PictureBoxCoc.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxCoc.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxCoc.Location = New System.Drawing.Point(155, 197)
        Me.PictureBoxCoc.Name = "PictureBoxCoc"
        Me.PictureBoxCoc.Size = New System.Drawing.Size(72, 82)
        Me.PictureBoxCoc.TabIndex = 194
        Me.PictureBoxCoc.TabStop = False
        '
        'PictureBoxBe
        '
        Me.PictureBoxBe.BackColor = System.Drawing.Color.Transparent
        Me.PictureBoxBe.BackgroundImage = CType(resources.GetObject("PictureBoxBe.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxBe.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxBe.Location = New System.Drawing.Point(354, 144)
        Me.PictureBoxBe.Name = "PictureBoxBe"
        Me.PictureBoxBe.Size = New System.Drawing.Size(100, 50)
        Me.PictureBoxBe.TabIndex = 195
        Me.PictureBoxBe.TabStop = False
        '
        'PictureBoxSna
        '
        Me.PictureBoxSna.BackColor = System.Drawing.Color.Transparent
        Me.PictureBoxSna.BackgroundImage = CType(resources.GetObject("PictureBoxSna.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxSna.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxSna.Location = New System.Drawing.Point(268, 222)
        Me.PictureBoxSna.Name = "PictureBoxSna"
        Me.PictureBoxSna.Size = New System.Drawing.Size(121, 57)
        Me.PictureBoxSna.TabIndex = 170
        Me.PictureBoxSna.TabStop = False
        '
        'FormCoffeeBar
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(584, 452)
        Me.Controls.Add(Me.LinkLabelSeclicb)
        Me.Controls.Add(Me.ButtonPas)
        Me.Controls.Add(Me.TextBoxPa)
        Me.Controls.Add(Me.DomainUpDownPa)
        Me.Controls.Add(Me.DomainUpDownTVcb)
        Me.Controls.Add(Me.LinkLabelTVcb)
        Me.Controls.Add(Me.PictureBoxTVcb)
        Me.Controls.Add(Me.DomainUpDownSScb)
        Me.Controls.Add(Me.LinkLabelSScb)
        Me.Controls.Add(Me.PictureBoxSScb)
        Me.Controls.Add(Me.DomainUpDownSlcb)
        Me.Controls.Add(Me.DomainUpDownMlcb)
        Me.Controls.Add(Me.NumericUpDownaircb)
        Me.Controls.Add(Me.LabelTempAcb)
        Me.Controls.Add(Me.LinkLabelAircb)
        Me.Controls.Add(Me.PictureBoxAircb)
        Me.Controls.Add(Me.LinkLabelMainLightscb)
        Me.Controls.Add(Me.PictureBoxMainLightscb)
        Me.Controls.Add(Me.PictureBoxSeclicb)
        Me.Controls.Add(Me.LinkLabelSna)
        Me.Controls.Add(Me.PictureBoxSna)
        Me.Controls.Add(Me.LinkLabelPa)
        Me.Controls.Add(Me.PictureBoxPa)
        Me.Controls.Add(Me.ButtonBackCBCust)
        Me.Controls.Add(Me.LinkLabelCof)
        Me.Controls.Add(Me.PictureBoxCof)
        Me.Controls.Add(Me.LinkLabelBe)
        Me.Controls.Add(Me.LinkLabelSp)
        Me.Controls.Add(Me.PictureBoxSp)
        Me.Controls.Add(Me.LinkLabelCoc)
        Me.Controls.Add(Me.PictureBoxCoc)
        Me.Controls.Add(Me.PictureBoxBe)
        Me.Controls.Add(Me.MenuStripFile)
        Me.Controls.Add(Me.ButtonBackCBStaf)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "FormCoffeeBar"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Coffee-Bar"
        CType(Me.NumericUpDownaircb, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStripFile.ResumeLayout(False)
        Me.MenuStripFile.PerformLayout()
        CType(Me.PictureBoxTVcb, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxSScb, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxAircb, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxMainLightscb, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxSeclicb, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxPa, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxCof, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxSp, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxCoc, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxBe, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxSna, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents LinkLabelBe As System.Windows.Forms.LinkLabel
    Friend WithEvents PictureBoxSp As System.Windows.Forms.PictureBox
    Friend WithEvents LinkLabelCoc As System.Windows.Forms.LinkLabel
    Friend WithEvents PictureBoxCoc As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBoxBe As System.Windows.Forms.PictureBox
    Friend WithEvents LinkLabelSp As System.Windows.Forms.LinkLabel
    Friend WithEvents LinkLabelCof As System.Windows.Forms.LinkLabel
    Friend WithEvents PictureBoxCof As System.Windows.Forms.PictureBox
    Friend WithEvents ButtonBackCBCust As System.Windows.Forms.Button
    Friend WithEvents LinkLabelPa As System.Windows.Forms.LinkLabel
    Friend WithEvents PictureBoxPa As System.Windows.Forms.PictureBox
    Friend WithEvents LinkLabelSna As System.Windows.Forms.LinkLabel
    Friend WithEvents DomainUpDownSlcb As System.Windows.Forms.DomainUpDown
    Friend WithEvents DomainUpDownMlcb As System.Windows.Forms.DomainUpDown
    Friend WithEvents NumericUpDownaircb As System.Windows.Forms.NumericUpDown
    Friend WithEvents LabelTempAcb As System.Windows.Forms.Label
    Friend WithEvents LinkLabelAircb As System.Windows.Forms.LinkLabel
    Friend WithEvents PictureBoxAircb As System.Windows.Forms.PictureBox
    Friend WithEvents LinkLabelSeclicb As System.Windows.Forms.LinkLabel
    Friend WithEvents LinkLabelMainLightscb As System.Windows.Forms.LinkLabel
    Friend WithEvents PictureBoxMainLightscb As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBoxSeclicb As System.Windows.Forms.PictureBox
    Friend WithEvents MenuStripFile As System.Windows.Forms.MenuStrip
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ContactToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitControlerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DomainUpDownSScb As System.Windows.Forms.DomainUpDown
    Friend WithEvents LinkLabelSScb As System.Windows.Forms.LinkLabel
    Friend WithEvents PictureBoxSScb As System.Windows.Forms.PictureBox
    Friend WithEvents DomainUpDownTVcb As System.Windows.Forms.DomainUpDown
    Friend WithEvents LinkLabelTVcb As System.Windows.Forms.LinkLabel
    Friend WithEvents PictureBoxTVcb As System.Windows.Forms.PictureBox
    Friend WithEvents ButtonBackCBStaf As System.Windows.Forms.Button
    Friend WithEvents DomainUpDownPa As System.Windows.Forms.DomainUpDown
    Friend WithEvents TextBoxPa As System.Windows.Forms.TextBox
    Friend WithEvents ButtonPas As System.Windows.Forms.Button
    Friend WithEvents LogOutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpProvider1 As System.Windows.Forms.HelpProvider
    Friend WithEvents PictureBoxSna As System.Windows.Forms.PictureBox
End Class
