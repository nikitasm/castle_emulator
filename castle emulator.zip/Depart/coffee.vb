﻿Public Class Formcoffee

    Private Sub Formcoffee_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        TextBoxCofOr.Text = (TextBoxCofOr.Text & "The Americano")
    End Sub

    Private Sub LinkLabel2_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel2.LinkClicked
        TextBoxCofOr.Text = (TextBoxCofOr.Text & "The Cappuccino")
    End Sub

    Private Sub LinkLabel3_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel3.LinkClicked
        TextBoxCofOr.Text = (TextBoxCofOr.Text & "Caffe Latte")
    End Sub

    Private Sub LinkLabel4_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel4.LinkClicked
        TextBoxCofOr.Text = (TextBoxCofOr.Text & "Caffe Mocha")
    End Sub

    Private Sub LinkLabel5_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel5.LinkClicked
        TextBoxCofOr.Text = (TextBoxCofOr.Text & "Espresso")
    End Sub

    Private Sub LinkLabel6_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel6.LinkClicked
        TextBoxCofOr.Text = (TextBoxCofOr.Text & "Double It Up")
    End Sub

    Private Sub LinkLabel7_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel7.LinkClicked
        TextBoxCofOr.Text = (TextBoxCofOr.Text & "Hot Chocolate")
    End Sub

    Private Sub LinkLabel8_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel8.LinkClicked
        TextBoxCofOr.Text = (TextBoxCofOr.Text & "Traditional Breakfast Tea")
    End Sub

    Private Sub LinkLabel9_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel9.LinkClicked
        TextBoxCofOr.Text = (TextBoxCofOr.Text & "Selected Muffin & Cookies")
    End Sub

    Private Sub LinkLabel10_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel10.LinkClicked
        TextBoxCofOr.Text = (TextBoxCofOr.Text & "Branded Coffee Mug")
    End Sub

    Private Sub LinkLabel11_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel11.LinkClicked
        TextBoxCofOr.Text = (TextBoxCofOr.Text & "Buy The Drink Keep The Mug")
    End Sub

    Private Sub ButtonResetO_Click(sender As Object, e As EventArgs) Handles ButtonResetO.Click
        TextBoxCofOr.Text = ""
    End Sub

    Private Sub ButtonBackcof_Click(sender As Object, e As EventArgs) Handles ButtonBackcof.Click
        FormCoffeeBar.Show()
        Me.Hide()
    End Sub
    Private Sub ButtonBackres_Click(sender As Object, e As EventArgs) Handles ButtonBackres.Click
        FormRestaurant.Show()
        Me.Hide()
    End Sub
End Class