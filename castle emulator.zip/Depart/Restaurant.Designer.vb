﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormRestaurant
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormRestaurant))
        Me.PictureBoxSeclightsR = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.DomainUpDownSlR = New System.Windows.Forms.DomainUpDown()
        Me.LinkLabelSeclightsR = New System.Windows.Forms.LinkLabel()
        Me.DomainUpDownTVR = New System.Windows.Forms.DomainUpDown()
        Me.LinkLabelTVR = New System.Windows.Forms.LinkLabel()
        Me.PictureBoxTVR = New System.Windows.Forms.PictureBox()
        Me.NumericUpDownAR = New System.Windows.Forms.NumericUpDown()
        Me.LabelTempAR = New System.Windows.Forms.Label()
        Me.LinkLabelAirR = New System.Windows.Forms.LinkLabel()
        Me.PictureBoxAirR = New System.Windows.Forms.PictureBox()
        Me.DomainUpDownSSR = New System.Windows.Forms.DomainUpDown()
        Me.LinkLabelSSR = New System.Windows.Forms.LinkLabel()
        Me.PictureBoxSSR = New System.Windows.Forms.PictureBox()
        Me.DomainUpDownMlR = New System.Windows.Forms.DomainUpDown()
        Me.LinkLabelMainLightsR = New System.Windows.Forms.LinkLabel()
        Me.PictureBoxMainLightsR = New System.Windows.Forms.PictureBox()
        Me.LinkLabelSpR = New System.Windows.Forms.LinkLabel()
        Me.PictureBoxSpR = New System.Windows.Forms.PictureBox()
        Me.LinkLabelCofR = New System.Windows.Forms.LinkLabel()
        Me.PictureBoxCofR = New System.Windows.Forms.PictureBox()
        Me.LinkLabelPaR = New System.Windows.Forms.LinkLabel()
        Me.PictureBoxPaR = New System.Windows.Forms.PictureBox()
        Me.LinkLabelmenuR = New System.Windows.Forms.LinkLabel()
        Me.PictureBoxMenuR = New System.Windows.Forms.PictureBox()
        Me.ButtonPasR = New System.Windows.Forms.Button()
        Me.TextBoxPaR = New System.Windows.Forms.TextBox()
        Me.DomainUpDownPaR = New System.Windows.Forms.DomainUpDown()
        Me.ButtonBackRCust = New System.Windows.Forms.Button()
        Me.ButtonBackRStaf = New System.Windows.Forms.Button()
        Me.MenuStripFile = New System.Windows.Forms.MenuStrip()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ContactToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LogOutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitControlerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpProvider1 = New System.Windows.Forms.HelpProvider()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        CType(Me.PictureBoxSeclightsR, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxTVR, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDownAR, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxAirR, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxSSR, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxMainLightsR, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxSpR, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxCofR, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxPaR, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxMenuR, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStripFile.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PictureBoxSeclightsR
        '
        Me.PictureBoxSeclightsR.BackColor = System.Drawing.Color.Transparent
        Me.PictureBoxSeclightsR.BackgroundImage = CType(resources.GetObject("PictureBoxSeclightsR.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxSeclightsR.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxSeclightsR.Location = New System.Drawing.Point(141, 119)
        Me.PictureBoxSeclightsR.Name = "PictureBoxSeclightsR"
        Me.PictureBoxSeclightsR.Size = New System.Drawing.Size(38, 93)
        Me.PictureBoxSeclightsR.TabIndex = 178
        Me.PictureBoxSeclightsR.TabStop = False
        Me.PictureBoxSeclightsR.Visible = False
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox1.BackgroundImage = CType(resources.GetObject("PictureBox1.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox1.Location = New System.Drawing.Point(-11, 112)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(54, 100)
        Me.PictureBox1.TabIndex = 179
        Me.PictureBox1.TabStop = False
        Me.PictureBox1.Visible = False
        '
        'DomainUpDownSlR
        '
        Me.DomainUpDownSlR.Items.Add("Off")
        Me.DomainUpDownSlR.Items.Add("On")
        Me.DomainUpDownSlR.Location = New System.Drawing.Point(151, 215)
        Me.DomainUpDownSlR.Name = "DomainUpDownSlR"
        Me.DomainUpDownSlR.ReadOnly = True
        Me.DomainUpDownSlR.Size = New System.Drawing.Size(64, 20)
        Me.DomainUpDownSlR.TabIndex = 182
        Me.DomainUpDownSlR.Text = "ON/OFF"
        Me.DomainUpDownSlR.Visible = False
        '
        'LinkLabelSeclightsR
        '
        Me.LinkLabelSeclightsR.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelSeclightsR.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelSeclightsR.LinkColor = System.Drawing.Color.White
        Me.LinkLabelSeclightsR.Location = New System.Drawing.Point(146, 99)
        Me.LinkLabelSeclightsR.Name = "LinkLabelSeclightsR"
        Me.LinkLabelSeclightsR.Size = New System.Drawing.Size(79, 113)
        Me.LinkLabelSeclightsR.TabIndex = 183
        Me.LinkLabelSeclightsR.TabStop = True
        Me.LinkLabelSeclightsR.Text = "Sec Lights"
        Me.LinkLabelSeclightsR.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.LinkLabelSeclightsR.Visible = False
        '
        'DomainUpDownTVR
        '
        Me.DomainUpDownTVR.Items.Add("Off")
        Me.DomainUpDownTVR.Items.Add("On")
        Me.DomainUpDownTVR.Location = New System.Drawing.Point(69, 215)
        Me.DomainUpDownTVR.Name = "DomainUpDownTVR"
        Me.DomainUpDownTVR.ReadOnly = True
        Me.DomainUpDownTVR.Size = New System.Drawing.Size(61, 20)
        Me.DomainUpDownTVR.TabIndex = 184
        Me.DomainUpDownTVR.Text = "ON/OFF"
        '
        'LinkLabelTVR
        '
        Me.LinkLabelTVR.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelTVR.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelTVR.LinkColor = System.Drawing.Color.White
        Me.LinkLabelTVR.Location = New System.Drawing.Point(48, 112)
        Me.LinkLabelTVR.Name = "LinkLabelTVR"
        Me.LinkLabelTVR.Size = New System.Drawing.Size(101, 100)
        Me.LinkLabelTVR.TabIndex = 186
        Me.LinkLabelTVR.TabStop = True
        Me.LinkLabelTVR.Text = "TV"
        Me.LinkLabelTVR.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'PictureBoxTVR
        '
        Me.PictureBoxTVR.BackgroundImage = CType(resources.GetObject("PictureBoxTVR.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxTVR.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxTVR.Location = New System.Drawing.Point(49, 138)
        Me.PictureBoxTVR.Name = "PictureBoxTVR"
        Me.PictureBoxTVR.Size = New System.Drawing.Size(100, 62)
        Me.PictureBoxTVR.TabIndex = 185
        Me.PictureBoxTVR.TabStop = False
        '
        'NumericUpDownAR
        '
        Me.NumericUpDownAR.Location = New System.Drawing.Point(446, 95)
        Me.NumericUpDownAR.Maximum = New Decimal(New Integer() {28, 0, 0, 0})
        Me.NumericUpDownAR.Minimum = New Decimal(New Integer() {16, 0, 0, 0})
        Me.NumericUpDownAR.Name = "NumericUpDownAR"
        Me.NumericUpDownAR.ReadOnly = True
        Me.NumericUpDownAR.Size = New System.Drawing.Size(67, 20)
        Me.NumericUpDownAR.TabIndex = 189
        Me.NumericUpDownAR.Value = New Decimal(New Integer() {16, 0, 0, 0})
        Me.NumericUpDownAR.Visible = False
        '
        'LabelTempAR
        '
        Me.LabelTempAR.AutoSize = True
        Me.LabelTempAR.Location = New System.Drawing.Point(443, 80)
        Me.LabelTempAR.Name = "LabelTempAR"
        Me.LabelTempAR.Size = New System.Drawing.Size(48, 13)
        Me.LabelTempAR.TabIndex = 190
        Me.LabelTempAR.Text = "Temp °C"
        Me.LabelTempAR.Visible = False
        '
        'LinkLabelAirR
        '
        Me.LinkLabelAirR.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelAirR.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelAirR.LinkColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.LinkLabelAirR.Location = New System.Drawing.Point(362, 71)
        Me.LinkLabelAirR.Name = "LinkLabelAirR"
        Me.LinkLabelAirR.Size = New System.Drawing.Size(82, 61)
        Me.LinkLabelAirR.TabIndex = 188
        Me.LinkLabelAirR.TabStop = True
        Me.LinkLabelAirR.Text = "Air"
        Me.LinkLabelAirR.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'PictureBoxAirR
        '
        Me.PictureBoxAirR.BackgroundImage = CType(resources.GetObject("PictureBoxAirR.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxAirR.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxAirR.Location = New System.Drawing.Point(365, 95)
        Me.PictureBoxAirR.Name = "PictureBoxAirR"
        Me.PictureBoxAirR.Size = New System.Drawing.Size(77, 39)
        Me.PictureBoxAirR.TabIndex = 187
        Me.PictureBoxAirR.TabStop = False
        '
        'DomainUpDownSSR
        '
        Me.DomainUpDownSSR.Items.Add("Off")
        Me.DomainUpDownSSR.Items.Add("On")
        Me.DomainUpDownSSR.Location = New System.Drawing.Point(511, 184)
        Me.DomainUpDownSSR.Name = "DomainUpDownSSR"
        Me.DomainUpDownSSR.ReadOnly = True
        Me.DomainUpDownSSR.Size = New System.Drawing.Size(61, 20)
        Me.DomainUpDownSSR.TabIndex = 193
        Me.DomainUpDownSSR.Text = "ON/OFF"
        Me.DomainUpDownSSR.Visible = False
        '
        'LinkLabelSSR
        '
        Me.LinkLabelSSR.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelSSR.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelSSR.LinkColor = System.Drawing.Color.Blue
        Me.LinkLabelSSR.Location = New System.Drawing.Point(502, 215)
        Me.LinkLabelSSR.Name = "LinkLabelSSR"
        Me.LinkLabelSSR.Size = New System.Drawing.Size(81, 44)
        Me.LinkLabelSSR.TabIndex = 192
        Me.LinkLabelSSR.TabStop = True
        Me.LinkLabelSSR.Text = "Stereo"
        Me.LinkLabelSSR.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.LinkLabelSSR.Visible = False
        '
        'PictureBoxSSR
        '
        Me.PictureBoxSSR.BackgroundImage = CType(resources.GetObject("PictureBoxSSR.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxSSR.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxSSR.Location = New System.Drawing.Point(507, 215)
        Me.PictureBoxSSR.Name = "PictureBoxSSR"
        Me.PictureBoxSSR.Size = New System.Drawing.Size(76, 37)
        Me.PictureBoxSSR.TabIndex = 191
        Me.PictureBoxSSR.TabStop = False
        '
        'DomainUpDownMlR
        '
        Me.DomainUpDownMlR.Items.Add("Off")
        Me.DomainUpDownMlR.Items.Add("On")
        Me.DomainUpDownMlR.Location = New System.Drawing.Point(114, 27)
        Me.DomainUpDownMlR.Name = "DomainUpDownMlR"
        Me.DomainUpDownMlR.ReadOnly = True
        Me.DomainUpDownMlR.Size = New System.Drawing.Size(65, 20)
        Me.DomainUpDownMlR.TabIndex = 194
        Me.DomainUpDownMlR.Text = "ON/OFF"
        Me.DomainUpDownMlR.Visible = False
        '
        'LinkLabelMainLightsR
        '
        Me.LinkLabelMainLightsR.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelMainLightsR.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelMainLightsR.LinkColor = System.Drawing.Color.Yellow
        Me.LinkLabelMainLightsR.Location = New System.Drawing.Point(176, 4)
        Me.LinkLabelMainLightsR.Name = "LinkLabelMainLightsR"
        Me.LinkLabelMainLightsR.Size = New System.Drawing.Size(137, 73)
        Me.LinkLabelMainLightsR.TabIndex = 196
        Me.LinkLabelMainLightsR.TabStop = True
        Me.LinkLabelMainLightsR.Text = "Main Lights"
        Me.LinkLabelMainLightsR.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.LinkLabelMainLightsR.Visible = False
        '
        'PictureBoxMainLightsR
        '
        Me.PictureBoxMainLightsR.BackColor = System.Drawing.Color.Transparent
        Me.PictureBoxMainLightsR.BackgroundImage = CType(resources.GetObject("PictureBoxMainLightsR.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxMainLightsR.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxMainLightsR.Location = New System.Drawing.Point(181, 4)
        Me.PictureBoxMainLightsR.Name = "PictureBoxMainLightsR"
        Me.PictureBoxMainLightsR.Size = New System.Drawing.Size(53, 44)
        Me.PictureBoxMainLightsR.TabIndex = 195
        Me.PictureBoxMainLightsR.TabStop = False
        Me.PictureBoxMainLightsR.Visible = False
        '
        'LinkLabelSpR
        '
        Me.LinkLabelSpR.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelSpR.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelSpR.LinkColor = System.Drawing.Color.Blue
        Me.LinkLabelSpR.Location = New System.Drawing.Point(509, 73)
        Me.LinkLabelSpR.Name = "LinkLabelSpR"
        Me.LinkLabelSpR.Size = New System.Drawing.Size(73, 105)
        Me.LinkLabelSpR.TabIndex = 199
        Me.LinkLabelSpR.TabStop = True
        Me.LinkLabelSpR.Text = "Spirits"
        Me.LinkLabelSpR.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'PictureBoxSpR
        '
        Me.PictureBoxSpR.BackColor = System.Drawing.Color.Transparent
        Me.PictureBoxSpR.BackgroundImage = CType(resources.GetObject("PictureBoxSpR.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxSpR.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxSpR.Location = New System.Drawing.Point(511, 95)
        Me.PictureBoxSpR.Name = "PictureBoxSpR"
        Me.PictureBoxSpR.Size = New System.Drawing.Size(71, 83)
        Me.PictureBoxSpR.TabIndex = 198
        Me.PictureBoxSpR.TabStop = False
        '
        'LinkLabelCofR
        '
        Me.LinkLabelCofR.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelCofR.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelCofR.LinkColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.LinkLabelCofR.Location = New System.Drawing.Point(355, 153)
        Me.LinkLabelCofR.Name = "LinkLabelCofR"
        Me.LinkLabelCofR.Size = New System.Drawing.Size(82, 67)
        Me.LinkLabelCofR.TabIndex = 201
        Me.LinkLabelCofR.TabStop = True
        Me.LinkLabelCofR.Text = "Coffee"
        Me.LinkLabelCofR.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PictureBoxCofR
        '
        Me.PictureBoxCofR.BackColor = System.Drawing.Color.Transparent
        Me.PictureBoxCofR.BackgroundImage = CType(resources.GetObject("PictureBoxCofR.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxCofR.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxCofR.Location = New System.Drawing.Point(365, 165)
        Me.PictureBoxCofR.Name = "PictureBoxCofR"
        Me.PictureBoxCofR.Size = New System.Drawing.Size(62, 47)
        Me.PictureBoxCofR.TabIndex = 200
        Me.PictureBoxCofR.TabStop = False
        '
        'LinkLabelPaR
        '
        Me.LinkLabelPaR.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelPaR.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelPaR.LinkColor = System.Drawing.Color.White
        Me.LinkLabelPaR.Location = New System.Drawing.Point(416, 303)
        Me.LinkLabelPaR.Name = "LinkLabelPaR"
        Me.LinkLabelPaR.Size = New System.Drawing.Size(156, 93)
        Me.LinkLabelPaR.TabIndex = 203
        Me.LinkLabelPaR.TabStop = True
        Me.LinkLabelPaR.Text = "Pay"
        Me.LinkLabelPaR.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'PictureBoxPaR
        '
        Me.PictureBoxPaR.BackColor = System.Drawing.Color.Transparent
        Me.PictureBoxPaR.BackgroundImage = CType(resources.GetObject("PictureBoxPaR.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxPaR.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxPaR.Location = New System.Drawing.Point(416, 316)
        Me.PictureBoxPaR.Name = "PictureBoxPaR"
        Me.PictureBoxPaR.Size = New System.Drawing.Size(156, 80)
        Me.PictureBoxPaR.TabIndex = 202
        Me.PictureBoxPaR.TabStop = False
        '
        'LinkLabelmenuR
        '
        Me.LinkLabelmenuR.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelmenuR.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelmenuR.LinkColor = System.Drawing.Color.White
        Me.LinkLabelmenuR.Location = New System.Drawing.Point(59, 238)
        Me.LinkLabelmenuR.Name = "LinkLabelmenuR"
        Me.LinkLabelmenuR.Size = New System.Drawing.Size(166, 110)
        Me.LinkLabelmenuR.TabIndex = 205
        Me.LinkLabelmenuR.TabStop = True
        Me.LinkLabelmenuR.Text = "MENU"
        Me.LinkLabelmenuR.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'PictureBoxMenuR
        '
        Me.PictureBoxMenuR.BackColor = System.Drawing.Color.Transparent
        Me.PictureBoxMenuR.BackgroundImage = CType(resources.GetObject("PictureBoxMenuR.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxMenuR.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxMenuR.Location = New System.Drawing.Point(283, 215)
        Me.PictureBoxMenuR.Name = "PictureBoxMenuR"
        Me.PictureBoxMenuR.Size = New System.Drawing.Size(55, 44)
        Me.PictureBoxMenuR.TabIndex = 204
        Me.PictureBoxMenuR.TabStop = False
        '
        'ButtonPasR
        '
        Me.ButtonPasR.Location = New System.Drawing.Point(367, 369)
        Me.ButtonPasR.Name = "ButtonPasR"
        Me.ButtonPasR.Size = New System.Drawing.Size(43, 22)
        Me.ButtonPasR.TabIndex = 208
        Me.ButtonPasR.Text = "Pay"
        Me.ButtonPasR.UseVisualStyleBackColor = True
        '
        'TextBoxPaR
        '
        Me.TextBoxPaR.Location = New System.Drawing.Point(120, 349)
        Me.TextBoxPaR.Name = "TextBoxPaR"
        Me.TextBoxPaR.Size = New System.Drawing.Size(129, 20)
        Me.TextBoxPaR.TabIndex = 207
        Me.TextBoxPaR.Visible = False
        '
        'DomainUpDownPaR
        '
        Me.DomainUpDownPaR.Items.Add("Add to My Room Account")
        Me.DomainUpDownPaR.Items.Add("Credit Card Instant Payment")
        Me.DomainUpDownPaR.Location = New System.Drawing.Point(273, 343)
        Me.DomainUpDownPaR.Name = "DomainUpDownPaR"
        Me.DomainUpDownPaR.ReadOnly = True
        Me.DomainUpDownPaR.Size = New System.Drawing.Size(140, 20)
        Me.DomainUpDownPaR.TabIndex = 206
        Me.DomainUpDownPaR.Text = "<select payment>"
        '
        'ButtonBackRCust
        '
        Me.ButtonBackRCust.Location = New System.Drawing.Point(462, 415)
        Me.ButtonBackRCust.Name = "ButtonBackRCust"
        Me.ButtonBackRCust.Size = New System.Drawing.Size(110, 25)
        Me.ButtonBackRCust.TabIndex = 209
        Me.ButtonBackRCust.Text = "Back"
        Me.ButtonBackRCust.UseVisualStyleBackColor = True
        '
        'ButtonBackRStaf
        '
        Me.ButtonBackRStaf.Enabled = False
        Me.ButtonBackRStaf.Location = New System.Drawing.Point(462, 415)
        Me.ButtonBackRStaf.Name = "ButtonBackRStaf"
        Me.ButtonBackRStaf.Size = New System.Drawing.Size(110, 25)
        Me.ButtonBackRStaf.TabIndex = 210
        Me.ButtonBackRStaf.Text = "Back"
        Me.ButtonBackRStaf.UseVisualStyleBackColor = True
        Me.ButtonBackRStaf.Visible = False
        '
        'MenuStripFile
        '
        Me.MenuStripFile.BackColor = System.Drawing.Color.Transparent
        Me.MenuStripFile.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.MenuStripFile.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem1})
        Me.MenuStripFile.Location = New System.Drawing.Point(0, 0)
        Me.MenuStripFile.Name = "MenuStripFile"
        Me.MenuStripFile.ShowItemToolTips = True
        Me.MenuStripFile.Size = New System.Drawing.Size(584, 24)
        Me.MenuStripFile.TabIndex = 211
        Me.MenuStripFile.Text = "MenuStrip1"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ContactToolStripMenuItem, Me.HelpToolStripMenuItem, Me.AboutToolStripMenuItem, Me.LogOutToolStripMenuItem, Me.ExitControlerToolStripMenuItem})
        Me.ToolStripMenuItem1.ForeColor = System.Drawing.Color.Coral
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(37, 20)
        Me.ToolStripMenuItem1.Text = "File"
        '
        'ContactToolStripMenuItem
        '
        Me.ContactToolStripMenuItem.Name = "ContactToolStripMenuItem"
        Me.ContactToolStripMenuItem.Size = New System.Drawing.Size(145, 22)
        Me.ContactToolStripMenuItem.Text = "Contact"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(145, 22)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(145, 22)
        Me.AboutToolStripMenuItem.Text = "About"
        '
        'LogOutToolStripMenuItem
        '
        Me.LogOutToolStripMenuItem.Name = "LogOutToolStripMenuItem"
        Me.LogOutToolStripMenuItem.Size = New System.Drawing.Size(145, 22)
        Me.LogOutToolStripMenuItem.Text = "Log Out"
        '
        'ExitControlerToolStripMenuItem
        '
        Me.ExitControlerToolStripMenuItem.Name = "ExitControlerToolStripMenuItem"
        Me.ExitControlerToolStripMenuItem.Size = New System.Drawing.Size(145, 22)
        Me.ExitControlerToolStripMenuItem.Text = "Exit Controler"
        '
        'HelpProvider1
        '
        Me.HelpProvider1.HelpNamespace = "C:\Users\Morpheus\Desktop\Dun.chm"
        '
        'PictureBox2
        '
        Me.PictureBox2.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox2.BackgroundImage = CType(resources.GetObject("PictureBox2.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox2.Location = New System.Drawing.Point(254, 146)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(27, 59)
        Me.PictureBox2.TabIndex = 212
        Me.PictureBox2.TabStop = False
        Me.PictureBox2.Visible = False
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(254, 420)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(100, 20)
        Me.TextBox1.TabIndex = 214
        Me.TextBox1.Visible = False
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Location = New System.Drawing.Point(25, 420)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(200, 20)
        Me.DateTimePicker1.TabIndex = 213
        Me.DateTimePicker1.Visible = False
        '
        'FormRestaurant
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(584, 452)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.DateTimePicker1)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.ButtonBackRCust)
        Me.Controls.Add(Me.ButtonBackRStaf)
        Me.Controls.Add(Me.ButtonPasR)
        Me.Controls.Add(Me.TextBoxPaR)
        Me.Controls.Add(Me.DomainUpDownPaR)
        Me.Controls.Add(Me.LinkLabelmenuR)
        Me.Controls.Add(Me.PictureBoxMenuR)
        Me.Controls.Add(Me.LinkLabelPaR)
        Me.Controls.Add(Me.PictureBoxPaR)
        Me.Controls.Add(Me.LinkLabelCofR)
        Me.Controls.Add(Me.PictureBoxCofR)
        Me.Controls.Add(Me.LinkLabelSpR)
        Me.Controls.Add(Me.PictureBoxSpR)
        Me.Controls.Add(Me.DomainUpDownMlR)
        Me.Controls.Add(Me.LinkLabelMainLightsR)
        Me.Controls.Add(Me.PictureBoxMainLightsR)
        Me.Controls.Add(Me.DomainUpDownSSR)
        Me.Controls.Add(Me.LinkLabelSSR)
        Me.Controls.Add(Me.PictureBoxSSR)
        Me.Controls.Add(Me.NumericUpDownAR)
        Me.Controls.Add(Me.LabelTempAR)
        Me.Controls.Add(Me.LinkLabelAirR)
        Me.Controls.Add(Me.PictureBoxAirR)
        Me.Controls.Add(Me.DomainUpDownTVR)
        Me.Controls.Add(Me.LinkLabelTVR)
        Me.Controls.Add(Me.PictureBoxTVR)
        Me.Controls.Add(Me.DomainUpDownSlR)
        Me.Controls.Add(Me.LinkLabelSeclightsR)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.PictureBoxSeclightsR)
        Me.Controls.Add(Me.MenuStripFile)
        Me.DoubleBuffered = True
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "FormRestaurant"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Restaurant"
        CType(Me.PictureBoxSeclightsR, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxTVR, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDownAR, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxAirR, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxSSR, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxMainLightsR, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxSpR, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxCofR, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxPaR, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxMenuR, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStripFile.ResumeLayout(False)
        Me.MenuStripFile.PerformLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents PictureBoxSeclightsR As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents DomainUpDownSlR As System.Windows.Forms.DomainUpDown
    Friend WithEvents LinkLabelSeclightsR As System.Windows.Forms.LinkLabel
    Friend WithEvents DomainUpDownTVR As System.Windows.Forms.DomainUpDown
    Friend WithEvents LinkLabelTVR As System.Windows.Forms.LinkLabel
    Friend WithEvents PictureBoxTVR As System.Windows.Forms.PictureBox
    Friend WithEvents NumericUpDownAR As System.Windows.Forms.NumericUpDown
    Friend WithEvents LabelTempAR As System.Windows.Forms.Label
    Friend WithEvents LinkLabelAirR As System.Windows.Forms.LinkLabel
    Friend WithEvents PictureBoxAirR As System.Windows.Forms.PictureBox
    Friend WithEvents DomainUpDownSSR As System.Windows.Forms.DomainUpDown
    Friend WithEvents LinkLabelSSR As System.Windows.Forms.LinkLabel
    Friend WithEvents PictureBoxSSR As System.Windows.Forms.PictureBox
    Friend WithEvents DomainUpDownMlR As System.Windows.Forms.DomainUpDown
    Friend WithEvents LinkLabelMainLightsR As System.Windows.Forms.LinkLabel
    Friend WithEvents PictureBoxMainLightsR As System.Windows.Forms.PictureBox
    Friend WithEvents LinkLabelSpR As System.Windows.Forms.LinkLabel
    Friend WithEvents PictureBoxSpR As System.Windows.Forms.PictureBox
    Friend WithEvents LinkLabelCofR As System.Windows.Forms.LinkLabel
    Friend WithEvents PictureBoxCofR As System.Windows.Forms.PictureBox
    Friend WithEvents LinkLabelPaR As System.Windows.Forms.LinkLabel
    Friend WithEvents PictureBoxPaR As System.Windows.Forms.PictureBox
    Friend WithEvents LinkLabelmenuR As System.Windows.Forms.LinkLabel
    Friend WithEvents PictureBoxMenuR As System.Windows.Forms.PictureBox
    Friend WithEvents ButtonPasR As System.Windows.Forms.Button
    Friend WithEvents TextBoxPaR As System.Windows.Forms.TextBox
    Friend WithEvents DomainUpDownPaR As System.Windows.Forms.DomainUpDown
    Friend WithEvents ButtonBackRCust As System.Windows.Forms.Button
    Friend WithEvents ButtonBackRStaf As System.Windows.Forms.Button
    Friend WithEvents MenuStripFile As System.Windows.Forms.MenuStrip
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ContactToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitControlerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LogOutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpProvider1 As System.Windows.Forms.HelpProvider
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents DateTimePicker1 As System.Windows.Forms.DateTimePicker
End Class
