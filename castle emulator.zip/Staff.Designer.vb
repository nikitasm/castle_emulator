﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormStaff
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormStaff))
        Me.ButtonSave = New System.Windows.Forms.Button()
        Me.TextBoxid = New System.Windows.Forms.TextBox()
        Me.Labelid = New System.Windows.Forms.Label()
        Me.Labelroom = New System.Windows.Forms.Label()
        Me.Labelsex = New System.Windows.Forms.Label()
        Me.TextBoxroom = New System.Windows.Forms.TextBox()
        Me.Labelpassword = New System.Windows.Forms.Label()
        Me.TextBoxpassword = New System.Windows.Forms.TextBox()
        Me.Labelsurname = New System.Windows.Forms.Label()
        Me.TextBoxsurname = New System.Windows.Forms.TextBox()
        Me.Labelusername = New System.Windows.Forms.Label()
        Me.TextBoxusername = New System.Windows.Forms.TextBox()
        Me.Labelname = New System.Windows.Forms.Label()
        Me.TextBoxname = New System.Windows.Forms.TextBox()
        Me.Labeltype = New System.Windows.Forms.Label()
        Me.ButtonLogoutSt = New System.Windows.Forms.Button()
        Me.DomainUpDownsex = New System.Windows.Forms.DomainUpDown()
        Me.DomainUpDowntype = New System.Windows.Forms.DomainUpDown()
        Me.TextBoxsex = New System.Windows.Forms.TextBox()
        Me.TextBoxtype = New System.Windows.Forms.TextBox()
        Me.DataGridViewSA = New System.Windows.Forms.DataGridView()
        Me.ButtonSA = New System.Windows.Forms.Button()
        Me.LabelSWK = New System.Windows.Forms.Label()
        Me.TextBoxSW = New System.Windows.Forms.TextBox()
        Me.LabelMaleSW = New System.Windows.Forms.Label()
        Me.LabelFemaleSW = New System.Windows.Forms.Label()
        Me.LabelSWP = New System.Windows.Forms.Label()
        Me.LinkLabelSW = New System.Windows.Forms.LinkLabel()
        Me.ButtonDelete = New System.Windows.Forms.Button()
        Me.TextBoxQuery = New System.Windows.Forms.TextBox()
        Me.PictureBoxSWK = New System.Windows.Forms.PictureBox()
        Me.PictureBoxSWP = New System.Windows.Forms.PictureBox()
        Me.TextBoxDeleteId = New System.Windows.Forms.TextBox()
        Me.LabelDel = New System.Windows.Forms.Label()
        Me.LinkLabelContCB = New System.Windows.Forms.LinkLabel()
        Me.MenuStripFile = New System.Windows.Forms.MenuStrip()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ContactToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LogOutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitControlerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LinkLabelContRest = New System.Windows.Forms.LinkLabel()
        Me.LinkLabelContRoom = New System.Windows.Forms.LinkLabel()
        Me.HelpProvider1 = New System.Windows.Forms.HelpProvider()
        Me.LinkLabelStaffMap = New System.Windows.Forms.LinkLabel()
        Me.TextBoxRo = New System.Windows.Forms.TextBox()
        Me.LabelRo = New System.Windows.Forms.Label()
        Me.ButtonRo = New System.Windows.Forms.Button()
        CType(Me.DataGridViewSA, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxSWK, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxSWP, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStripFile.SuspendLayout()
        Me.SuspendLayout()
        '
        'ButtonSave
        '
        Me.ButtonSave.Location = New System.Drawing.Point(135, 418)
        Me.ButtonSave.Name = "ButtonSave"
        Me.ButtonSave.Size = New System.Drawing.Size(79, 19)
        Me.ButtonSave.TabIndex = 11
        Me.ButtonSave.Text = "Save"
        Me.ButtonSave.UseVisualStyleBackColor = True
        '
        'TextBoxid
        '
        Me.TextBoxid.Location = New System.Drawing.Point(91, 178)
        Me.TextBoxid.Name = "TextBoxid"
        Me.TextBoxid.Size = New System.Drawing.Size(111, 20)
        Me.TextBoxid.TabIndex = 1
        '
        'Labelid
        '
        Me.Labelid.AutoSize = True
        Me.Labelid.Location = New System.Drawing.Point(26, 181)
        Me.Labelid.Name = "Labelid"
        Me.Labelid.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Labelid.Size = New System.Drawing.Size(15, 13)
        Me.Labelid.TabIndex = 2
        Me.Labelid.Text = "id"
        '
        'Labelroom
        '
        Me.Labelroom.AutoSize = True
        Me.Labelroom.Location = New System.Drawing.Point(393, 233)
        Me.Labelroom.Name = "Labelroom"
        Me.Labelroom.Size = New System.Drawing.Size(30, 13)
        Me.Labelroom.TabIndex = 4
        Me.Labelroom.Text = "room"
        '
        'Labelsex
        '
        Me.Labelsex.AutoSize = True
        Me.Labelsex.Location = New System.Drawing.Point(393, 207)
        Me.Labelsex.Name = "Labelsex"
        Me.Labelsex.Size = New System.Drawing.Size(23, 13)
        Me.Labelsex.TabIndex = 6
        Me.Labelsex.Text = "sex"
        '
        'TextBoxroom
        '
        Me.TextBoxroom.Location = New System.Drawing.Point(445, 230)
        Me.TextBoxroom.Name = "TextBoxroom"
        Me.TextBoxroom.Size = New System.Drawing.Size(111, 20)
        Me.TextBoxroom.TabIndex = 7
        '
        'Labelpassword
        '
        Me.Labelpassword.AutoSize = True
        Me.Labelpassword.Location = New System.Drawing.Point(389, 184)
        Me.Labelpassword.Name = "Labelpassword"
        Me.Labelpassword.Size = New System.Drawing.Size(52, 13)
        Me.Labelpassword.TabIndex = 8
        Me.Labelpassword.Text = "password"
        '
        'TextBoxpassword
        '
        Me.TextBoxpassword.Location = New System.Drawing.Point(445, 180)
        Me.TextBoxpassword.Name = "TextBoxpassword"
        Me.TextBoxpassword.Size = New System.Drawing.Size(111, 20)
        Me.TextBoxpassword.TabIndex = 5
        '
        'Labelsurname
        '
        Me.Labelsurname.AutoSize = True
        Me.Labelsurname.Location = New System.Drawing.Point(26, 256)
        Me.Labelsurname.Name = "Labelsurname"
        Me.Labelsurname.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Labelsurname.Size = New System.Drawing.Size(47, 13)
        Me.Labelsurname.TabIndex = 10
        Me.Labelsurname.Text = "surname"
        '
        'TextBoxsurname
        '
        Me.TextBoxsurname.Location = New System.Drawing.Point(91, 253)
        Me.TextBoxsurname.Name = "TextBoxsurname"
        Me.TextBoxsurname.Size = New System.Drawing.Size(111, 20)
        Me.TextBoxsurname.TabIndex = 4
        '
        'Labelusername
        '
        Me.Labelusername.AutoSize = True
        Me.Labelusername.Location = New System.Drawing.Point(26, 231)
        Me.Labelusername.Name = "Labelusername"
        Me.Labelusername.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Labelusername.Size = New System.Drawing.Size(53, 13)
        Me.Labelusername.TabIndex = 12
        Me.Labelusername.Text = "username"
        '
        'TextBoxusername
        '
        Me.TextBoxusername.Location = New System.Drawing.Point(91, 228)
        Me.TextBoxusername.Name = "TextBoxusername"
        Me.TextBoxusername.Size = New System.Drawing.Size(111, 20)
        Me.TextBoxusername.TabIndex = 3
        '
        'Labelname
        '
        Me.Labelname.AutoSize = True
        Me.Labelname.Location = New System.Drawing.Point(26, 205)
        Me.Labelname.Name = "Labelname"
        Me.Labelname.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Labelname.Size = New System.Drawing.Size(33, 13)
        Me.Labelname.TabIndex = 14
        Me.Labelname.Text = "name"
        '
        'TextBoxname
        '
        Me.TextBoxname.Location = New System.Drawing.Point(91, 202)
        Me.TextBoxname.Name = "TextBoxname"
        Me.TextBoxname.Size = New System.Drawing.Size(111, 20)
        Me.TextBoxname.TabIndex = 2
        '
        'Labeltype
        '
        Me.Labeltype.AutoSize = True
        Me.Labeltype.Location = New System.Drawing.Point(389, 255)
        Me.Labeltype.Name = "Labeltype"
        Me.Labeltype.Size = New System.Drawing.Size(27, 13)
        Me.Labeltype.TabIndex = 15
        Me.Labeltype.Text = "type"
        '
        'ButtonLogoutSt
        '
        Me.ButtonLogoutSt.Location = New System.Drawing.Point(484, 419)
        Me.ButtonLogoutSt.Name = "ButtonLogoutSt"
        Me.ButtonLogoutSt.Size = New System.Drawing.Size(88, 21)
        Me.ButtonLogoutSt.TabIndex = 13
        Me.ButtonLogoutSt.Text = "Log Out"
        Me.ButtonLogoutSt.UseVisualStyleBackColor = True
        '
        'DomainUpDownsex
        '
        Me.DomainUpDownsex.Items.Add("male")
        Me.DomainUpDownsex.Items.Add("female")
        Me.DomainUpDownsex.Location = New System.Drawing.Point(445, 205)
        Me.DomainUpDownsex.Name = "DomainUpDownsex"
        Me.DomainUpDownsex.ReadOnly = True
        Me.DomainUpDownsex.Size = New System.Drawing.Size(111, 20)
        Me.DomainUpDownsex.TabIndex = 6
        Me.DomainUpDownsex.Text = "<select sex>"
        '
        'DomainUpDowntype
        '
        Me.DomainUpDowntype.Items.Add("customer")
        Me.DomainUpDowntype.Items.Add("staff")
        Me.DomainUpDowntype.Location = New System.Drawing.Point(445, 255)
        Me.DomainUpDowntype.Name = "DomainUpDowntype"
        Me.DomainUpDowntype.ReadOnly = True
        Me.DomainUpDowntype.Size = New System.Drawing.Size(111, 20)
        Me.DomainUpDowntype.TabIndex = 8
        Me.DomainUpDowntype.Text = "<select type>"
        '
        'TextBoxsex
        '
        Me.TextBoxsex.Location = New System.Drawing.Point(529, 84)
        Me.TextBoxsex.Name = "TextBoxsex"
        Me.TextBoxsex.Size = New System.Drawing.Size(43, 20)
        Me.TextBoxsex.TabIndex = 19
        Me.TextBoxsex.Visible = False
        '
        'TextBoxtype
        '
        Me.TextBoxtype.Location = New System.Drawing.Point(529, 121)
        Me.TextBoxtype.Name = "TextBoxtype"
        Me.TextBoxtype.Size = New System.Drawing.Size(43, 20)
        Me.TextBoxtype.TabIndex = 20
        Me.TextBoxtype.Visible = False
        '
        'DataGridViewSA
        '
        Me.DataGridViewSA.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.DataGridViewSA.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.DataGridViewSA.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridViewSA.Location = New System.Drawing.Point(17, 286)
        Me.DataGridViewSA.Name = "DataGridViewSA"
        Me.DataGridViewSA.ReadOnly = True
        Me.DataGridViewSA.Size = New System.Drawing.Size(539, 87)
        Me.DataGridViewSA.TabIndex = 21
        '
        'ButtonSA
        '
        Me.ButtonSA.Location = New System.Drawing.Point(29, 418)
        Me.ButtonSA.Name = "ButtonSA"
        Me.ButtonSA.Size = New System.Drawing.Size(81, 20)
        Me.ButtonSA.TabIndex = 10
        Me.ButtonSA.Text = "Show All"
        Me.ButtonSA.UseVisualStyleBackColor = True
        '
        'LabelSWK
        '
        Me.LabelSWK.AutoSize = True
        Me.LabelSWK.BackColor = System.Drawing.Color.Transparent
        Me.LabelSWK.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LabelSWK.ForeColor = System.Drawing.Color.Navy
        Me.LabelSWK.Location = New System.Drawing.Point(220, 9)
        Me.LabelSWK.Name = "LabelSWK"
        Me.LabelSWK.Size = New System.Drawing.Size(280, 24)
        Me.LabelSWK.TabIndex = 23
        Me.LabelSWK.Text = "Welcome To Duty My Knight!"
        '
        'TextBoxSW
        '
        Me.TextBoxSW.Location = New System.Drawing.Point(529, 42)
        Me.TextBoxSW.Name = "TextBoxSW"
        Me.TextBoxSW.Size = New System.Drawing.Size(43, 20)
        Me.TextBoxSW.TabIndex = 25
        Me.TextBoxSW.Visible = False
        '
        'LabelMaleSW
        '
        Me.LabelMaleSW.Location = New System.Drawing.Point(482, 34)
        Me.LabelMaleSW.Name = "LabelMaleSW"
        Me.LabelMaleSW.Size = New System.Drawing.Size(41, 16)
        Me.LabelMaleSW.TabIndex = 26
        Me.LabelMaleSW.Text = "male"
        Me.LabelMaleSW.Visible = False
        '
        'LabelFemaleSW
        '
        Me.LabelFemaleSW.Location = New System.Drawing.Point(482, 50)
        Me.LabelFemaleSW.Name = "LabelFemaleSW"
        Me.LabelFemaleSW.Size = New System.Drawing.Size(41, 16)
        Me.LabelFemaleSW.TabIndex = 27
        Me.LabelFemaleSW.Text = "female"
        Me.LabelFemaleSW.Visible = False
        '
        'LabelSWP
        '
        Me.LabelSWP.AutoSize = True
        Me.LabelSWP.BackColor = System.Drawing.Color.Transparent
        Me.LabelSWP.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LabelSWP.ForeColor = System.Drawing.Color.Fuchsia
        Me.LabelSWP.Location = New System.Drawing.Point(222, 10)
        Me.LabelSWP.Name = "LabelSWP"
        Me.LabelSWP.Size = New System.Drawing.Size(301, 24)
        Me.LabelSWP.TabIndex = 28
        Me.LabelSWP.Text = "Welcome To Duty My Princess!"
        '
        'LinkLabelSW
        '
        Me.LinkLabelSW.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelSW.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelSW.LinkColor = System.Drawing.Color.Yellow
        Me.LinkLabelSW.Location = New System.Drawing.Point(77, 6)
        Me.LinkLabelSW.Name = "LinkLabelSW"
        Me.LinkLabelSW.Size = New System.Drawing.Size(449, 28)
        Me.LinkLabelSW.TabIndex = 151
        Me.LinkLabelSW.TabStop = True
        Me.LinkLabelSW.Text = "Hello!!!"
        Me.LinkLabelSW.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'ButtonDelete
        '
        Me.ButtonDelete.Location = New System.Drawing.Point(243, 418)
        Me.ButtonDelete.Name = "ButtonDelete"
        Me.ButtonDelete.Size = New System.Drawing.Size(91, 20)
        Me.ButtonDelete.TabIndex = 12
        Me.ButtonDelete.Text = "Delete"
        Me.ButtonDelete.UseVisualStyleBackColor = True
        '
        'TextBoxQuery
        '
        Me.TextBoxQuery.Location = New System.Drawing.Point(529, 158)
        Me.TextBoxQuery.Name = "TextBoxQuery"
        Me.TextBoxQuery.Size = New System.Drawing.Size(43, 20)
        Me.TextBoxQuery.TabIndex = 153
        Me.TextBoxQuery.Visible = False
        '
        'PictureBoxSWK
        '
        Me.PictureBoxSWK.BackColor = System.Drawing.Color.Transparent
        Me.PictureBoxSWK.BackgroundImage = CType(resources.GetObject("PictureBoxSWK.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxSWK.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxSWK.Location = New System.Drawing.Point(224, 152)
        Me.PictureBoxSWK.Name = "PictureBoxSWK"
        Me.PictureBoxSWK.Size = New System.Drawing.Size(142, 134)
        Me.PictureBoxSWK.TabIndex = 154
        Me.PictureBoxSWK.TabStop = False
        '
        'PictureBoxSWP
        '
        Me.PictureBoxSWP.BackColor = System.Drawing.Color.Transparent
        Me.PictureBoxSWP.BackgroundImage = CType(resources.GetObject("PictureBoxSWP.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxSWP.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxSWP.Location = New System.Drawing.Point(223, 154)
        Me.PictureBoxSWP.Name = "PictureBoxSWP"
        Me.PictureBoxSWP.Size = New System.Drawing.Size(142, 134)
        Me.PictureBoxSWP.TabIndex = 155
        Me.PictureBoxSWP.TabStop = False
        '
        'TextBoxDeleteId
        '
        Me.TextBoxDeleteId.Location = New System.Drawing.Point(243, 379)
        Me.TextBoxDeleteId.Name = "TextBoxDeleteId"
        Me.TextBoxDeleteId.Size = New System.Drawing.Size(94, 20)
        Me.TextBoxDeleteId.TabIndex = 9
        '
        'LabelDel
        '
        Me.LabelDel.AutoSize = True
        Me.LabelDel.Location = New System.Drawing.Point(185, 379)
        Me.LabelDel.Name = "LabelDel"
        Me.LabelDel.Size = New System.Drawing.Size(52, 13)
        Me.LabelDel.TabIndex = 159
        Me.LabelDel.Text = "Delete ID"
        '
        'LinkLabelContCB
        '
        Me.LinkLabelContCB.AutoSize = True
        Me.LinkLabelContCB.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelContCB.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelContCB.LinkColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.LinkLabelContCB.Location = New System.Drawing.Point(11, 33)
        Me.LinkLabelContCB.Name = "LinkLabelContCB"
        Me.LinkLabelContCB.Size = New System.Drawing.Size(142, 20)
        Me.LinkLabelContCB.TabIndex = 160
        Me.LinkLabelContCB.TabStop = True
        Me.LinkLabelContCB.Text = "Coffee-Bar Control"
        '
        'MenuStripFile
        '
        Me.MenuStripFile.BackColor = System.Drawing.Color.Transparent
        Me.MenuStripFile.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.MenuStripFile.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem1})
        Me.MenuStripFile.Location = New System.Drawing.Point(0, 0)
        Me.MenuStripFile.Name = "MenuStripFile"
        Me.MenuStripFile.ShowItemToolTips = True
        Me.MenuStripFile.Size = New System.Drawing.Size(584, 24)
        Me.MenuStripFile.TabIndex = 161
        Me.MenuStripFile.Text = "MenuStrip1"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ContactToolStripMenuItem, Me.HelpToolStripMenuItem, Me.AboutToolStripMenuItem, Me.LogOutToolStripMenuItem, Me.ExitControlerToolStripMenuItem})
        Me.ToolStripMenuItem1.ForeColor = System.Drawing.Color.Coral
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(37, 20)
        Me.ToolStripMenuItem1.Text = "File"
        '
        'ContactToolStripMenuItem
        '
        Me.ContactToolStripMenuItem.Name = "ContactToolStripMenuItem"
        Me.ContactToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.ContactToolStripMenuItem.Text = "Contact"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.AboutToolStripMenuItem.Text = "About"
        '
        'LogOutToolStripMenuItem
        '
        Me.LogOutToolStripMenuItem.Name = "LogOutToolStripMenuItem"
        Me.LogOutToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.LogOutToolStripMenuItem.Text = "Log Out"
        '
        'ExitControlerToolStripMenuItem
        '
        Me.ExitControlerToolStripMenuItem.Name = "ExitControlerToolStripMenuItem"
        Me.ExitControlerToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.ExitControlerToolStripMenuItem.Text = "Exit Controler"
        '
        'LinkLabelContRest
        '
        Me.LinkLabelContRest.AutoSize = True
        Me.LinkLabelContRest.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelContRest.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelContRest.LinkColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.LinkLabelContRest.Location = New System.Drawing.Point(11, 64)
        Me.LinkLabelContRest.Name = "LinkLabelContRest"
        Me.LinkLabelContRest.Size = New System.Drawing.Size(144, 20)
        Me.LinkLabelContRest.TabIndex = 162
        Me.LinkLabelContRest.TabStop = True
        Me.LinkLabelContRest.Text = "Restaurant Control"
        '
        'LinkLabelContRoom
        '
        Me.LinkLabelContRoom.AutoSize = True
        Me.LinkLabelContRoom.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelContRoom.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelContRoom.LinkColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.LinkLabelContRoom.Location = New System.Drawing.Point(12, 97)
        Me.LinkLabelContRoom.Name = "LinkLabelContRoom"
        Me.LinkLabelContRoom.Size = New System.Drawing.Size(107, 20)
        Me.LinkLabelContRoom.TabIndex = 163
        Me.LinkLabelContRoom.TabStop = True
        Me.LinkLabelContRoom.Text = "Room Control"
        '
        'HelpProvider1
        '
        Me.HelpProvider1.HelpNamespace = "C:\Users\Morpheus\Desktop\Dun.chm"
        '
        'LinkLabelStaffMap
        '
        Me.LinkLabelStaffMap.AutoSize = True
        Me.LinkLabelStaffMap.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelStaffMap.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelStaffMap.LinkColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.LinkLabelStaffMap.Location = New System.Drawing.Point(13, 121)
        Me.LinkLabelStaffMap.Name = "LinkLabelStaffMap"
        Me.LinkLabelStaffMap.Size = New System.Drawing.Size(89, 20)
        Me.LinkLabelStaffMap.TabIndex = 164
        Me.LinkLabelStaffMap.TabStop = True
        Me.LinkLabelStaffMap.Text = "Castle Map"
        '
        'TextBoxRo
        '
        Me.TextBoxRo.Location = New System.Drawing.Point(163, 99)
        Me.TextBoxRo.Name = "TextBoxRo"
        Me.TextBoxRo.Size = New System.Drawing.Size(65, 20)
        Me.TextBoxRo.TabIndex = 165
        Me.TextBoxRo.Visible = False
        '
        'LabelRo
        '
        Me.LabelRo.AutoSize = True
        Me.LabelRo.Location = New System.Drawing.Point(176, 86)
        Me.LabelRo.Name = "LabelRo"
        Me.LabelRo.Size = New System.Drawing.Size(64, 13)
        Me.LabelRo.TabIndex = 166
        Me.LabelRo.Text = "Insert Room"
        Me.LabelRo.Visible = False
        '
        'ButtonRo
        '
        Me.ButtonRo.Location = New System.Drawing.Point(241, 98)
        Me.ButtonRo.Name = "ButtonRo"
        Me.ButtonRo.Size = New System.Drawing.Size(33, 23)
        Me.ButtonRo.TabIndex = 167
        Me.ButtonRo.Text = "Go"
        Me.ButtonRo.UseVisualStyleBackColor = True
        Me.ButtonRo.Visible = False
        '
        'FormStaff
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(584, 452)
        Me.Controls.Add(Me.ButtonRo)
        Me.Controls.Add(Me.LabelRo)
        Me.Controls.Add(Me.TextBoxRo)
        Me.Controls.Add(Me.LinkLabelStaffMap)
        Me.Controls.Add(Me.LinkLabelContRoom)
        Me.Controls.Add(Me.LinkLabelContRest)
        Me.Controls.Add(Me.LinkLabelContCB)
        Me.Controls.Add(Me.LabelDel)
        Me.Controls.Add(Me.TextBoxDeleteId)
        Me.Controls.Add(Me.DataGridViewSA)
        Me.Controls.Add(Me.PictureBoxSWP)
        Me.Controls.Add(Me.PictureBoxSWK)
        Me.Controls.Add(Me.TextBoxQuery)
        Me.Controls.Add(Me.ButtonDelete)
        Me.Controls.Add(Me.LinkLabelSW)
        Me.Controls.Add(Me.LabelSWP)
        Me.Controls.Add(Me.LabelFemaleSW)
        Me.Controls.Add(Me.LabelMaleSW)
        Me.Controls.Add(Me.TextBoxSW)
        Me.Controls.Add(Me.LabelSWK)
        Me.Controls.Add(Me.ButtonSA)
        Me.Controls.Add(Me.TextBoxtype)
        Me.Controls.Add(Me.TextBoxsex)
        Me.Controls.Add(Me.DomainUpDowntype)
        Me.Controls.Add(Me.DomainUpDownsex)
        Me.Controls.Add(Me.ButtonLogoutSt)
        Me.Controls.Add(Me.Labeltype)
        Me.Controls.Add(Me.Labelname)
        Me.Controls.Add(Me.TextBoxname)
        Me.Controls.Add(Me.Labelusername)
        Me.Controls.Add(Me.TextBoxusername)
        Me.Controls.Add(Me.Labelsurname)
        Me.Controls.Add(Me.TextBoxsurname)
        Me.Controls.Add(Me.Labelpassword)
        Me.Controls.Add(Me.TextBoxpassword)
        Me.Controls.Add(Me.Labelsex)
        Me.Controls.Add(Me.TextBoxroom)
        Me.Controls.Add(Me.Labelroom)
        Me.Controls.Add(Me.Labelid)
        Me.Controls.Add(Me.TextBoxid)
        Me.Controls.Add(Me.ButtonSave)
        Me.Controls.Add(Me.MenuStripFile)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "FormStaff"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Staff "
        CType(Me.DataGridViewSA, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxSWK, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxSWP, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStripFile.ResumeLayout(False)
        Me.MenuStripFile.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ButtonSave As System.Windows.Forms.Button
    Friend WithEvents TextBoxid As System.Windows.Forms.TextBox
    Friend WithEvents Labelid As System.Windows.Forms.Label
    Friend WithEvents Labelroom As System.Windows.Forms.Label
    Friend WithEvents Labelsex As System.Windows.Forms.Label
    Friend WithEvents TextBoxroom As System.Windows.Forms.TextBox
    Friend WithEvents Labelpassword As System.Windows.Forms.Label
    Friend WithEvents TextBoxpassword As System.Windows.Forms.TextBox
    Friend WithEvents Labelsurname As System.Windows.Forms.Label
    Friend WithEvents TextBoxsurname As System.Windows.Forms.TextBox
    Friend WithEvents Labelusername As System.Windows.Forms.Label
    Friend WithEvents TextBoxusername As System.Windows.Forms.TextBox
    Friend WithEvents Labelname As System.Windows.Forms.Label
    Friend WithEvents TextBoxname As System.Windows.Forms.TextBox
    Friend WithEvents Labeltype As System.Windows.Forms.Label
    Friend WithEvents ButtonLogoutSt As System.Windows.Forms.Button
    Friend WithEvents DomainUpDownsex As System.Windows.Forms.DomainUpDown
    Friend WithEvents DomainUpDowntype As System.Windows.Forms.DomainUpDown
    Friend WithEvents TextBoxsex As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxtype As System.Windows.Forms.TextBox
    Friend WithEvents DataGridViewSA As System.Windows.Forms.DataGridView
    Friend WithEvents ButtonSA As System.Windows.Forms.Button
    Friend WithEvents LabelSWK As System.Windows.Forms.Label
    Friend WithEvents TextBoxSW As System.Windows.Forms.TextBox
    Friend WithEvents LabelMaleSW As System.Windows.Forms.Label
    Friend WithEvents LabelFemaleSW As System.Windows.Forms.Label
    Friend WithEvents LabelSWP As System.Windows.Forms.Label
    Friend WithEvents LinkLabelSW As System.Windows.Forms.LinkLabel
    Friend WithEvents ButtonDelete As System.Windows.Forms.Button
    Friend WithEvents TextBoxQuery As System.Windows.Forms.TextBox
    Friend WithEvents PictureBoxSWK As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBoxSWP As System.Windows.Forms.PictureBox
    Friend WithEvents TextBoxDeleteId As System.Windows.Forms.TextBox
    Friend WithEvents LabelDel As System.Windows.Forms.Label
    Friend WithEvents LinkLabelContCB As System.Windows.Forms.LinkLabel
    Friend WithEvents MenuStripFile As System.Windows.Forms.MenuStrip
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ContactToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitControlerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LinkLabelContRest As System.Windows.Forms.LinkLabel
    Friend WithEvents LinkLabelContRoom As System.Windows.Forms.LinkLabel
    Friend WithEvents LogOutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpProvider1 As System.Windows.Forms.HelpProvider
    Friend WithEvents LinkLabelStaffMap As System.Windows.Forms.LinkLabel
    Friend WithEvents TextBoxRo As System.Windows.Forms.TextBox
    Friend WithEvents LabelRo As System.Windows.Forms.Label
    Friend WithEvents ButtonRo As System.Windows.Forms.Button
End Class
