﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormSecBedroom
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormSecBedroom))
        Me.ButtonBackS = New System.Windows.Forms.Button()
        Me.MenuStripFile = New System.Windows.Forms.MenuStrip()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ContactToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LogOutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitControlerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DomainUpDownSLSB = New System.Windows.Forms.DomainUpDown()
        Me.LinkLabelTVSB = New System.Windows.Forms.LinkLabel()
        Me.LinkLabelSeclightsSB = New System.Windows.Forms.LinkLabel()
        Me.PictureBoxSeclightsSB = New System.Windows.Forms.PictureBox()
        Me.PictureBoxTVSB = New System.Windows.Forms.PictureBox()
        Me.DomainUpDownSSSB = New System.Windows.Forms.DomainUpDown()
        Me.NumericUpDownASB = New System.Windows.Forms.NumericUpDown()
        Me.LabelTempASB = New System.Windows.Forms.Label()
        Me.LinkLabelAirSB = New System.Windows.Forms.LinkLabel()
        Me.PictureBoxAirSB = New System.Windows.Forms.PictureBox()
        Me.LinkLabelSSSB = New System.Windows.Forms.LinkLabel()
        Me.LinkLabelMainLightsSB = New System.Windows.Forms.LinkLabel()
        Me.PictureBoxMainLightsSB = New System.Windows.Forms.PictureBox()
        Me.PictureBoxSSSB = New System.Windows.Forms.PictureBox()
        Me.LinkLabelFPSB = New System.Windows.Forms.LinkLabel()
        Me.DomainUpDownFPSB = New System.Windows.Forms.DomainUpDown()
        Me.PictureBoxFPSB = New System.Windows.Forms.PictureBox()
        Me.DomainUpDownMLSB = New System.Windows.Forms.DomainUpDown()
        Me.DomainUpDownTVSB = New System.Windows.Forms.DomainUpDown()
        Me.HelpProvider1 = New System.Windows.Forms.HelpProvider()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.MenuStripFile.SuspendLayout()
        CType(Me.PictureBoxSeclightsSB, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxTVSB, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDownASB, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxAirSB, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxMainLightsSB, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxSSSB, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxFPSB, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ButtonBackS
        '
        Me.ButtonBackS.Location = New System.Drawing.Point(451, 399)
        Me.ButtonBackS.Name = "ButtonBackS"
        Me.ButtonBackS.Size = New System.Drawing.Size(110, 25)
        Me.ButtonBackS.TabIndex = 17
        Me.ButtonBackS.Text = "Back"
        Me.ButtonBackS.UseVisualStyleBackColor = True
        '
        'MenuStripFile
        '
        Me.MenuStripFile.BackColor = System.Drawing.Color.Transparent
        Me.MenuStripFile.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.MenuStripFile.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem1})
        Me.MenuStripFile.Location = New System.Drawing.Point(0, 0)
        Me.MenuStripFile.Name = "MenuStripFile"
        Me.MenuStripFile.ShowItemToolTips = True
        Me.MenuStripFile.Size = New System.Drawing.Size(584, 24)
        Me.MenuStripFile.TabIndex = 18
        Me.MenuStripFile.Text = "MenuStrip1"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ContactToolStripMenuItem, Me.HelpToolStripMenuItem, Me.AboutToolStripMenuItem, Me.LogOutToolStripMenuItem, Me.ExitControlerToolStripMenuItem})
        Me.ToolStripMenuItem1.ForeColor = System.Drawing.Color.Coral
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(37, 20)
        Me.ToolStripMenuItem1.Text = "File"
        '
        'ContactToolStripMenuItem
        '
        Me.ContactToolStripMenuItem.Name = "ContactToolStripMenuItem"
        Me.ContactToolStripMenuItem.Size = New System.Drawing.Size(145, 22)
        Me.ContactToolStripMenuItem.Text = "Contact"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(145, 22)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(145, 22)
        Me.AboutToolStripMenuItem.Text = "About"
        '
        'LogOutToolStripMenuItem
        '
        Me.LogOutToolStripMenuItem.Name = "LogOutToolStripMenuItem"
        Me.LogOutToolStripMenuItem.Size = New System.Drawing.Size(145, 22)
        Me.LogOutToolStripMenuItem.Text = "Log Out"
        '
        'ExitControlerToolStripMenuItem
        '
        Me.ExitControlerToolStripMenuItem.Name = "ExitControlerToolStripMenuItem"
        Me.ExitControlerToolStripMenuItem.Size = New System.Drawing.Size(145, 22)
        Me.ExitControlerToolStripMenuItem.Text = "Exit Controler"
        '
        'DomainUpDownSLSB
        '
        Me.DomainUpDownSLSB.Items.Add("ON")
        Me.DomainUpDownSLSB.Items.Add("OFF")
        Me.DomainUpDownSLSB.Location = New System.Drawing.Point(311, 289)
        Me.DomainUpDownSLSB.Name = "DomainUpDownSLSB"
        Me.DomainUpDownSLSB.ReadOnly = True
        Me.DomainUpDownSLSB.Size = New System.Drawing.Size(61, 20)
        Me.DomainUpDownSLSB.TabIndex = 115
        Me.DomainUpDownSLSB.Text = "ON/OFF"
        '
        'LinkLabelTVSB
        '
        Me.LinkLabelTVSB.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelTVSB.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelTVSB.LinkColor = System.Drawing.Color.White
        Me.LinkLabelTVSB.Location = New System.Drawing.Point(460, 267)
        Me.LinkLabelTVSB.Name = "LinkLabelTVSB"
        Me.LinkLabelTVSB.Size = New System.Drawing.Size(101, 93)
        Me.LinkLabelTVSB.TabIndex = 114
        Me.LinkLabelTVSB.TabStop = True
        Me.LinkLabelTVSB.Text = "TV"
        Me.LinkLabelTVSB.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'LinkLabelSeclightsSB
        '
        Me.LinkLabelSeclightsSB.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelSeclightsSB.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelSeclightsSB.LinkColor = System.Drawing.Color.White
        Me.LinkLabelSeclightsSB.Location = New System.Drawing.Point(368, 221)
        Me.LinkLabelSeclightsSB.Name = "LinkLabelSeclightsSB"
        Me.LinkLabelSeclightsSB.Size = New System.Drawing.Size(102, 139)
        Me.LinkLabelSeclightsSB.TabIndex = 111
        Me.LinkLabelSeclightsSB.TabStop = True
        Me.LinkLabelSeclightsSB.Text = "Sec Lights"
        Me.LinkLabelSeclightsSB.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'PictureBoxSeclightsSB
        '
        Me.PictureBoxSeclightsSB.BackColor = System.Drawing.Color.Transparent
        Me.PictureBoxSeclightsSB.BackgroundImage = CType(resources.GetObject("PictureBoxSeclightsSB.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxSeclightsSB.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxSeclightsSB.Location = New System.Drawing.Point(373, 230)
        Me.PictureBoxSeclightsSB.Name = "PictureBoxSeclightsSB"
        Me.PictureBoxSeclightsSB.Size = New System.Drawing.Size(80, 130)
        Me.PictureBoxSeclightsSB.TabIndex = 112
        Me.PictureBoxSeclightsSB.TabStop = False
        '
        'PictureBoxTVSB
        '
        Me.PictureBoxTVSB.BackgroundImage = CType(resources.GetObject("PictureBoxTVSB.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxTVSB.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxTVSB.Location = New System.Drawing.Point(461, 298)
        Me.PictureBoxTVSB.Name = "PictureBoxTVSB"
        Me.PictureBoxTVSB.Size = New System.Drawing.Size(100, 62)
        Me.PictureBoxTVSB.TabIndex = 113
        Me.PictureBoxTVSB.TabStop = False
        '
        'DomainUpDownSSSB
        '
        Me.DomainUpDownSSSB.Items.Add("ON")
        Me.DomainUpDownSSSB.Items.Add("OFF")
        Me.DomainUpDownSSSB.Location = New System.Drawing.Point(157, 238)
        Me.DomainUpDownSSSB.Name = "DomainUpDownSSSB"
        Me.DomainUpDownSSSB.ReadOnly = True
        Me.DomainUpDownSSSB.Size = New System.Drawing.Size(61, 20)
        Me.DomainUpDownSSSB.TabIndex = 124
        Me.DomainUpDownSSSB.Text = "ON/OFF"
        '
        'NumericUpDownASB
        '
        Me.NumericUpDownASB.Location = New System.Drawing.Point(374, 44)
        Me.NumericUpDownASB.Maximum = New Decimal(New Integer() {28, 0, 0, 0})
        Me.NumericUpDownASB.Minimum = New Decimal(New Integer() {16, 0, 0, 0})
        Me.NumericUpDownASB.Name = "NumericUpDownASB"
        Me.NumericUpDownASB.ReadOnly = True
        Me.NumericUpDownASB.Size = New System.Drawing.Size(67, 20)
        Me.NumericUpDownASB.TabIndex = 122
        Me.NumericUpDownASB.Value = New Decimal(New Integer() {16, 0, 0, 0})
        Me.NumericUpDownASB.Visible = False
        '
        'LabelTempASB
        '
        Me.LabelTempASB.AutoSize = True
        Me.LabelTempASB.Location = New System.Drawing.Point(375, 29)
        Me.LabelTempASB.Name = "LabelTempASB"
        Me.LabelTempASB.Size = New System.Drawing.Size(48, 13)
        Me.LabelTempASB.TabIndex = 123
        Me.LabelTempASB.Text = "Temp °C"
        Me.LabelTempASB.Visible = False
        '
        'LinkLabelAirSB
        '
        Me.LinkLabelAirSB.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelAirSB.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelAirSB.LinkColor = System.Drawing.Color.White
        Me.LinkLabelAirSB.Location = New System.Drawing.Point(250, 22)
        Me.LinkLabelAirSB.Name = "LinkLabelAirSB"
        Me.LinkLabelAirSB.Size = New System.Drawing.Size(122, 63)
        Me.LinkLabelAirSB.TabIndex = 121
        Me.LinkLabelAirSB.TabStop = True
        Me.LinkLabelAirSB.Text = "Air"
        Me.LinkLabelAirSB.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PictureBoxAirSB
        '
        Me.PictureBoxAirSB.BackgroundImage = CType(resources.GetObject("PictureBoxAirSB.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxAirSB.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxAirSB.Location = New System.Drawing.Point(250, 33)
        Me.PictureBoxAirSB.Name = "PictureBoxAirSB"
        Me.PictureBoxAirSB.Size = New System.Drawing.Size(122, 52)
        Me.PictureBoxAirSB.TabIndex = 120
        Me.PictureBoxAirSB.TabStop = False
        '
        'LinkLabelSSSB
        '
        Me.LinkLabelSSSB.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelSSSB.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelSSSB.LinkColor = System.Drawing.Color.White
        Me.LinkLabelSSSB.Location = New System.Drawing.Point(53, 177)
        Me.LinkLabelSSSB.Name = "LinkLabelSSSB"
        Me.LinkLabelSSSB.Size = New System.Drawing.Size(102, 81)
        Me.LinkLabelSSSB.TabIndex = 119
        Me.LinkLabelSSSB.TabStop = True
        Me.LinkLabelSSSB.Text = "Stereo"
        Me.LinkLabelSSSB.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'LinkLabelMainLightsSB
        '
        Me.LinkLabelMainLightsSB.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelMainLightsSB.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelMainLightsSB.LinkColor = System.Drawing.Color.Yellow
        Me.LinkLabelMainLightsSB.Location = New System.Drawing.Point(67, 0)
        Me.LinkLabelMainLightsSB.Name = "LinkLabelMainLightsSB"
        Me.LinkLabelMainLightsSB.Size = New System.Drawing.Size(151, 97)
        Me.LinkLabelMainLightsSB.TabIndex = 117
        Me.LinkLabelMainLightsSB.TabStop = True
        Me.LinkLabelMainLightsSB.Text = "Main Lights"
        Me.LinkLabelMainLightsSB.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PictureBoxMainLightsSB
        '
        Me.PictureBoxMainLightsSB.BackColor = System.Drawing.Color.Transparent
        Me.PictureBoxMainLightsSB.BackgroundImage = CType(resources.GetObject("PictureBoxMainLightsSB.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxMainLightsSB.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxMainLightsSB.Location = New System.Drawing.Point(72, 0)
        Me.PictureBoxMainLightsSB.Name = "PictureBoxMainLightsSB"
        Me.PictureBoxMainLightsSB.Size = New System.Drawing.Size(146, 94)
        Me.PictureBoxMainLightsSB.TabIndex = 116
        Me.PictureBoxMainLightsSB.TabStop = False
        '
        'PictureBoxSSSB
        '
        Me.PictureBoxSSSB.BackgroundImage = CType(resources.GetObject("PictureBoxSSSB.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxSSSB.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxSSSB.Location = New System.Drawing.Point(57, 208)
        Me.PictureBoxSSSB.Name = "PictureBoxSSSB"
        Me.PictureBoxSSSB.Size = New System.Drawing.Size(98, 50)
        Me.PictureBoxSSSB.TabIndex = 118
        Me.PictureBoxSSSB.TabStop = False
        '
        'LinkLabelFPSB
        '
        Me.LinkLabelFPSB.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelFPSB.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelFPSB.LinkColor = System.Drawing.Color.White
        Me.LinkLabelFPSB.Location = New System.Drawing.Point(4, 261)
        Me.LinkLabelFPSB.Name = "LinkLabelFPSB"
        Me.LinkLabelFPSB.Size = New System.Drawing.Size(134, 102)
        Me.LinkLabelFPSB.TabIndex = 127
        Me.LinkLabelFPSB.TabStop = True
        Me.LinkLabelFPSB.Text = "Fire Place"
        Me.LinkLabelFPSB.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'DomainUpDownFPSB
        '
        Me.DomainUpDownFPSB.Items.Add("ON")
        Me.DomainUpDownFPSB.Items.Add("OFF")
        Me.DomainUpDownFPSB.Location = New System.Drawing.Point(142, 305)
        Me.DomainUpDownFPSB.Name = "DomainUpDownFPSB"
        Me.DomainUpDownFPSB.ReadOnly = True
        Me.DomainUpDownFPSB.Size = New System.Drawing.Size(61, 20)
        Me.DomainUpDownFPSB.TabIndex = 126
        Me.DomainUpDownFPSB.Text = "ON/OFF"
        '
        'PictureBoxFPSB
        '
        Me.PictureBoxFPSB.BackgroundImage = CType(resources.GetObject("PictureBoxFPSB.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxFPSB.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxFPSB.Location = New System.Drawing.Point(4, 289)
        Me.PictureBoxFPSB.Name = "PictureBoxFPSB"
        Me.PictureBoxFPSB.Size = New System.Drawing.Size(134, 74)
        Me.PictureBoxFPSB.TabIndex = 125
        Me.PictureBoxFPSB.TabStop = False
        '
        'DomainUpDownMLSB
        '
        Me.DomainUpDownMLSB.Items.Add("ON")
        Me.DomainUpDownMLSB.Items.Add("OFF")
        Me.DomainUpDownMLSB.Location = New System.Drawing.Point(178, 100)
        Me.DomainUpDownMLSB.Name = "DomainUpDownMLSB"
        Me.DomainUpDownMLSB.ReadOnly = True
        Me.DomainUpDownMLSB.Size = New System.Drawing.Size(65, 20)
        Me.DomainUpDownMLSB.TabIndex = 128
        Me.DomainUpDownMLSB.Text = "ON/OFF"
        '
        'DomainUpDownTVSB
        '
        Me.DomainUpDownTVSB.Items.Add("ON")
        Me.DomainUpDownTVSB.Items.Add("OFF")
        Me.DomainUpDownTVSB.Location = New System.Drawing.Point(451, 363)
        Me.DomainUpDownTVSB.Name = "DomainUpDownTVSB"
        Me.DomainUpDownTVSB.ReadOnly = True
        Me.DomainUpDownTVSB.Size = New System.Drawing.Size(61, 20)
        Me.DomainUpDownTVSB.TabIndex = 129
        Me.DomainUpDownTVSB.Text = "ON/OFF"
        '
        'HelpProvider1
        '
        Me.HelpProvider1.HelpNamespace = "C:\Users\Morpheus\Desktop\Dun.chm"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(4, 44)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(62, 20)
        Me.TextBox1.TabIndex = 151
        Me.TextBox1.Visible = False
        '
        'FormSecBedroom
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(584, 452)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.DomainUpDownTVSB)
        Me.Controls.Add(Me.DomainUpDownMLSB)
        Me.Controls.Add(Me.LinkLabelFPSB)
        Me.Controls.Add(Me.DomainUpDownFPSB)
        Me.Controls.Add(Me.PictureBoxFPSB)
        Me.Controls.Add(Me.DomainUpDownSSSB)
        Me.Controls.Add(Me.NumericUpDownASB)
        Me.Controls.Add(Me.LabelTempASB)
        Me.Controls.Add(Me.LinkLabelAirSB)
        Me.Controls.Add(Me.PictureBoxAirSB)
        Me.Controls.Add(Me.LinkLabelSSSB)
        Me.Controls.Add(Me.LinkLabelMainLightsSB)
        Me.Controls.Add(Me.PictureBoxMainLightsSB)
        Me.Controls.Add(Me.PictureBoxSSSB)
        Me.Controls.Add(Me.DomainUpDownSLSB)
        Me.Controls.Add(Me.LinkLabelTVSB)
        Me.Controls.Add(Me.LinkLabelSeclightsSB)
        Me.Controls.Add(Me.PictureBoxSeclightsSB)
        Me.Controls.Add(Me.PictureBoxTVSB)
        Me.Controls.Add(Me.MenuStripFile)
        Me.Controls.Add(Me.ButtonBackS)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "FormSecBedroom"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Sec Bedroom"
        Me.MenuStripFile.ResumeLayout(False)
        Me.MenuStripFile.PerformLayout()
        CType(Me.PictureBoxSeclightsSB, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxTVSB, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDownASB, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxAirSB, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxMainLightsSB, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxSSSB, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxFPSB, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ButtonBackS As System.Windows.Forms.Button
    Friend WithEvents MenuStripFile As System.Windows.Forms.MenuStrip
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ContactToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitControlerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DomainUpDownSLSB As System.Windows.Forms.DomainUpDown
    Friend WithEvents LinkLabelTVSB As System.Windows.Forms.LinkLabel
    Friend WithEvents LinkLabelSeclightsSB As System.Windows.Forms.LinkLabel
    Friend WithEvents PictureBoxSeclightsSB As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBoxTVSB As System.Windows.Forms.PictureBox
    Friend WithEvents DomainUpDownSSSB As System.Windows.Forms.DomainUpDown
    Friend WithEvents NumericUpDownASB As System.Windows.Forms.NumericUpDown
    Friend WithEvents LabelTempASB As System.Windows.Forms.Label
    Friend WithEvents LinkLabelAirSB As System.Windows.Forms.LinkLabel
    Friend WithEvents PictureBoxAirSB As System.Windows.Forms.PictureBox
    Friend WithEvents LinkLabelSSSB As System.Windows.Forms.LinkLabel
    Friend WithEvents LinkLabelMainLightsSB As System.Windows.Forms.LinkLabel
    Friend WithEvents PictureBoxMainLightsSB As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBoxSSSB As System.Windows.Forms.PictureBox
    Friend WithEvents LinkLabelFPSB As System.Windows.Forms.LinkLabel
    Friend WithEvents DomainUpDownFPSB As System.Windows.Forms.DomainUpDown
    Friend WithEvents PictureBoxFPSB As System.Windows.Forms.PictureBox
    Friend WithEvents DomainUpDownMLSB As System.Windows.Forms.DomainUpDown
    Friend WithEvents DomainUpDownTVSB As System.Windows.Forms.DomainUpDown
    Friend WithEvents LogOutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpProvider1 As System.Windows.Forms.HelpProvider
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
End Class
