﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormMoat
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormMoat))
        Me.ButtonBackM = New System.Windows.Forms.Button()
        Me.LabelTempWM = New System.Windows.Forms.Label()
        Me.NumericUpDownWM = New System.Windows.Forms.NumericUpDown()
        Me.LinkLabelWaterM = New System.Windows.Forms.LinkLabel()
        Me.PictureBoxWaterM = New System.Windows.Forms.PictureBox()
        Me.LinkLabelDM = New System.Windows.Forms.LinkLabel()
        Me.DomainUpDownDM = New System.Windows.Forms.DomainUpDown()
        Me.PictureBoxDM = New System.Windows.Forms.PictureBox()
        Me.DomainUpDownLM = New System.Windows.Forms.DomainUpDown()
        Me.LinkLabelLightsM = New System.Windows.Forms.LinkLabel()
        Me.PictureBoxLightsM = New System.Windows.Forms.PictureBox()
        Me.MenuStripFile = New System.Windows.Forms.MenuStrip()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ContactToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LogOutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitControlerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LabelLevelWM = New System.Windows.Forms.Label()
        Me.NumericUpDownLevelWM = New System.Windows.Forms.NumericUpDown()
        Me.DomainUpDownAlarmMnf = New System.Windows.Forms.DomainUpDown()
        Me.LinkLabelAlarmM = New System.Windows.Forms.LinkLabel()
        Me.PictureBoxAlarmM = New System.Windows.Forms.PictureBox()
        Me.HelpProvider1 = New System.Windows.Forms.HelpProvider()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.DomainUpDownAlarmM2 = New System.Windows.Forms.DomainUpDown()
        Me.TextBoxHuman = New System.Windows.Forms.TextBox()
        Me.DomainUpDownAlarmM3 = New System.Windows.Forms.DomainUpDown()
        Me.DomainUpDownAlarmM4 = New System.Windows.Forms.DomainUpDown()
        Me.DomainUpDownAlarmM1 = New System.Windows.Forms.DomainUpDown()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.ButtonBackMS = New System.Windows.Forms.Button()
        CType(Me.NumericUpDownWM, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxWaterM, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxDM, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxLightsM, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStripFile.SuspendLayout()
        CType(Me.NumericUpDownLevelWM, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxAlarmM, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ButtonBackM
        '
        Me.ButtonBackM.Location = New System.Drawing.Point(457, 407)
        Me.ButtonBackM.Name = "ButtonBackM"
        Me.ButtonBackM.Size = New System.Drawing.Size(110, 25)
        Me.ButtonBackM.TabIndex = 8
        Me.ButtonBackM.Text = "Back"
        Me.ButtonBackM.UseVisualStyleBackColor = True
        '
        'LabelTempWM
        '
        Me.LabelTempWM.AutoSize = True
        Me.LabelTempWM.Location = New System.Drawing.Point(53, 244)
        Me.LabelTempWM.Name = "LabelTempWM"
        Me.LabelTempWM.Size = New System.Drawing.Size(48, 13)
        Me.LabelTempWM.TabIndex = 153
        Me.LabelTempWM.Text = "Temp °C"
        Me.LabelTempWM.Visible = False
        '
        'NumericUpDownWM
        '
        Me.NumericUpDownWM.Increment = New Decimal(New Integer() {10, 0, 0, 0})
        Me.NumericUpDownWM.Location = New System.Drawing.Point(56, 260)
        Me.NumericUpDownWM.Maximum = New Decimal(New Integer() {90, 0, 0, 0})
        Me.NumericUpDownWM.Minimum = New Decimal(New Integer() {20, 0, 0, 0})
        Me.NumericUpDownWM.Name = "NumericUpDownWM"
        Me.NumericUpDownWM.ReadOnly = True
        Me.NumericUpDownWM.Size = New System.Drawing.Size(67, 20)
        Me.NumericUpDownWM.TabIndex = 152
        Me.NumericUpDownWM.Value = New Decimal(New Integer() {50, 0, 0, 0})
        Me.NumericUpDownWM.Visible = False
        '
        'LinkLabelWaterM
        '
        Me.LinkLabelWaterM.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelWaterM.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelWaterM.LinkColor = System.Drawing.Color.Blue
        Me.LinkLabelWaterM.Location = New System.Drawing.Point(7, 115)
        Me.LinkLabelWaterM.Name = "LinkLabelWaterM"
        Me.LinkLabelWaterM.Size = New System.Drawing.Size(176, 126)
        Me.LinkLabelWaterM.TabIndex = 151
        Me.LinkLabelWaterM.TabStop = True
        Me.LinkLabelWaterM.Text = "Water"
        Me.LinkLabelWaterM.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'PictureBoxWaterM
        '
        Me.PictureBoxWaterM.BackgroundImage = CType(resources.GetObject("PictureBoxWaterM.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxWaterM.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxWaterM.Location = New System.Drawing.Point(12, 137)
        Me.PictureBoxWaterM.Name = "PictureBoxWaterM"
        Me.PictureBoxWaterM.Size = New System.Drawing.Size(163, 104)
        Me.PictureBoxWaterM.TabIndex = 150
        Me.PictureBoxWaterM.TabStop = False
        '
        'LinkLabelDM
        '
        Me.LinkLabelDM.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelDM.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelDM.LinkColor = System.Drawing.Color.White
        Me.LinkLabelDM.Location = New System.Drawing.Point(377, 115)
        Me.LinkLabelDM.Name = "LinkLabelDM"
        Me.LinkLabelDM.Size = New System.Drawing.Size(190, 188)
        Me.LinkLabelDM.TabIndex = 156
        Me.LinkLabelDM.TabStop = True
        Me.LinkLabelDM.Text = "Draw Bridge"
        Me.LinkLabelDM.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'DomainUpDownDM
        '
        Me.DomainUpDownDM.Items.Add("UP")
        Me.DomainUpDownDM.Items.Add("DOWN")
        Me.DomainUpDownDM.Location = New System.Drawing.Point(441, 306)
        Me.DomainUpDownDM.Name = "DomainUpDownDM"
        Me.DomainUpDownDM.ReadOnly = True
        Me.DomainUpDownDM.Size = New System.Drawing.Size(78, 20)
        Me.DomainUpDownDM.TabIndex = 155
        Me.DomainUpDownDM.Text = "UP/DOWN"
        '
        'PictureBoxDM
        '
        Me.PictureBoxDM.BackgroundImage = CType(resources.GetObject("PictureBoxDM.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxDM.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxDM.InitialImage = CType(resources.GetObject("PictureBoxDM.InitialImage"), System.Drawing.Image)
        Me.PictureBoxDM.Location = New System.Drawing.Point(387, 143)
        Me.PictureBoxDM.Name = "PictureBoxDM"
        Me.PictureBoxDM.Size = New System.Drawing.Size(180, 160)
        Me.PictureBoxDM.TabIndex = 154
        Me.PictureBoxDM.TabStop = False
        Me.PictureBoxDM.WaitOnLoad = True
        '
        'DomainUpDownLM
        '
        Me.DomainUpDownLM.Items.Add("ON")
        Me.DomainUpDownLM.Items.Add("OFF")
        Me.DomainUpDownLM.Location = New System.Drawing.Point(267, 263)
        Me.DomainUpDownLM.Name = "DomainUpDownLM"
        Me.DomainUpDownLM.ReadOnly = True
        Me.DomainUpDownLM.Size = New System.Drawing.Size(61, 20)
        Me.DomainUpDownLM.TabIndex = 159
        Me.DomainUpDownLM.Text = "ON/OFF"
        '
        'LinkLabelLightsM
        '
        Me.LinkLabelLightsM.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelLightsM.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelLightsM.LinkColor = System.Drawing.Color.White
        Me.LinkLabelLightsM.Location = New System.Drawing.Point(219, 115)
        Me.LinkLabelLightsM.Name = "LinkLabelLightsM"
        Me.LinkLabelLightsM.Size = New System.Drawing.Size(162, 142)
        Me.LinkLabelLightsM.TabIndex = 157
        Me.LinkLabelLightsM.TabStop = True
        Me.LinkLabelLightsM.Text = "Lights"
        Me.LinkLabelLightsM.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'PictureBoxLightsM
        '
        Me.PictureBoxLightsM.BackColor = System.Drawing.Color.Transparent
        Me.PictureBoxLightsM.BackgroundImage = CType(resources.GetObject("PictureBoxLightsM.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxLightsM.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxLightsM.Location = New System.Drawing.Point(219, 143)
        Me.PictureBoxLightsM.Name = "PictureBoxLightsM"
        Me.PictureBoxLightsM.Size = New System.Drawing.Size(157, 114)
        Me.PictureBoxLightsM.TabIndex = 158
        Me.PictureBoxLightsM.TabStop = False
        '
        'MenuStripFile
        '
        Me.MenuStripFile.BackColor = System.Drawing.Color.Transparent
        Me.MenuStripFile.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.MenuStripFile.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem1})
        Me.MenuStripFile.Location = New System.Drawing.Point(0, 0)
        Me.MenuStripFile.Name = "MenuStripFile"
        Me.MenuStripFile.ShowItemToolTips = True
        Me.MenuStripFile.Size = New System.Drawing.Size(584, 24)
        Me.MenuStripFile.TabIndex = 160
        Me.MenuStripFile.Text = "MenuStrip1"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ContactToolStripMenuItem, Me.HelpToolStripMenuItem, Me.AboutToolStripMenuItem, Me.LogOutToolStripMenuItem, Me.ExitControlerToolStripMenuItem})
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(37, 20)
        Me.ToolStripMenuItem1.Text = "File"
        '
        'ContactToolStripMenuItem
        '
        Me.ContactToolStripMenuItem.Name = "ContactToolStripMenuItem"
        Me.ContactToolStripMenuItem.Size = New System.Drawing.Size(145, 22)
        Me.ContactToolStripMenuItem.Text = "Contact"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(145, 22)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(145, 22)
        Me.AboutToolStripMenuItem.Text = "About"
        '
        'LogOutToolStripMenuItem
        '
        Me.LogOutToolStripMenuItem.Name = "LogOutToolStripMenuItem"
        Me.LogOutToolStripMenuItem.Size = New System.Drawing.Size(145, 22)
        Me.LogOutToolStripMenuItem.Text = "Log Out"
        '
        'ExitControlerToolStripMenuItem
        '
        Me.ExitControlerToolStripMenuItem.Name = "ExitControlerToolStripMenuItem"
        Me.ExitControlerToolStripMenuItem.Size = New System.Drawing.Size(145, 22)
        Me.ExitControlerToolStripMenuItem.Text = "Exit Controler"
        '
        'LabelLevelWM
        '
        Me.LabelLevelWM.AutoSize = True
        Me.LabelLevelWM.Location = New System.Drawing.Point(53, 290)
        Me.LabelLevelWM.Name = "LabelLevelWM"
        Me.LabelLevelWM.Size = New System.Drawing.Size(53, 13)
        Me.LabelLevelWM.TabIndex = 162
        Me.LabelLevelWM.Text = "Level 4/4"
        Me.LabelLevelWM.Visible = False
        '
        'NumericUpDownLevelWM
        '
        Me.NumericUpDownLevelWM.Location = New System.Drawing.Point(56, 306)
        Me.NumericUpDownLevelWM.Maximum = New Decimal(New Integer() {4, 0, 0, 0})
        Me.NumericUpDownLevelWM.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDownLevelWM.Name = "NumericUpDownLevelWM"
        Me.NumericUpDownLevelWM.ReadOnly = True
        Me.NumericUpDownLevelWM.Size = New System.Drawing.Size(67, 20)
        Me.NumericUpDownLevelWM.TabIndex = 161
        Me.NumericUpDownLevelWM.Value = New Decimal(New Integer() {4, 0, 0, 0})
        Me.NumericUpDownLevelWM.Visible = False
        '
        'DomainUpDownAlarmMnf
        '
        Me.DomainUpDownAlarmMnf.Items.Add("ON")
        Me.DomainUpDownAlarmMnf.Items.Add("OFF")
        Me.DomainUpDownAlarmMnf.Location = New System.Drawing.Point(356, 407)
        Me.DomainUpDownAlarmMnf.Name = "DomainUpDownAlarmMnf"
        Me.DomainUpDownAlarmMnf.ReadOnly = True
        Me.DomainUpDownAlarmMnf.Size = New System.Drawing.Size(61, 20)
        Me.DomainUpDownAlarmMnf.TabIndex = 165
        Me.DomainUpDownAlarmMnf.Text = "ON/OFF"
        '
        'LinkLabelAlarmM
        '
        Me.LinkLabelAlarmM.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelAlarmM.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelAlarmM.LinkColor = System.Drawing.Color.White
        Me.LinkLabelAlarmM.Location = New System.Drawing.Point(242, 286)
        Me.LinkLabelAlarmM.Name = "LinkLabelAlarmM"
        Me.LinkLabelAlarmM.Size = New System.Drawing.Size(117, 122)
        Me.LinkLabelAlarmM.TabIndex = 163
        Me.LinkLabelAlarmM.TabStop = True
        Me.LinkLabelAlarmM.Text = "Alarm"
        Me.LinkLabelAlarmM.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'PictureBoxAlarmM
        '
        Me.PictureBoxAlarmM.BackgroundImage = CType(resources.GetObject("PictureBoxAlarmM.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxAlarmM.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxAlarmM.Location = New System.Drawing.Point(247, 335)
        Me.PictureBoxAlarmM.Name = "PictureBoxAlarmM"
        Me.PictureBoxAlarmM.Size = New System.Drawing.Size(90, 73)
        Me.PictureBoxAlarmM.TabIndex = 164
        Me.PictureBoxAlarmM.TabStop = False
        '
        'HelpProvider1
        '
        Me.HelpProvider1.HelpNamespace = "C:\Users\Morpheus\Desktop\Dun.chm"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(56, 332)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(62, 20)
        Me.TextBox1.TabIndex = 167
        Me.TextBox1.Visible = False
        '
        'DomainUpDownAlarmM2
        '
        Me.DomainUpDownAlarmM2.Items.Add("1")
        Me.DomainUpDownAlarmM2.Items.Add("2")
        Me.DomainUpDownAlarmM2.Items.Add("3")
        Me.DomainUpDownAlarmM2.Items.Add("4")
        Me.DomainUpDownAlarmM2.Items.Add("5")
        Me.DomainUpDownAlarmM2.Items.Add("6")
        Me.DomainUpDownAlarmM2.Items.Add("7")
        Me.DomainUpDownAlarmM2.Items.Add("8")
        Me.DomainUpDownAlarmM2.Items.Add("9")
        Me.DomainUpDownAlarmM2.Items.Add("0")
        Me.DomainUpDownAlarmM2.Location = New System.Drawing.Point(256, 407)
        Me.DomainUpDownAlarmM2.Name = "DomainUpDownAlarmM2"
        Me.DomainUpDownAlarmM2.ReadOnly = True
        Me.DomainUpDownAlarmM2.Size = New System.Drawing.Size(33, 20)
        Me.DomainUpDownAlarmM2.TabIndex = 169
        Me.DomainUpDownAlarmM2.Text = "#"
        '
        'TextBoxHuman
        '
        Me.TextBoxHuman.Location = New System.Drawing.Point(40, 407)
        Me.TextBoxHuman.Name = "TextBoxHuman"
        Me.TextBoxHuman.ReadOnly = True
        Me.TextBoxHuman.Size = New System.Drawing.Size(100, 20)
        Me.TextBoxHuman.TabIndex = 172
        '
        'DomainUpDownAlarmM3
        '
        Me.DomainUpDownAlarmM3.Items.Add("1")
        Me.DomainUpDownAlarmM3.Items.Add("2")
        Me.DomainUpDownAlarmM3.Items.Add("3")
        Me.DomainUpDownAlarmM3.Items.Add("4")
        Me.DomainUpDownAlarmM3.Items.Add("5")
        Me.DomainUpDownAlarmM3.Items.Add("6")
        Me.DomainUpDownAlarmM3.Items.Add("7")
        Me.DomainUpDownAlarmM3.Items.Add("8")
        Me.DomainUpDownAlarmM3.Items.Add("9")
        Me.DomainUpDownAlarmM3.Items.Add("0")
        Me.DomainUpDownAlarmM3.Location = New System.Drawing.Point(289, 407)
        Me.DomainUpDownAlarmM3.Name = "DomainUpDownAlarmM3"
        Me.DomainUpDownAlarmM3.ReadOnly = True
        Me.DomainUpDownAlarmM3.Size = New System.Drawing.Size(33, 20)
        Me.DomainUpDownAlarmM3.TabIndex = 173
        Me.DomainUpDownAlarmM3.Text = "#"
        '
        'DomainUpDownAlarmM4
        '
        Me.DomainUpDownAlarmM4.Items.Add("1")
        Me.DomainUpDownAlarmM4.Items.Add("2")
        Me.DomainUpDownAlarmM4.Items.Add("3")
        Me.DomainUpDownAlarmM4.Items.Add("4")
        Me.DomainUpDownAlarmM4.Items.Add("5")
        Me.DomainUpDownAlarmM4.Items.Add("6")
        Me.DomainUpDownAlarmM4.Items.Add("7")
        Me.DomainUpDownAlarmM4.Items.Add("8")
        Me.DomainUpDownAlarmM4.Items.Add("9")
        Me.DomainUpDownAlarmM4.Items.Add("0")
        Me.DomainUpDownAlarmM4.Location = New System.Drawing.Point(322, 407)
        Me.DomainUpDownAlarmM4.Name = "DomainUpDownAlarmM4"
        Me.DomainUpDownAlarmM4.ReadOnly = True
        Me.DomainUpDownAlarmM4.Size = New System.Drawing.Size(33, 20)
        Me.DomainUpDownAlarmM4.TabIndex = 174
        Me.DomainUpDownAlarmM4.Text = "#"
        '
        'DomainUpDownAlarmM1
        '
        Me.DomainUpDownAlarmM1.Items.Add("1")
        Me.DomainUpDownAlarmM1.Items.Add("2")
        Me.DomainUpDownAlarmM1.Items.Add("3")
        Me.DomainUpDownAlarmM1.Items.Add("4")
        Me.DomainUpDownAlarmM1.Items.Add("5")
        Me.DomainUpDownAlarmM1.Items.Add("6")
        Me.DomainUpDownAlarmM1.Items.Add("7")
        Me.DomainUpDownAlarmM1.Items.Add("8")
        Me.DomainUpDownAlarmM1.Items.Add("9")
        Me.DomainUpDownAlarmM1.Items.Add("0")
        Me.DomainUpDownAlarmM1.Location = New System.Drawing.Point(223, 407)
        Me.DomainUpDownAlarmM1.Name = "DomainUpDownAlarmM1"
        Me.DomainUpDownAlarmM1.ReadOnly = True
        Me.DomainUpDownAlarmM1.Size = New System.Drawing.Size(33, 20)
        Me.DomainUpDownAlarmM1.TabIndex = 175
        Me.DomainUpDownAlarmM1.Text = "#"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(31, 394)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(40, 13)
        Me.Label1.TabIndex = 176
        Me.Label1.Text = "Sensor"
        '
        'PictureBox2
        '
        Me.PictureBox2.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox2.BackgroundImage = CType(resources.GetObject("PictureBox2.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox2.Location = New System.Drawing.Point(161, 213)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(22, 44)
        Me.PictureBox2.TabIndex = 181
        Me.PictureBox2.TabStop = False
        Me.PictureBox2.Visible = False
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox1.BackgroundImage = CType(resources.GetObject("PictureBox1.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox1.Location = New System.Drawing.Point(344, 190)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(32, 67)
        Me.PictureBox1.TabIndex = 182
        Me.PictureBox1.TabStop = False
        Me.PictureBox1.Visible = False
        '
        'PictureBox3
        '
        Me.PictureBox3.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox3.BackgroundImage = CType(resources.GetObject("PictureBox3.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox3.Location = New System.Drawing.Point(551, 219)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(54, 107)
        Me.PictureBox3.TabIndex = 183
        Me.PictureBox3.TabStop = False
        Me.PictureBox3.Visible = False
        '
        'PictureBox4
        '
        Me.PictureBox4.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox4.BackgroundImage = CType(resources.GetObject("PictureBox4.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox4.Location = New System.Drawing.Point(2, 230)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(50, 82)
        Me.PictureBox4.TabIndex = 184
        Me.PictureBox4.TabStop = False
        Me.PictureBox4.Visible = False
        '
        'ButtonBackMS
        '
        Me.ButtonBackMS.Location = New System.Drawing.Point(457, 407)
        Me.ButtonBackMS.Name = "ButtonBackMS"
        Me.ButtonBackMS.Size = New System.Drawing.Size(110, 25)
        Me.ButtonBackMS.TabIndex = 185
        Me.ButtonBackMS.Text = "Back"
        Me.ButtonBackMS.UseVisualStyleBackColor = True
        '
        'FormMoat
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(584, 452)
        Me.Controls.Add(Me.PictureBox4)
        Me.Controls.Add(Me.PictureBox3)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.DomainUpDownAlarmM1)
        Me.Controls.Add(Me.DomainUpDownAlarmM4)
        Me.Controls.Add(Me.DomainUpDownAlarmM3)
        Me.Controls.Add(Me.TextBoxHuman)
        Me.Controls.Add(Me.DomainUpDownAlarmM2)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.DomainUpDownAlarmMnf)
        Me.Controls.Add(Me.LinkLabelAlarmM)
        Me.Controls.Add(Me.PictureBoxAlarmM)
        Me.Controls.Add(Me.LabelLevelWM)
        Me.Controls.Add(Me.NumericUpDownLevelWM)
        Me.Controls.Add(Me.MenuStripFile)
        Me.Controls.Add(Me.DomainUpDownLM)
        Me.Controls.Add(Me.LinkLabelLightsM)
        Me.Controls.Add(Me.PictureBoxLightsM)
        Me.Controls.Add(Me.LinkLabelDM)
        Me.Controls.Add(Me.DomainUpDownDM)
        Me.Controls.Add(Me.PictureBoxDM)
        Me.Controls.Add(Me.LabelTempWM)
        Me.Controls.Add(Me.NumericUpDownWM)
        Me.Controls.Add(Me.LinkLabelWaterM)
        Me.Controls.Add(Me.PictureBoxWaterM)
        Me.Controls.Add(Me.ButtonBackM)
        Me.Controls.Add(Me.ButtonBackMS)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "FormMoat"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "My Moat"
        CType(Me.NumericUpDownWM, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxWaterM, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxDM, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxLightsM, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStripFile.ResumeLayout(False)
        Me.MenuStripFile.PerformLayout()
        CType(Me.NumericUpDownLevelWM, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxAlarmM, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ButtonBackM As System.Windows.Forms.Button
    Friend WithEvents LabelTempWM As System.Windows.Forms.Label
    Friend WithEvents NumericUpDownWM As System.Windows.Forms.NumericUpDown
    Friend WithEvents LinkLabelWaterM As System.Windows.Forms.LinkLabel
    Friend WithEvents PictureBoxWaterM As System.Windows.Forms.PictureBox
    Friend WithEvents LinkLabelDM As System.Windows.Forms.LinkLabel
    Friend WithEvents DomainUpDownDM As System.Windows.Forms.DomainUpDown
    Friend WithEvents PictureBoxDM As System.Windows.Forms.PictureBox
    Friend WithEvents DomainUpDownLM As System.Windows.Forms.DomainUpDown
    Friend WithEvents LinkLabelLightsM As System.Windows.Forms.LinkLabel
    Friend WithEvents PictureBoxLightsM As System.Windows.Forms.PictureBox
    Friend WithEvents MenuStripFile As System.Windows.Forms.MenuStrip
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ContactToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitControlerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LabelLevelWM As System.Windows.Forms.Label
    Friend WithEvents NumericUpDownLevelWM As System.Windows.Forms.NumericUpDown
    Friend WithEvents DomainUpDownAlarmMnf As System.Windows.Forms.DomainUpDown
    Friend WithEvents LinkLabelAlarmM As System.Windows.Forms.LinkLabel
    Friend WithEvents PictureBoxAlarmM As System.Windows.Forms.PictureBox
    Friend WithEvents LogOutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpProvider1 As System.Windows.Forms.HelpProvider
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents DomainUpDownAlarmM2 As System.Windows.Forms.DomainUpDown
    Friend WithEvents TextBoxHuman As System.Windows.Forms.TextBox
    Friend WithEvents DomainUpDownAlarmM3 As System.Windows.Forms.DomainUpDown
    Friend WithEvents DomainUpDownAlarmM4 As System.Windows.Forms.DomainUpDown
    Friend WithEvents DomainUpDownAlarmM1 As System.Windows.Forms.DomainUpDown
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox3 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox4 As System.Windows.Forms.PictureBox
    Friend WithEvents ButtonBackMS As System.Windows.Forms.Button
End Class
