﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormKitchen
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormKitchen))
        Me.ButtonBackK = New System.Windows.Forms.Button()
        Me.MenuStripFile = New System.Windows.Forms.MenuStrip()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ContactToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LogOutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitControlerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LinkLabelFridge = New System.Windows.Forms.LinkLabel()
        Me.PictureBoxFridge = New System.Windows.Forms.PictureBox()
        Me.NumericUpDownFridge = New System.Windows.Forms.NumericUpDown()
        Me.LabelTempF = New System.Windows.Forms.Label()
        Me.PictureBoxMainLights = New System.Windows.Forms.PictureBox()
        Me.LinkLabel1 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabelMainLightsK = New System.Windows.Forms.LinkLabel()
        Me.LinkLabelOven = New System.Windows.Forms.LinkLabel()
        Me.PictureBoxOven = New System.Windows.Forms.PictureBox()
        Me.PictureBoxMicrowave = New System.Windows.Forms.PictureBox()
        Me.LinkLabelMicrowave = New System.Windows.Forms.LinkLabel()
        Me.LinkLabelSeclightsK = New System.Windows.Forms.LinkLabel()
        Me.PictureBoxSeclights = New System.Windows.Forms.PictureBox()
        Me.PictureBoxHobs = New System.Windows.Forms.PictureBox()
        Me.LinkLabelHobsK = New System.Windows.Forms.LinkLabel()
        Me.PictureBoxTVK = New System.Windows.Forms.PictureBox()
        Me.PictureBoxSSK = New System.Windows.Forms.PictureBox()
        Me.LinkLabelTVK = New System.Windows.Forms.LinkLabel()
        Me.LinkLabelSSK = New System.Windows.Forms.LinkLabel()
        Me.PictureBoxAirK = New System.Windows.Forms.PictureBox()
        Me.LinkLabelAirK = New System.Windows.Forms.LinkLabel()
        Me.LabelTempOK = New System.Windows.Forms.Label()
        Me.NumericUpDownMK = New System.Windows.Forms.NumericUpDown()
        Me.LabelTempMK = New System.Windows.Forms.Label()
        Me.NumericUpDownMmK = New System.Windows.Forms.NumericUpDown()
        Me.LabelMinK = New System.Windows.Forms.Label()
        Me.NumericUpDownHK = New System.Windows.Forms.NumericUpDown()
        Me.LabelHobK = New System.Windows.Forms.Label()
        Me.NumericUpDownTempHK = New System.Windows.Forms.NumericUpDown()
        Me.LabelTempHK = New System.Windows.Forms.Label()
        Me.NumericUpDownAK = New System.Windows.Forms.NumericUpDown()
        Me.LabelTempAK = New System.Windows.Forms.Label()
        Me.NumericUpDownOK = New System.Windows.Forms.NumericUpDown()
        Me.DomainUpDownMlK = New System.Windows.Forms.DomainUpDown()
        Me.DomainUpDownSlK = New System.Windows.Forms.DomainUpDown()
        Me.DomainUpDownSSK = New System.Windows.Forms.DomainUpDown()
        Me.DomainUpDownTVK = New System.Windows.Forms.DomainUpDown()
        Me.HelpProvider1 = New System.Windows.Forms.HelpProvider()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.MenuStripFile.SuspendLayout()
        CType(Me.PictureBoxFridge, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDownFridge, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxMainLights, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxOven, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxMicrowave, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxSeclights, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxHobs, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxTVK, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxSSK, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxAirK, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDownMK, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDownMmK, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDownHK, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDownTempHK, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDownAK, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDownOK, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ButtonBackK
        '
        Me.ButtonBackK.Location = New System.Drawing.Point(462, 405)
        Me.ButtonBackK.Name = "ButtonBackK"
        Me.ButtonBackK.Size = New System.Drawing.Size(110, 25)
        Me.ButtonBackK.TabIndex = 16
        Me.ButtonBackK.Text = "Back"
        Me.ButtonBackK.UseVisualStyleBackColor = True
        '
        'MenuStripFile
        '
        Me.MenuStripFile.BackColor = System.Drawing.Color.Transparent
        Me.MenuStripFile.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.MenuStripFile.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem1})
        Me.MenuStripFile.Location = New System.Drawing.Point(0, 0)
        Me.MenuStripFile.Name = "MenuStripFile"
        Me.MenuStripFile.ShowItemToolTips = True
        Me.MenuStripFile.Size = New System.Drawing.Size(584, 24)
        Me.MenuStripFile.TabIndex = 17
        Me.MenuStripFile.Text = "MenuStrip1"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ContactToolStripMenuItem, Me.HelpToolStripMenuItem, Me.AboutToolStripMenuItem, Me.LogOutToolStripMenuItem, Me.ExitControlerToolStripMenuItem})
        Me.ToolStripMenuItem1.ForeColor = System.Drawing.Color.Coral
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(37, 20)
        Me.ToolStripMenuItem1.Text = "File"
        '
        'ContactToolStripMenuItem
        '
        Me.ContactToolStripMenuItem.Name = "ContactToolStripMenuItem"
        Me.ContactToolStripMenuItem.Size = New System.Drawing.Size(117, 22)
        Me.ContactToolStripMenuItem.Text = "Contact"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(117, 22)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(117, 22)
        Me.AboutToolStripMenuItem.Text = "About"
        '
        'LogOutToolStripMenuItem
        '
        Me.LogOutToolStripMenuItem.Name = "LogOutToolStripMenuItem"
        Me.LogOutToolStripMenuItem.Size = New System.Drawing.Size(117, 22)
        Me.LogOutToolStripMenuItem.Text = "Log Out"
        '
        'ExitControlerToolStripMenuItem
        '
        Me.ExitControlerToolStripMenuItem.Name = "ExitControlerToolStripMenuItem"
        Me.ExitControlerToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.ExitControlerToolStripMenuItem.Text = "Exit Controller"
        '
        'LinkLabelFridge
        '
        Me.LinkLabelFridge.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelFridge.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelFridge.LinkColor = System.Drawing.Color.White
        Me.LinkLabelFridge.Location = New System.Drawing.Point(37, 134)
        Me.LinkLabelFridge.Name = "LinkLabelFridge"
        Me.LinkLabelFridge.Size = New System.Drawing.Size(97, 150)
        Me.LinkLabelFridge.TabIndex = 0
        Me.LinkLabelFridge.TabStop = True
        Me.LinkLabelFridge.Text = "Fridge"
        Me.LinkLabelFridge.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'PictureBoxFridge
        '
        Me.PictureBoxFridge.BackgroundImage = CType(resources.GetObject("PictureBoxFridge.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxFridge.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxFridge.Location = New System.Drawing.Point(37, 149)
        Me.PictureBoxFridge.Name = "PictureBoxFridge"
        Me.PictureBoxFridge.Size = New System.Drawing.Size(96, 135)
        Me.PictureBoxFridge.TabIndex = 19
        Me.PictureBoxFridge.TabStop = False
        '
        'NumericUpDownFridge
        '
        Me.NumericUpDownFridge.Location = New System.Drawing.Point(37, 109)
        Me.NumericUpDownFridge.Maximum = New Decimal(New Integer() {10, 0, 0, 0})
        Me.NumericUpDownFridge.Minimum = New Decimal(New Integer() {10, 0, 0, -2147483648})
        Me.NumericUpDownFridge.Name = "NumericUpDownFridge"
        Me.NumericUpDownFridge.ReadOnly = True
        Me.NumericUpDownFridge.Size = New System.Drawing.Size(96, 20)
        Me.NumericUpDownFridge.TabIndex = 20
        Me.NumericUpDownFridge.Visible = False
        '
        'LabelTempF
        '
        Me.LabelTempF.AutoSize = True
        Me.LabelTempF.Location = New System.Drawing.Point(34, 95)
        Me.LabelTempF.Name = "LabelTempF"
        Me.LabelTempF.Size = New System.Drawing.Size(48, 13)
        Me.LabelTempF.TabIndex = 21
        Me.LabelTempF.Text = "Temp °C"
        Me.LabelTempF.Visible = False
        '
        'PictureBoxMainLights
        '
        Me.PictureBoxMainLights.BackColor = System.Drawing.Color.Transparent
        Me.PictureBoxMainLights.BackgroundImage = CType(resources.GetObject("PictureBoxMainLights.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxMainLights.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxMainLights.Location = New System.Drawing.Point(198, 9)
        Me.PictureBoxMainLights.Name = "PictureBoxMainLights"
        Me.PictureBoxMainLights.Size = New System.Drawing.Size(125, 120)
        Me.PictureBoxMainLights.TabIndex = 56
        Me.PictureBoxMainLights.TabStop = False
        '
        'LinkLabel1
        '
        Me.LinkLabel1.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabel1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabel1.LinkColor = System.Drawing.Color.DarkBlue
        Me.LinkLabel1.Location = New System.Drawing.Point(158, 147)
        Me.LinkLabel1.Name = "LinkLabel1"
        Me.LinkLabel1.Size = New System.Drawing.Size(97, 137)
        Me.LinkLabel1.TabIndex = 0
        Me.LinkLabel1.TabStop = True
        Me.LinkLabel1.Text = "Fridge"
        Me.LinkLabel1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'LinkLabelMainLightsK
        '
        Me.LinkLabelMainLightsK.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelMainLightsK.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelMainLightsK.LinkColor = System.Drawing.Color.Yellow
        Me.LinkLabelMainLightsK.Location = New System.Drawing.Point(193, 9)
        Me.LinkLabelMainLightsK.Name = "LinkLabelMainLightsK"
        Me.LinkLabelMainLightsK.Size = New System.Drawing.Size(147, 126)
        Me.LinkLabelMainLightsK.TabIndex = 23
        Me.LinkLabelMainLightsK.TabStop = True
        Me.LinkLabelMainLightsK.Text = "Main Lights"
        Me.LinkLabelMainLightsK.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'LinkLabelOven
        '
        Me.LinkLabelOven.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelOven.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelOven.LinkColor = System.Drawing.Color.White
        Me.LinkLabelOven.Location = New System.Drawing.Point(139, 134)
        Me.LinkLabelOven.Name = "LinkLabelOven"
        Me.LinkLabelOven.Size = New System.Drawing.Size(70, 81)
        Me.LinkLabelOven.TabIndex = 24
        Me.LinkLabelOven.TabStop = True
        Me.LinkLabelOven.Text = "Oven"
        Me.LinkLabelOven.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'PictureBoxOven
        '
        Me.PictureBoxOven.BackgroundImage = CType(resources.GetObject("PictureBoxOven.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxOven.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxOven.Location = New System.Drawing.Point(140, 163)
        Me.PictureBoxOven.Name = "PictureBoxOven"
        Me.PictureBoxOven.Size = New System.Drawing.Size(51, 52)
        Me.PictureBoxOven.TabIndex = 25
        Me.PictureBoxOven.TabStop = False
        '
        'PictureBoxMicrowave
        '
        Me.PictureBoxMicrowave.BackgroundImage = CType(resources.GetObject("PictureBoxMicrowave.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxMicrowave.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxMicrowave.Location = New System.Drawing.Point(215, 163)
        Me.PictureBoxMicrowave.Name = "PictureBoxMicrowave"
        Me.PictureBoxMicrowave.Size = New System.Drawing.Size(55, 37)
        Me.PictureBoxMicrowave.TabIndex = 26
        Me.PictureBoxMicrowave.TabStop = False
        '
        'LinkLabelMicrowave
        '
        Me.LinkLabelMicrowave.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelMicrowave.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelMicrowave.LinkColor = System.Drawing.Color.White
        Me.LinkLabelMicrowave.Location = New System.Drawing.Point(215, 135)
        Me.LinkLabelMicrowave.Name = "LinkLabelMicrowave"
        Me.LinkLabelMicrowave.Size = New System.Drawing.Size(64, 65)
        Me.LinkLabelMicrowave.TabIndex = 27
        Me.LinkLabelMicrowave.TabStop = True
        Me.LinkLabelMicrowave.Text = "Micro"
        Me.LinkLabelMicrowave.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'LinkLabelSeclightsK
        '
        Me.LinkLabelSeclightsK.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelSeclightsK.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelSeclightsK.LinkColor = System.Drawing.Color.White
        Me.LinkLabelSeclightsK.Location = New System.Drawing.Point(451, 9)
        Me.LinkLabelSeclightsK.Name = "LinkLabelSeclightsK"
        Me.LinkLabelSeclightsK.Size = New System.Drawing.Size(121, 95)
        Me.LinkLabelSeclightsK.TabIndex = 28
        Me.LinkLabelSeclightsK.TabStop = True
        Me.LinkLabelSeclightsK.Text = "Sec Lights"
        Me.LinkLabelSeclightsK.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'PictureBoxSeclights
        '
        Me.PictureBoxSeclights.BackColor = System.Drawing.Color.Transparent
        Me.PictureBoxSeclights.BackgroundImage = CType(resources.GetObject("PictureBoxSeclights.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxSeclights.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxSeclights.Location = New System.Drawing.Point(456, 40)
        Me.PictureBoxSeclights.Name = "PictureBoxSeclights"
        Me.PictureBoxSeclights.Size = New System.Drawing.Size(56, 89)
        Me.PictureBoxSeclights.TabIndex = 57
        Me.PictureBoxSeclights.TabStop = False
        '
        'PictureBoxHobs
        '
        Me.PictureBoxHobs.BackgroundImage = CType(resources.GetObject("PictureBoxHobs.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxHobs.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxHobs.Location = New System.Drawing.Point(371, 156)
        Me.PictureBoxHobs.Name = "PictureBoxHobs"
        Me.PictureBoxHobs.Size = New System.Drawing.Size(83, 78)
        Me.PictureBoxHobs.TabIndex = 30
        Me.PictureBoxHobs.TabStop = False
        '
        'LinkLabelHobsK
        '
        Me.LinkLabelHobsK.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelHobsK.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelHobsK.ForeColor = System.Drawing.Color.White
        Me.LinkLabelHobsK.LinkColor = System.Drawing.Color.White
        Me.LinkLabelHobsK.Location = New System.Drawing.Point(357, 147)
        Me.LinkLabelHobsK.Name = "LinkLabelHobsK"
        Me.LinkLabelHobsK.Size = New System.Drawing.Size(99, 89)
        Me.LinkLabelHobsK.TabIndex = 31
        Me.LinkLabelHobsK.TabStop = True
        Me.LinkLabelHobsK.Text = "Hobs"
        Me.LinkLabelHobsK.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PictureBoxTVK
        '
        Me.PictureBoxTVK.BackgroundImage = CType(resources.GetObject("PictureBoxTVK.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxTVK.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxTVK.Location = New System.Drawing.Point(461, 138)
        Me.PictureBoxTVK.Name = "PictureBoxTVK"
        Me.PictureBoxTVK.Size = New System.Drawing.Size(100, 62)
        Me.PictureBoxTVK.TabIndex = 32
        Me.PictureBoxTVK.TabStop = False
        '
        'PictureBoxSSK
        '
        Me.PictureBoxSSK.BackgroundImage = CType(resources.GetObject("PictureBoxSSK.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxSSK.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxSSK.Location = New System.Drawing.Point(462, 232)
        Me.PictureBoxSSK.Name = "PictureBoxSSK"
        Me.PictureBoxSSK.Size = New System.Drawing.Size(98, 50)
        Me.PictureBoxSSK.TabIndex = 33
        Me.PictureBoxSSK.TabStop = False
        '
        'LinkLabelTVK
        '
        Me.LinkLabelTVK.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelTVK.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelTVK.LinkColor = System.Drawing.Color.White
        Me.LinkLabelTVK.Location = New System.Drawing.Point(461, 107)
        Me.LinkLabelTVK.Name = "LinkLabelTVK"
        Me.LinkLabelTVK.Size = New System.Drawing.Size(101, 93)
        Me.LinkLabelTVK.TabIndex = 34
        Me.LinkLabelTVK.TabStop = True
        Me.LinkLabelTVK.Text = "TV"
        Me.LinkLabelTVK.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'LinkLabelSSK
        '
        Me.LinkLabelSSK.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelSSK.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelSSK.LinkColor = System.Drawing.Color.White
        Me.LinkLabelSSK.Location = New System.Drawing.Point(458, 203)
        Me.LinkLabelSSK.Name = "LinkLabelSSK"
        Me.LinkLabelSSK.Size = New System.Drawing.Size(102, 81)
        Me.LinkLabelSSK.TabIndex = 35
        Me.LinkLabelSSK.TabStop = True
        Me.LinkLabelSSK.Text = "Stereo"
        Me.LinkLabelSSK.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'PictureBoxAirK
        '
        Me.PictureBoxAirK.BackgroundImage = CType(resources.GetObject("PictureBoxAirK.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxAirK.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxAirK.Location = New System.Drawing.Point(328, 52)
        Me.PictureBoxAirK.Name = "PictureBoxAirK"
        Me.PictureBoxAirK.Size = New System.Drawing.Size(122, 52)
        Me.PictureBoxAirK.TabIndex = 36
        Me.PictureBoxAirK.TabStop = False
        '
        'LinkLabelAirK
        '
        Me.LinkLabelAirK.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelAirK.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelAirK.LinkColor = System.Drawing.Color.White
        Me.LinkLabelAirK.Location = New System.Drawing.Point(328, 52)
        Me.LinkLabelAirK.Name = "LinkLabelAirK"
        Me.LinkLabelAirK.Size = New System.Drawing.Size(122, 52)
        Me.LinkLabelAirK.TabIndex = 37
        Me.LinkLabelAirK.TabStop = True
        Me.LinkLabelAirK.Text = "Air"
        Me.LinkLabelAirK.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'LabelTempOK
        '
        Me.LabelTempOK.AutoSize = True
        Me.LabelTempOK.Location = New System.Drawing.Point(141, 220)
        Me.LabelTempOK.Name = "LabelTempOK"
        Me.LabelTempOK.Size = New System.Drawing.Size(48, 13)
        Me.LabelTempOK.TabIndex = 39
        Me.LabelTempOK.Text = "Temp °C"
        Me.LabelTempOK.Visible = False
        '
        'NumericUpDownMK
        '
        Me.NumericUpDownMK.Increment = New Decimal(New Integer() {50, 0, 0, 0})
        Me.NumericUpDownMK.Location = New System.Drawing.Point(224, 221)
        Me.NumericUpDownMK.Maximum = New Decimal(New Integer() {270, 0, 0, 0})
        Me.NumericUpDownMK.Name = "NumericUpDownMK"
        Me.NumericUpDownMK.ReadOnly = True
        Me.NumericUpDownMK.Size = New System.Drawing.Size(55, 20)
        Me.NumericUpDownMK.TabIndex = 40
        Me.NumericUpDownMK.Value = New Decimal(New Integer() {120, 0, 0, 0})
        Me.NumericUpDownMK.Visible = False
        '
        'LabelTempMK
        '
        Me.LabelTempMK.AutoSize = True
        Me.LabelTempMK.Location = New System.Drawing.Point(221, 207)
        Me.LabelTempMK.Name = "LabelTempMK"
        Me.LabelTempMK.Size = New System.Drawing.Size(48, 13)
        Me.LabelTempMK.TabIndex = 41
        Me.LabelTempMK.Text = "Temp °C"
        Me.LabelTempMK.Visible = False
        '
        'NumericUpDownMmK
        '
        Me.NumericUpDownMmK.Location = New System.Drawing.Point(224, 255)
        Me.NumericUpDownMmK.Maximum = New Decimal(New Integer() {10, 0, 0, 0})
        Me.NumericUpDownMmK.Name = "NumericUpDownMmK"
        Me.NumericUpDownMmK.ReadOnly = True
        Me.NumericUpDownMmK.Size = New System.Drawing.Size(55, 20)
        Me.NumericUpDownMmK.TabIndex = 42
        Me.NumericUpDownMmK.Value = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDownMmK.Visible = False
        '
        'LabelMinK
        '
        Me.LabelMinK.AutoSize = True
        Me.LabelMinK.Location = New System.Drawing.Point(221, 241)
        Me.LabelMinK.Name = "LabelMinK"
        Me.LabelMinK.Size = New System.Drawing.Size(24, 13)
        Me.LabelMinK.TabIndex = 43
        Me.LabelMinK.Text = "Min"
        Me.LabelMinK.Visible = False
        '
        'NumericUpDownHK
        '
        Me.NumericUpDownHK.Location = New System.Drawing.Point(371, 253)
        Me.NumericUpDownHK.Maximum = New Decimal(New Integer() {4, 0, 0, 0})
        Me.NumericUpDownHK.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDownHK.Name = "NumericUpDownHK"
        Me.NumericUpDownHK.ReadOnly = True
        Me.NumericUpDownHK.Size = New System.Drawing.Size(57, 20)
        Me.NumericUpDownHK.TabIndex = 44
        Me.NumericUpDownHK.Value = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDownHK.Visible = False
        '
        'LabelHobK
        '
        Me.LabelHobK.AutoSize = True
        Me.LabelHobK.Location = New System.Drawing.Point(368, 240)
        Me.LabelHobK.Name = "LabelHobK"
        Me.LabelHobK.Size = New System.Drawing.Size(27, 13)
        Me.LabelHobK.TabIndex = 45
        Me.LabelHobK.Text = "Hob"
        Me.LabelHobK.Visible = False
        '
        'NumericUpDownTempHK
        '
        Me.NumericUpDownTempHK.Location = New System.Drawing.Point(371, 285)
        Me.NumericUpDownTempHK.Maximum = New Decimal(New Integer() {10, 0, 0, 0})
        Me.NumericUpDownTempHK.Name = "NumericUpDownTempHK"
        Me.NumericUpDownTempHK.ReadOnly = True
        Me.NumericUpDownTempHK.Size = New System.Drawing.Size(57, 20)
        Me.NumericUpDownTempHK.TabIndex = 46
        Me.NumericUpDownTempHK.Value = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDownTempHK.Visible = False
        '
        'LabelTempHK
        '
        Me.LabelTempHK.AutoSize = True
        Me.LabelTempHK.Location = New System.Drawing.Point(368, 272)
        Me.LabelTempHK.Name = "LabelTempHK"
        Me.LabelTempHK.Size = New System.Drawing.Size(48, 13)
        Me.LabelTempHK.TabIndex = 47
        Me.LabelTempHK.Text = "Temp °C"
        Me.LabelTempHK.Visible = False
        '
        'NumericUpDownAK
        '
        Me.NumericUpDownAK.Location = New System.Drawing.Point(349, 121)
        Me.NumericUpDownAK.Maximum = New Decimal(New Integer() {28, 0, 0, 0})
        Me.NumericUpDownAK.Minimum = New Decimal(New Integer() {16, 0, 0, 0})
        Me.NumericUpDownAK.Name = "NumericUpDownAK"
        Me.NumericUpDownAK.ReadOnly = True
        Me.NumericUpDownAK.Size = New System.Drawing.Size(67, 20)
        Me.NumericUpDownAK.TabIndex = 48
        Me.NumericUpDownAK.Value = New Decimal(New Integer() {16, 0, 0, 0})
        Me.NumericUpDownAK.Visible = False
        '
        'LabelTempAK
        '
        Me.LabelTempAK.AutoSize = True
        Me.LabelTempAK.Location = New System.Drawing.Point(346, 107)
        Me.LabelTempAK.Name = "LabelTempAK"
        Me.LabelTempAK.Size = New System.Drawing.Size(48, 13)
        Me.LabelTempAK.TabIndex = 49
        Me.LabelTempAK.Text = "Temp °C"
        Me.LabelTempAK.Visible = False
        '
        'NumericUpDownOK
        '
        Me.NumericUpDownOK.Increment = New Decimal(New Integer() {50, 0, 0, 0})
        Me.NumericUpDownOK.Location = New System.Drawing.Point(143, 234)
        Me.NumericUpDownOK.Maximum = New Decimal(New Integer() {270, 0, 0, 0})
        Me.NumericUpDownOK.Name = "NumericUpDownOK"
        Me.NumericUpDownOK.ReadOnly = True
        Me.NumericUpDownOK.Size = New System.Drawing.Size(55, 20)
        Me.NumericUpDownOK.TabIndex = 50
        Me.NumericUpDownOK.Value = New Decimal(New Integer() {120, 0, 0, 0})
        Me.NumericUpDownOK.Visible = False
        '
        'DomainUpDownMlK
        '
        Me.DomainUpDownMlK.Items.Add("ON")
        Me.DomainUpDownMlK.Items.Add("OFF")
        Me.DomainUpDownMlK.Location = New System.Drawing.Point(133, 12)
        Me.DomainUpDownMlK.Name = "DomainUpDownMlK"
        Me.DomainUpDownMlK.ReadOnly = True
        Me.DomainUpDownMlK.Size = New System.Drawing.Size(65, 20)
        Me.DomainUpDownMlK.TabIndex = 2
        Me.DomainUpDownMlK.Text = "ON/OFF"
        '
        'DomainUpDownSlK
        '
        Me.DomainUpDownSlK.Items.Add("ON")
        Me.DomainUpDownSlK.Items.Add("OFF")
        Me.DomainUpDownSlK.Location = New System.Drawing.Point(511, 84)
        Me.DomainUpDownSlK.Name = "DomainUpDownSlK"
        Me.DomainUpDownSlK.ReadOnly = True
        Me.DomainUpDownSlK.Size = New System.Drawing.Size(61, 20)
        Me.DomainUpDownSlK.TabIndex = 2
        Me.DomainUpDownSlK.Text = "ON/OFF"
        '
        'DomainUpDownSSK
        '
        Me.DomainUpDownSSK.Items.Add("ON")
        Me.DomainUpDownSSK.Items.Add("OFF")
        Me.DomainUpDownSSK.Location = New System.Drawing.Point(502, 289)
        Me.DomainUpDownSSK.Name = "DomainUpDownSSK"
        Me.DomainUpDownSSK.ReadOnly = True
        Me.DomainUpDownSSK.Size = New System.Drawing.Size(61, 20)
        Me.DomainUpDownSSK.TabIndex = 55
        Me.DomainUpDownSSK.Text = "ON/OFF"
        '
        'DomainUpDownTVK
        '
        Me.DomainUpDownTVK.Items.Add("ON")
        Me.DomainUpDownTVK.Items.Add("OFF")
        Me.DomainUpDownTVK.Location = New System.Drawing.Point(395, 149)
        Me.DomainUpDownTVK.Name = "DomainUpDownTVK"
        Me.DomainUpDownTVK.ReadOnly = True
        Me.DomainUpDownTVK.Size = New System.Drawing.Size(61, 20)
        Me.DomainUpDownTVK.TabIndex = 2
        Me.DomainUpDownTVK.Text = "ON/OFF"
        '
        'HelpProvider1
        '
        Me.HelpProvider1.HelpNamespace = "C:\Users\Morpheus\Desktop\Dun.chm"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(37, 385)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(62, 20)
        Me.TextBox1.TabIndex = 151
        Me.TextBox1.Visible = False
        '
        'FormKitchen
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(584, 452)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.DomainUpDownTVK)
        Me.Controls.Add(Me.DomainUpDownSSK)
        Me.Controls.Add(Me.DomainUpDownSlK)
        Me.Controls.Add(Me.DomainUpDownMlK)
        Me.Controls.Add(Me.NumericUpDownOK)
        Me.Controls.Add(Me.NumericUpDownAK)
        Me.Controls.Add(Me.LabelTempAK)
        Me.Controls.Add(Me.NumericUpDownTempHK)
        Me.Controls.Add(Me.LabelTempHK)
        Me.Controls.Add(Me.NumericUpDownHK)
        Me.Controls.Add(Me.LabelHobK)
        Me.Controls.Add(Me.NumericUpDownMmK)
        Me.Controls.Add(Me.LabelMinK)
        Me.Controls.Add(Me.NumericUpDownMK)
        Me.Controls.Add(Me.LabelTempMK)
        Me.Controls.Add(Me.LabelTempOK)
        Me.Controls.Add(Me.LinkLabelAirK)
        Me.Controls.Add(Me.PictureBoxAirK)
        Me.Controls.Add(Me.LinkLabelSSK)
        Me.Controls.Add(Me.LinkLabelTVK)
        Me.Controls.Add(Me.LinkLabelHobsK)
        Me.Controls.Add(Me.LinkLabelSeclightsK)
        Me.Controls.Add(Me.LinkLabelMicrowave)
        Me.Controls.Add(Me.LinkLabelOven)
        Me.Controls.Add(Me.LinkLabelMainLightsK)
        Me.Controls.Add(Me.PictureBoxMainLights)
        Me.Controls.Add(Me.LinkLabelFridge)
        Me.Controls.Add(Me.PictureBoxFridge)
        Me.Controls.Add(Me.MenuStripFile)
        Me.Controls.Add(Me.ButtonBackK)
        Me.Controls.Add(Me.NumericUpDownFridge)
        Me.Controls.Add(Me.LabelTempF)
        Me.Controls.Add(Me.PictureBoxOven)
        Me.Controls.Add(Me.PictureBoxMicrowave)
        Me.Controls.Add(Me.PictureBoxSSK)
        Me.Controls.Add(Me.PictureBoxTVK)
        Me.Controls.Add(Me.PictureBoxHobs)
        Me.Controls.Add(Me.PictureBoxSeclights)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "FormKitchen"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Kitchen"
        Me.MenuStripFile.ResumeLayout(False)
        Me.MenuStripFile.PerformLayout()
        CType(Me.PictureBoxFridge, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDownFridge, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxMainLights, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxOven, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxMicrowave, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxSeclights, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxHobs, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxTVK, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxSSK, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxAirK, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDownMK, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDownMmK, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDownHK, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDownTempHK, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDownAK, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDownOK, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ButtonBackK As System.Windows.Forms.Button
    Friend WithEvents MenuStripFile As System.Windows.Forms.MenuStrip
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ContactToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitControlerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ShapeContainer1 As Microsoft.VisualBasic.PowerPacks.ShapeContainer
    Friend WithEvents RectangleShapeFridge As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents LinkLabelFridge As System.Windows.Forms.LinkLabel
    Friend WithEvents PictureBoxFridge As System.Windows.Forms.PictureBox
    Friend WithEvents NumericUpDownFridge As System.Windows.Forms.NumericUpDown
    Friend WithEvents LabelTempF As System.Windows.Forms.Label
    Friend WithEvents PictureBoxMainLights As System.Windows.Forms.PictureBox
    Friend WithEvents LinkLabel1 As System.Windows.Forms.LinkLabel
    Friend WithEvents LinkLabelMainLightsK As System.Windows.Forms.LinkLabel
    Friend WithEvents LinkLabelOven As System.Windows.Forms.LinkLabel
    Friend WithEvents PictureBoxOven As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBoxMicrowave As System.Windows.Forms.PictureBox
    Friend WithEvents LinkLabelMicrowave As System.Windows.Forms.LinkLabel
    Friend WithEvents LinkLabelSeclightsK As System.Windows.Forms.LinkLabel
    Friend WithEvents PictureBoxSeclights As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBoxHobs As System.Windows.Forms.PictureBox
    Friend WithEvents LinkLabelHobsK As System.Windows.Forms.LinkLabel
    Friend WithEvents PictureBoxTVK As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBoxSSK As System.Windows.Forms.PictureBox
    Friend WithEvents LinkLabelTVK As System.Windows.Forms.LinkLabel
    Friend WithEvents LinkLabelSSK As System.Windows.Forms.LinkLabel
    Friend WithEvents PictureBoxAirK As System.Windows.Forms.PictureBox
    Friend WithEvents LinkLabelAirK As System.Windows.Forms.LinkLabel
    Friend WithEvents LabelTempOK As System.Windows.Forms.Label
    Friend WithEvents NumericUpDownMK As System.Windows.Forms.NumericUpDown
    Friend WithEvents LabelTempMK As System.Windows.Forms.Label
    Friend WithEvents NumericUpDownMmK As System.Windows.Forms.NumericUpDown
    Friend WithEvents LabelMinK As System.Windows.Forms.Label
    Friend WithEvents NumericUpDownHK As System.Windows.Forms.NumericUpDown
    Friend WithEvents LabelHobK As System.Windows.Forms.Label
    Friend WithEvents NumericUpDownTempHK As System.Windows.Forms.NumericUpDown
    Friend WithEvents LabelTempHK As System.Windows.Forms.Label
    Friend WithEvents NumericUpDownAK As System.Windows.Forms.NumericUpDown
    Friend WithEvents LabelTempAK As System.Windows.Forms.Label
    Friend WithEvents NumericUpDownOK As System.Windows.Forms.NumericUpDown
    Friend WithEvents DomainUpDownMlK As System.Windows.Forms.DomainUpDown
    Friend WithEvents DomainUpDownSlK As System.Windows.Forms.DomainUpDown
    Friend WithEvents DomainUpDownSSK As System.Windows.Forms.DomainUpDown
    Friend WithEvents DomainUpDownTVK As System.Windows.Forms.DomainUpDown
    Friend WithEvents LogOutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpProvider1 As System.Windows.Forms.HelpProvider
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
End Class
