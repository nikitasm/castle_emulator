﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormMainBedroom
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormMainBedroom))
        Me.ButtonBackM = New System.Windows.Forms.Button()
        Me.MenuStripFile = New System.Windows.Forms.MenuStrip()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ContactToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LogOutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitControlerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DomainUpDownTVMB = New System.Windows.Forms.DomainUpDown()
        Me.DomainUpDownSSMB = New System.Windows.Forms.DomainUpDown()
        Me.DomainUpDownMLMB = New System.Windows.Forms.DomainUpDown()
        Me.NumericUpDownAMB = New System.Windows.Forms.NumericUpDown()
        Me.LabelTempAMB = New System.Windows.Forms.Label()
        Me.LinkLabelAirMB = New System.Windows.Forms.LinkLabel()
        Me.PictureBoxAirMB = New System.Windows.Forms.PictureBox()
        Me.LinkLabelSSMB = New System.Windows.Forms.LinkLabel()
        Me.LinkLabelTVMB = New System.Windows.Forms.LinkLabel()
        Me.LinkLabelSeclightsMB = New System.Windows.Forms.LinkLabel()
        Me.LinkLabelMainLightsMB = New System.Windows.Forms.LinkLabel()
        Me.PictureBoxMainLightsMB = New System.Windows.Forms.PictureBox()
        Me.PictureBoxSeclightsMB = New System.Windows.Forms.PictureBox()
        Me.PictureBoxSSMB = New System.Windows.Forms.PictureBox()
        Me.PictureBoxTVMB = New System.Windows.Forms.PictureBox()
        Me.DomainUpDownSLMB = New System.Windows.Forms.DomainUpDown()
        Me.LinkLabelFPMB = New System.Windows.Forms.LinkLabel()
        Me.DomainUpDownFPMB = New System.Windows.Forms.DomainUpDown()
        Me.PictureBoxFPMB = New System.Windows.Forms.PictureBox()
        Me.HelpProvider1 = New System.Windows.Forms.HelpProvider()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.MenuStripFile.SuspendLayout()
        CType(Me.NumericUpDownAMB, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxAirMB, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxMainLightsMB, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxSeclightsMB, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxSSMB, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxTVMB, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxFPMB, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ButtonBackM
        '
        Me.ButtonBackM.Location = New System.Drawing.Point(462, 415)
        Me.ButtonBackM.Name = "ButtonBackM"
        Me.ButtonBackM.Size = New System.Drawing.Size(110, 25)
        Me.ButtonBackM.TabIndex = 7
        Me.ButtonBackM.Text = "Back"
        Me.ButtonBackM.UseVisualStyleBackColor = True
        '
        'MenuStripFile
        '
        Me.MenuStripFile.BackColor = System.Drawing.Color.Transparent
        Me.MenuStripFile.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.MenuStripFile.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem1})
        Me.MenuStripFile.Location = New System.Drawing.Point(0, 0)
        Me.MenuStripFile.Name = "MenuStripFile"
        Me.MenuStripFile.ShowItemToolTips = True
        Me.MenuStripFile.Size = New System.Drawing.Size(584, 24)
        Me.MenuStripFile.TabIndex = 8
        Me.MenuStripFile.Text = "MenuStrip1"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ContactToolStripMenuItem, Me.HelpToolStripMenuItem, Me.AboutToolStripMenuItem, Me.LogOutToolStripMenuItem, Me.ExitControlerToolStripMenuItem})
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(37, 20)
        Me.ToolStripMenuItem1.Text = "File"
        '
        'ContactToolStripMenuItem
        '
        Me.ContactToolStripMenuItem.Name = "ContactToolStripMenuItem"
        Me.ContactToolStripMenuItem.Size = New System.Drawing.Size(145, 22)
        Me.ContactToolStripMenuItem.Text = "Contact"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(145, 22)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(145, 22)
        Me.AboutToolStripMenuItem.Text = "About"
        '
        'LogOutToolStripMenuItem
        '
        Me.LogOutToolStripMenuItem.Name = "LogOutToolStripMenuItem"
        Me.LogOutToolStripMenuItem.Size = New System.Drawing.Size(145, 22)
        Me.LogOutToolStripMenuItem.Text = "Log Out"
        '
        'ExitControlerToolStripMenuItem
        '
        Me.ExitControlerToolStripMenuItem.Name = "ExitControlerToolStripMenuItem"
        Me.ExitControlerToolStripMenuItem.Size = New System.Drawing.Size(145, 22)
        Me.ExitControlerToolStripMenuItem.Text = "Exit Controler"
        '
        'DomainUpDownTVMB
        '
        Me.DomainUpDownTVMB.Items.Add("ON")
        Me.DomainUpDownTVMB.Items.Add("OFF")
        Me.DomainUpDownTVMB.Location = New System.Drawing.Point(421, 178)
        Me.DomainUpDownTVMB.Name = "DomainUpDownTVMB"
        Me.DomainUpDownTVMB.ReadOnly = True
        Me.DomainUpDownTVMB.Size = New System.Drawing.Size(61, 20)
        Me.DomainUpDownTVMB.TabIndex = 95
        Me.DomainUpDownTVMB.Text = "ON/OFF"
        '
        'DomainUpDownSSMB
        '
        Me.DomainUpDownSSMB.Items.Add("ON")
        Me.DomainUpDownSSMB.Items.Add("OFF")
        Me.DomainUpDownSSMB.Location = New System.Drawing.Point(420, 56)
        Me.DomainUpDownSSMB.Name = "DomainUpDownSSMB"
        Me.DomainUpDownSSMB.ReadOnly = True
        Me.DomainUpDownSSMB.Size = New System.Drawing.Size(61, 20)
        Me.DomainUpDownSSMB.TabIndex = 109
        Me.DomainUpDownSSMB.Text = "ON/OFF"
        '
        'DomainUpDownMLMB
        '
        Me.DomainUpDownMLMB.Items.Add("ON")
        Me.DomainUpDownMLMB.Items.Add("OFF")
        Me.DomainUpDownMLMB.Location = New System.Drawing.Point(216, 110)
        Me.DomainUpDownMLMB.Name = "DomainUpDownMLMB"
        Me.DomainUpDownMLMB.ReadOnly = True
        Me.DomainUpDownMLMB.Size = New System.Drawing.Size(65, 20)
        Me.DomainUpDownMLMB.TabIndex = 96
        Me.DomainUpDownMLMB.Text = "ON/OFF"
        '
        'NumericUpDownAMB
        '
        Me.NumericUpDownAMB.Location = New System.Drawing.Point(138, 178)
        Me.NumericUpDownAMB.Maximum = New Decimal(New Integer() {28, 0, 0, 0})
        Me.NumericUpDownAMB.Minimum = New Decimal(New Integer() {16, 0, 0, 0})
        Me.NumericUpDownAMB.Name = "NumericUpDownAMB"
        Me.NumericUpDownAMB.ReadOnly = True
        Me.NumericUpDownAMB.Size = New System.Drawing.Size(67, 20)
        Me.NumericUpDownAMB.TabIndex = 107
        Me.NumericUpDownAMB.Value = New Decimal(New Integer() {16, 0, 0, 0})
        Me.NumericUpDownAMB.Visible = False
        '
        'LabelTempAMB
        '
        Me.LabelTempAMB.AutoSize = True
        Me.LabelTempAMB.Location = New System.Drawing.Point(138, 162)
        Me.LabelTempAMB.Name = "LabelTempAMB"
        Me.LabelTempAMB.Size = New System.Drawing.Size(48, 13)
        Me.LabelTempAMB.TabIndex = 108
        Me.LabelTempAMB.Text = "Temp °C"
        Me.LabelTempAMB.Visible = False
        '
        'LinkLabelAirMB
        '
        Me.LinkLabelAirMB.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelAirMB.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelAirMB.LinkColor = System.Drawing.Color.White
        Me.LinkLabelAirMB.Location = New System.Drawing.Point(10, 135)
        Me.LinkLabelAirMB.Name = "LinkLabelAirMB"
        Me.LinkLabelAirMB.Size = New System.Drawing.Size(122, 63)
        Me.LinkLabelAirMB.TabIndex = 106
        Me.LinkLabelAirMB.TabStop = True
        Me.LinkLabelAirMB.Text = "Air"
        Me.LinkLabelAirMB.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'PictureBoxAirMB
        '
        Me.PictureBoxAirMB.BackgroundImage = CType(resources.GetObject("PictureBoxAirMB.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxAirMB.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxAirMB.Location = New System.Drawing.Point(10, 146)
        Me.PictureBoxAirMB.Name = "PictureBoxAirMB"
        Me.PictureBoxAirMB.Size = New System.Drawing.Size(122, 52)
        Me.PictureBoxAirMB.TabIndex = 105
        Me.PictureBoxAirMB.TabStop = False
        '
        'LinkLabelSSMB
        '
        Me.LinkLabelSSMB.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelSSMB.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelSSMB.LinkColor = System.Drawing.Color.White
        Me.LinkLabelSSMB.Location = New System.Drawing.Point(419, 79)
        Me.LinkLabelSSMB.Name = "LinkLabelSSMB"
        Me.LinkLabelSSMB.Size = New System.Drawing.Size(102, 81)
        Me.LinkLabelSSMB.TabIndex = 104
        Me.LinkLabelSSMB.TabStop = True
        Me.LinkLabelSSMB.Text = "Stereo"
        Me.LinkLabelSSMB.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'LinkLabelTVMB
        '
        Me.LinkLabelTVMB.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelTVMB.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelTVMB.LinkColor = System.Drawing.Color.White
        Me.LinkLabelTVMB.Location = New System.Drawing.Point(419, 201)
        Me.LinkLabelTVMB.Name = "LinkLabelTVMB"
        Me.LinkLabelTVMB.Size = New System.Drawing.Size(101, 93)
        Me.LinkLabelTVMB.TabIndex = 103
        Me.LinkLabelTVMB.TabStop = True
        Me.LinkLabelTVMB.Text = "TV"
        Me.LinkLabelTVMB.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'LinkLabelSeclightsMB
        '
        Me.LinkLabelSeclightsMB.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelSeclightsMB.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelSeclightsMB.LinkColor = System.Drawing.Color.White
        Me.LinkLabelSeclightsMB.Location = New System.Drawing.Point(306, 195)
        Me.LinkLabelSeclightsMB.Name = "LinkLabelSeclightsMB"
        Me.LinkLabelSeclightsMB.Size = New System.Drawing.Size(105, 104)
        Me.LinkLabelSeclightsMB.TabIndex = 99
        Me.LinkLabelSeclightsMB.TabStop = True
        Me.LinkLabelSeclightsMB.Text = "Sec Lights"
        Me.LinkLabelSeclightsMB.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'LinkLabelMainLightsMB
        '
        Me.LinkLabelMainLightsMB.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelMainLightsMB.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelMainLightsMB.LinkColor = System.Drawing.SystemColors.ActiveCaption
        Me.LinkLabelMainLightsMB.Location = New System.Drawing.Point(97, 12)
        Me.LinkLabelMainLightsMB.Name = "LinkLabelMainLightsMB"
        Me.LinkLabelMainLightsMB.Size = New System.Drawing.Size(122, 126)
        Me.LinkLabelMainLightsMB.TabIndex = 98
        Me.LinkLabelMainLightsMB.TabStop = True
        Me.LinkLabelMainLightsMB.Text = "Main Lights"
        Me.LinkLabelMainLightsMB.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'PictureBoxMainLightsMB
        '
        Me.PictureBoxMainLightsMB.BackColor = System.Drawing.Color.Transparent
        Me.PictureBoxMainLightsMB.BackgroundImage = CType(resources.GetObject("PictureBoxMainLightsMB.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxMainLightsMB.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxMainLightsMB.Location = New System.Drawing.Point(97, 12)
        Me.PictureBoxMainLightsMB.Name = "PictureBoxMainLightsMB"
        Me.PictureBoxMainLightsMB.Size = New System.Drawing.Size(117, 120)
        Me.PictureBoxMainLightsMB.TabIndex = 97
        Me.PictureBoxMainLightsMB.TabStop = False
        '
        'PictureBoxSeclightsMB
        '
        Me.PictureBoxSeclightsMB.BackColor = System.Drawing.Color.Transparent
        Me.PictureBoxSeclightsMB.BackgroundImage = CType(resources.GetObject("PictureBoxSeclightsMB.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxSeclightsMB.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxSeclightsMB.Location = New System.Drawing.Point(307, 221)
        Me.PictureBoxSeclightsMB.Name = "PictureBoxSeclightsMB"
        Me.PictureBoxSeclightsMB.Size = New System.Drawing.Size(32, 78)
        Me.PictureBoxSeclightsMB.TabIndex = 100
        Me.PictureBoxSeclightsMB.TabStop = False
        '
        'PictureBoxSSMB
        '
        Me.PictureBoxSSMB.BackgroundImage = CType(resources.GetObject("PictureBoxSSMB.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxSSMB.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxSSMB.Location = New System.Drawing.Point(421, 110)
        Me.PictureBoxSSMB.Name = "PictureBoxSSMB"
        Me.PictureBoxSSMB.Size = New System.Drawing.Size(98, 50)
        Me.PictureBoxSSMB.TabIndex = 102
        Me.PictureBoxSSMB.TabStop = False
        '
        'PictureBoxTVMB
        '
        Me.PictureBoxTVMB.BackgroundImage = CType(resources.GetObject("PictureBoxTVMB.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxTVMB.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxTVMB.Location = New System.Drawing.Point(420, 232)
        Me.PictureBoxTVMB.Name = "PictureBoxTVMB"
        Me.PictureBoxTVMB.Size = New System.Drawing.Size(100, 62)
        Me.PictureBoxTVMB.TabIndex = 101
        Me.PictureBoxTVMB.TabStop = False
        '
        'DomainUpDownSLMB
        '
        Me.DomainUpDownSLMB.Items.Add("ON")
        Me.DomainUpDownSLMB.Items.Add("OFF")
        Me.DomainUpDownSLMB.Location = New System.Drawing.Point(247, 244)
        Me.DomainUpDownSLMB.Name = "DomainUpDownSLMB"
        Me.DomainUpDownSLMB.ReadOnly = True
        Me.DomainUpDownSLMB.Size = New System.Drawing.Size(61, 20)
        Me.DomainUpDownSLMB.TabIndex = 110
        Me.DomainUpDownSLMB.Text = "ON/OFF"
        '
        'LinkLabelFPMB
        '
        Me.LinkLabelFPMB.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelFPMB.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelFPMB.LinkColor = System.Drawing.Color.White
        Me.LinkLabelFPMB.Location = New System.Drawing.Point(5, 282)
        Me.LinkLabelFPMB.Name = "LinkLabelFPMB"
        Me.LinkLabelFPMB.Size = New System.Drawing.Size(106, 134)
        Me.LinkLabelFPMB.TabIndex = 113
        Me.LinkLabelFPMB.TabStop = True
        Me.LinkLabelFPMB.Text = "Fire Place"
        Me.LinkLabelFPMB.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'DomainUpDownFPMB
        '
        Me.DomainUpDownFPMB.Items.Add("ON")
        Me.DomainUpDownFPMB.Items.Add("OFF")
        Me.DomainUpDownFPMB.Location = New System.Drawing.Point(115, 305)
        Me.DomainUpDownFPMB.Name = "DomainUpDownFPMB"
        Me.DomainUpDownFPMB.ReadOnly = True
        Me.DomainUpDownFPMB.Size = New System.Drawing.Size(61, 20)
        Me.DomainUpDownFPMB.TabIndex = 112
        Me.DomainUpDownFPMB.Text = "ON/OFF"
        '
        'PictureBoxFPMB
        '
        Me.PictureBoxFPMB.BackgroundImage = CType(resources.GetObject("PictureBoxFPMB.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxFPMB.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxFPMB.Location = New System.Drawing.Point(5, 305)
        Me.PictureBoxFPMB.Name = "PictureBoxFPMB"
        Me.PictureBoxFPMB.Size = New System.Drawing.Size(93, 111)
        Me.PictureBoxFPMB.TabIndex = 111
        Me.PictureBoxFPMB.TabStop = False
        '
        'HelpProvider1
        '
        Me.HelpProvider1.HelpNamespace = "C:\Users\Morpheus\Desktop\Dun.chm"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(15, 396)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(62, 20)
        Me.TextBox1.TabIndex = 151
        Me.TextBox1.Visible = False
        '
        'FormMainBedroom
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(584, 452)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.LinkLabelFPMB)
        Me.Controls.Add(Me.DomainUpDownFPMB)
        Me.Controls.Add(Me.PictureBoxFPMB)
        Me.Controls.Add(Me.DomainUpDownSLMB)
        Me.Controls.Add(Me.DomainUpDownTVMB)
        Me.Controls.Add(Me.DomainUpDownSSMB)
        Me.Controls.Add(Me.DomainUpDownMLMB)
        Me.Controls.Add(Me.NumericUpDownAMB)
        Me.Controls.Add(Me.LabelTempAMB)
        Me.Controls.Add(Me.LinkLabelAirMB)
        Me.Controls.Add(Me.PictureBoxAirMB)
        Me.Controls.Add(Me.LinkLabelSSMB)
        Me.Controls.Add(Me.LinkLabelTVMB)
        Me.Controls.Add(Me.LinkLabelSeclightsMB)
        Me.Controls.Add(Me.LinkLabelMainLightsMB)
        Me.Controls.Add(Me.PictureBoxMainLightsMB)
        Me.Controls.Add(Me.PictureBoxSeclightsMB)
        Me.Controls.Add(Me.PictureBoxSSMB)
        Me.Controls.Add(Me.PictureBoxTVMB)
        Me.Controls.Add(Me.MenuStripFile)
        Me.Controls.Add(Me.ButtonBackM)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "FormMainBedroom"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Main Bedroom"
        Me.MenuStripFile.ResumeLayout(False)
        Me.MenuStripFile.PerformLayout()
        CType(Me.NumericUpDownAMB, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxAirMB, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxMainLightsMB, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxSeclightsMB, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxSSMB, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxTVMB, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxFPMB, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ButtonBackM As System.Windows.Forms.Button
    Friend WithEvents MenuStripFile As System.Windows.Forms.MenuStrip
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ContactToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitControlerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DomainUpDownTVMB As System.Windows.Forms.DomainUpDown
    Friend WithEvents DomainUpDownSSMB As System.Windows.Forms.DomainUpDown
    Friend WithEvents DomainUpDownMLMB As System.Windows.Forms.DomainUpDown
    Friend WithEvents NumericUpDownAMB As System.Windows.Forms.NumericUpDown
    Friend WithEvents LabelTempAMB As System.Windows.Forms.Label
    Friend WithEvents LinkLabelAirMB As System.Windows.Forms.LinkLabel
    Friend WithEvents PictureBoxAirMB As System.Windows.Forms.PictureBox
    Friend WithEvents LinkLabelSSMB As System.Windows.Forms.LinkLabel
    Friend WithEvents LinkLabelTVMB As System.Windows.Forms.LinkLabel
    Friend WithEvents LinkLabelSeclightsMB As System.Windows.Forms.LinkLabel
    Friend WithEvents LinkLabelMainLightsMB As System.Windows.Forms.LinkLabel
    Friend WithEvents PictureBoxMainLightsMB As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBoxSeclightsMB As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBoxSSMB As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBoxTVMB As System.Windows.Forms.PictureBox
    Friend WithEvents DomainUpDownSLMB As System.Windows.Forms.DomainUpDown
    Friend WithEvents LinkLabelFPMB As System.Windows.Forms.LinkLabel
    Friend WithEvents DomainUpDownFPMB As System.Windows.Forms.DomainUpDown
    Friend WithEvents PictureBoxFPMB As System.Windows.Forms.PictureBox
    Friend WithEvents LogOutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpProvider1 As System.Windows.Forms.HelpProvider
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
End Class
