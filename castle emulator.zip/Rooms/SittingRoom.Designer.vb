﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormSittingRoom
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormSittingRoom))
        Me.MenuStripFile = New System.Windows.Forms.MenuStrip()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ContactToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LogOutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitControlerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DomainUpDownTVS = New System.Windows.Forms.DomainUpDown()
        Me.DomainUpDownSSS = New System.Windows.Forms.DomainUpDown()
        Me.DomainUpDownSLS = New System.Windows.Forms.DomainUpDown()
        Me.DomainUpDownMLS = New System.Windows.Forms.DomainUpDown()
        Me.NumericUpDownAS = New System.Windows.Forms.NumericUpDown()
        Me.LabelTempAS = New System.Windows.Forms.Label()
        Me.LinkLabelAirS = New System.Windows.Forms.LinkLabel()
        Me.PictureBoxAirS = New System.Windows.Forms.PictureBox()
        Me.LinkLabelSSS = New System.Windows.Forms.LinkLabel()
        Me.LinkLabelTVS = New System.Windows.Forms.LinkLabel()
        Me.ButtonBackS = New System.Windows.Forms.Button()
        Me.LinkLabelSeclightsS = New System.Windows.Forms.LinkLabel()
        Me.LinkLabelMainLightsS = New System.Windows.Forms.LinkLabel()
        Me.PictureBoxMainLightsS = New System.Windows.Forms.PictureBox()
        Me.PictureBoxSeclightsS = New System.Windows.Forms.PictureBox()
        Me.PictureBoxSSS = New System.Windows.Forms.PictureBox()
        Me.PictureBoxTVS = New System.Windows.Forms.PictureBox()
        Me.PictureBoxFPS = New System.Windows.Forms.PictureBox()
        Me.DomainUpDownFPS = New System.Windows.Forms.DomainUpDown()
        Me.LinkLabelFPS = New System.Windows.Forms.LinkLabel()
        Me.HelpProvider1 = New System.Windows.Forms.HelpProvider()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.MenuStripFile.SuspendLayout()
        CType(Me.NumericUpDownAS, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxAirS, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxMainLightsS, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxSeclightsS, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxSSS, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxTVS, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxFPS, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'MenuStripFile
        '
        Me.MenuStripFile.BackColor = System.Drawing.Color.Transparent
        Me.MenuStripFile.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.MenuStripFile.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem1})
        Me.MenuStripFile.Location = New System.Drawing.Point(0, 0)
        Me.MenuStripFile.Name = "MenuStripFile"
        Me.MenuStripFile.ShowItemToolTips = True
        Me.MenuStripFile.Size = New System.Drawing.Size(584, 24)
        Me.MenuStripFile.TabIndex = 19
        Me.MenuStripFile.Text = "MenuStrip1"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ContactToolStripMenuItem, Me.HelpToolStripMenuItem, Me.AboutToolStripMenuItem, Me.LogOutToolStripMenuItem, Me.ExitControlerToolStripMenuItem})
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(37, 20)
        Me.ToolStripMenuItem1.Text = "File"
        '
        'ContactToolStripMenuItem
        '
        Me.ContactToolStripMenuItem.Name = "ContactToolStripMenuItem"
        Me.ContactToolStripMenuItem.Size = New System.Drawing.Size(145, 22)
        Me.ContactToolStripMenuItem.Text = "Contact"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(145, 22)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(145, 22)
        Me.AboutToolStripMenuItem.Text = "About"
        '
        'LogOutToolStripMenuItem
        '
        Me.LogOutToolStripMenuItem.Name = "LogOutToolStripMenuItem"
        Me.LogOutToolStripMenuItem.Size = New System.Drawing.Size(145, 22)
        Me.LogOutToolStripMenuItem.Text = "Log Out"
        '
        'ExitControlerToolStripMenuItem
        '
        Me.ExitControlerToolStripMenuItem.Name = "ExitControlerToolStripMenuItem"
        Me.ExitControlerToolStripMenuItem.Size = New System.Drawing.Size(145, 22)
        Me.ExitControlerToolStripMenuItem.Text = "Exit Controler"
        '
        'DomainUpDownTVS
        '
        Me.DomainUpDownTVS.Items.Add("ON")
        Me.DomainUpDownTVS.Items.Add("OFF")
        Me.DomainUpDownTVS.Location = New System.Drawing.Point(251, 123)
        Me.DomainUpDownTVS.Name = "DomainUpDownTVS"
        Me.DomainUpDownTVS.ReadOnly = True
        Me.DomainUpDownTVS.Size = New System.Drawing.Size(61, 20)
        Me.DomainUpDownTVS.TabIndex = 58
        Me.DomainUpDownTVS.Text = "ON/OFF"
        '
        'DomainUpDownSSS
        '
        Me.DomainUpDownSSS.Items.Add("ON")
        Me.DomainUpDownSSS.Items.Add("OFF")
        Me.DomainUpDownSSS.Location = New System.Drawing.Point(30, 123)
        Me.DomainUpDownSSS.Name = "DomainUpDownSSS"
        Me.DomainUpDownSSS.ReadOnly = True
        Me.DomainUpDownSSS.Size = New System.Drawing.Size(61, 20)
        Me.DomainUpDownSSS.TabIndex = 94
        Me.DomainUpDownSSS.Text = "ON/OFF"
        '
        'DomainUpDownSLS
        '
        Me.DomainUpDownSLS.Items.Add("ON")
        Me.DomainUpDownSLS.Items.Add("OFF")
        Me.DomainUpDownSLS.Location = New System.Drawing.Point(455, 214)
        Me.DomainUpDownSLS.Name = "DomainUpDownSLS"
        Me.DomainUpDownSLS.ReadOnly = True
        Me.DomainUpDownSLS.Size = New System.Drawing.Size(61, 20)
        Me.DomainUpDownSLS.TabIndex = 59
        Me.DomainUpDownSLS.Text = "ON/OFF"
        '
        'DomainUpDownMLS
        '
        Me.DomainUpDownMLS.Items.Add("ON")
        Me.DomainUpDownMLS.Items.Add("OFF")
        Me.DomainUpDownMLS.Location = New System.Drawing.Point(169, 27)
        Me.DomainUpDownMLS.Name = "DomainUpDownMLS"
        Me.DomainUpDownMLS.ReadOnly = True
        Me.DomainUpDownMLS.Size = New System.Drawing.Size(65, 20)
        Me.DomainUpDownMLS.TabIndex = 60
        Me.DomainUpDownMLS.Text = "ON/OFF"
        '
        'NumericUpDownAS
        '
        Me.NumericUpDownAS.Location = New System.Drawing.Point(380, 62)
        Me.NumericUpDownAS.Maximum = New Decimal(New Integer() {28, 0, 0, 0})
        Me.NumericUpDownAS.Minimum = New Decimal(New Integer() {16, 0, 0, 0})
        Me.NumericUpDownAS.Name = "NumericUpDownAS"
        Me.NumericUpDownAS.ReadOnly = True
        Me.NumericUpDownAS.Size = New System.Drawing.Size(67, 20)
        Me.NumericUpDownAS.TabIndex = 91
        Me.NumericUpDownAS.Value = New Decimal(New Integer() {16, 0, 0, 0})
        Me.NumericUpDownAS.Visible = False
        '
        'LabelTempAS
        '
        Me.LabelTempAS.AutoSize = True
        Me.LabelTempAS.Location = New System.Drawing.Point(378, 47)
        Me.LabelTempAS.Name = "LabelTempAS"
        Me.LabelTempAS.Size = New System.Drawing.Size(48, 13)
        Me.LabelTempAS.TabIndex = 92
        Me.LabelTempAS.Text = "Temp °C"
        Me.LabelTempAS.Visible = False
        '
        'LinkLabelAirS
        '
        Me.LinkLabelAirS.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelAirS.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelAirS.LinkColor = System.Drawing.Color.White
        Me.LinkLabelAirS.Location = New System.Drawing.Point(450, 31)
        Me.LinkLabelAirS.Name = "LinkLabelAirS"
        Me.LinkLabelAirS.Size = New System.Drawing.Size(122, 63)
        Me.LinkLabelAirS.TabIndex = 81
        Me.LinkLabelAirS.TabStop = True
        Me.LinkLabelAirS.Text = "Air"
        Me.LinkLabelAirS.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'PictureBoxAirS
        '
        Me.PictureBoxAirS.BackgroundImage = CType(resources.GetObject("PictureBoxAirS.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxAirS.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxAirS.Location = New System.Drawing.Point(450, 38)
        Me.PictureBoxAirS.Name = "PictureBoxAirS"
        Me.PictureBoxAirS.Size = New System.Drawing.Size(122, 52)
        Me.PictureBoxAirS.TabIndex = 80
        Me.PictureBoxAirS.TabStop = False
        '
        'LinkLabelSSS
        '
        Me.LinkLabelSSS.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelSSS.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelSSS.LinkColor = System.Drawing.Color.White
        Me.LinkLabelSSS.Location = New System.Drawing.Point(13, 38)
        Me.LinkLabelSSS.Name = "LinkLabelSSS"
        Me.LinkLabelSSS.Size = New System.Drawing.Size(102, 81)
        Me.LinkLabelSSS.TabIndex = 79
        Me.LinkLabelSSS.TabStop = True
        Me.LinkLabelSSS.Text = "Stereo"
        Me.LinkLabelSSS.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'LinkLabelTVS
        '
        Me.LinkLabelTVS.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelTVS.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelTVS.LinkColor = System.Drawing.Color.White
        Me.LinkLabelTVS.Location = New System.Drawing.Point(250, 123)
        Me.LinkLabelTVS.Name = "LinkLabelTVS"
        Me.LinkLabelTVS.Size = New System.Drawing.Size(101, 93)
        Me.LinkLabelTVS.TabIndex = 78
        Me.LinkLabelTVS.TabStop = True
        Me.LinkLabelTVS.Text = "TV"
        Me.LinkLabelTVS.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'ButtonBackS
        '
        Me.ButtonBackS.Location = New System.Drawing.Point(462, 416)
        Me.ButtonBackS.Name = "ButtonBackS"
        Me.ButtonBackS.Size = New System.Drawing.Size(110, 25)
        Me.ButtonBackS.TabIndex = 61
        Me.ButtonBackS.Text = "Back"
        Me.ButtonBackS.UseVisualStyleBackColor = True
        '
        'LinkLabelSeclightsS
        '
        Me.LinkLabelSeclightsS.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelSeclightsS.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelSeclightsS.LinkColor = System.Drawing.Color.White
        Me.LinkLabelSeclightsS.Location = New System.Drawing.Point(411, 130)
        Me.LinkLabelSeclightsS.Name = "LinkLabelSeclightsS"
        Me.LinkLabelSeclightsS.Size = New System.Drawing.Size(105, 94)
        Me.LinkLabelSeclightsS.TabIndex = 72
        Me.LinkLabelSeclightsS.TabStop = True
        Me.LinkLabelSeclightsS.Text = "Sec Lights"
        Me.LinkLabelSeclightsS.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'LinkLabelMainLightsS
        '
        Me.LinkLabelMainLightsS.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelMainLightsS.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelMainLightsS.LinkColor = System.Drawing.Color.Yellow
        Me.LinkLabelMainLightsS.Location = New System.Drawing.Point(240, 24)
        Me.LinkLabelMainLightsS.Name = "LinkLabelMainLightsS"
        Me.LinkLabelMainLightsS.Size = New System.Drawing.Size(121, 76)
        Me.LinkLabelMainLightsS.TabIndex = 67
        Me.LinkLabelMainLightsS.TabStop = True
        Me.LinkLabelMainLightsS.Text = "Main Lights"
        Me.LinkLabelMainLightsS.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'PictureBoxMainLightsS
        '
        Me.PictureBoxMainLightsS.BackColor = System.Drawing.Color.Transparent
        Me.PictureBoxMainLightsS.BackgroundImage = CType(resources.GetObject("PictureBoxMainLightsS.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxMainLightsS.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxMainLightsS.Location = New System.Drawing.Point(240, 24)
        Me.PictureBoxMainLightsS.Name = "PictureBoxMainLightsS"
        Me.PictureBoxMainLightsS.Size = New System.Drawing.Size(121, 76)
        Me.PictureBoxMainLightsS.TabIndex = 66
        Me.PictureBoxMainLightsS.TabStop = False
        '
        'PictureBoxSeclightsS
        '
        Me.PictureBoxSeclightsS.BackColor = System.Drawing.Color.Transparent
        Me.PictureBoxSeclightsS.BackgroundImage = CType(resources.GetObject("PictureBoxSeclightsS.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxSeclightsS.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxSeclightsS.Location = New System.Drawing.Point(416, 136)
        Me.PictureBoxSeclightsS.Name = "PictureBoxSeclightsS"
        Me.PictureBoxSeclightsS.Size = New System.Drawing.Size(41, 88)
        Me.PictureBoxSeclightsS.TabIndex = 73
        Me.PictureBoxSeclightsS.TabStop = False
        '
        'PictureBoxSSS
        '
        Me.PictureBoxSSS.BackgroundImage = CType(resources.GetObject("PictureBoxSSS.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxSSS.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxSSS.Location = New System.Drawing.Point(17, 63)
        Me.PictureBoxSSS.Name = "PictureBoxSSS"
        Me.PictureBoxSSS.Size = New System.Drawing.Size(98, 50)
        Me.PictureBoxSSS.TabIndex = 77
        Me.PictureBoxSSS.TabStop = False
        '
        'PictureBoxTVS
        '
        Me.PictureBoxTVS.BackgroundImage = CType(resources.GetObject("PictureBoxTVS.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxTVS.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxTVS.Location = New System.Drawing.Point(251, 149)
        Me.PictureBoxTVS.Name = "PictureBoxTVS"
        Me.PictureBoxTVS.Size = New System.Drawing.Size(100, 62)
        Me.PictureBoxTVS.TabIndex = 76
        Me.PictureBoxTVS.TabStop = False
        '
        'PictureBoxFPS
        '
        Me.PictureBoxFPS.BackgroundImage = CType(resources.GetObject("PictureBoxFPS.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxFPS.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxFPS.Location = New System.Drawing.Point(226, 244)
        Me.PictureBoxFPS.Name = "PictureBoxFPS"
        Me.PictureBoxFPS.Size = New System.Drawing.Size(155, 79)
        Me.PictureBoxFPS.TabIndex = 95
        Me.PictureBoxFPS.TabStop = False
        '
        'DomainUpDownFPS
        '
        Me.DomainUpDownFPS.Items.Add("ON")
        Me.DomainUpDownFPS.Items.Add("OFF")
        Me.DomainUpDownFPS.Location = New System.Drawing.Point(381, 244)
        Me.DomainUpDownFPS.Name = "DomainUpDownFPS"
        Me.DomainUpDownFPS.ReadOnly = True
        Me.DomainUpDownFPS.Size = New System.Drawing.Size(61, 20)
        Me.DomainUpDownFPS.TabIndex = 96
        Me.DomainUpDownFPS.Text = "ON/OFF"
        '
        'LinkLabelFPS
        '
        Me.LinkLabelFPS.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelFPS.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelFPS.LinkColor = System.Drawing.Color.White
        Me.LinkLabelFPS.Location = New System.Drawing.Point(221, 230)
        Me.LinkLabelFPS.Name = "LinkLabelFPS"
        Me.LinkLabelFPS.Size = New System.Drawing.Size(160, 93)
        Me.LinkLabelFPS.TabIndex = 97
        Me.LinkLabelFPS.TabStop = True
        Me.LinkLabelFPS.Text = "Fire Place"
        Me.LinkLabelFPS.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'HelpProvider1
        '
        Me.HelpProvider1.HelpNamespace = "C:\Users\Morpheus\Desktop\Dun.chm"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(29, 290)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(62, 20)
        Me.TextBox1.TabIndex = 151
        Me.TextBox1.Visible = False
        '
        'PictureBox2
        '
        Me.PictureBox2.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox2.BackgroundImage = CType(resources.GetObject("PictureBox2.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox2.Location = New System.Drawing.Point(147, 136)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(33, 75)
        Me.PictureBox2.TabIndex = 181
        Me.PictureBox2.TabStop = False
        Me.PictureBox2.Visible = False
        '
        'FormSittingRoom
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(584, 452)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.LinkLabelFPS)
        Me.Controls.Add(Me.DomainUpDownFPS)
        Me.Controls.Add(Me.DomainUpDownTVS)
        Me.Controls.Add(Me.DomainUpDownSSS)
        Me.Controls.Add(Me.DomainUpDownSLS)
        Me.Controls.Add(Me.DomainUpDownMLS)
        Me.Controls.Add(Me.NumericUpDownAS)
        Me.Controls.Add(Me.LabelTempAS)
        Me.Controls.Add(Me.LinkLabelAirS)
        Me.Controls.Add(Me.PictureBoxAirS)
        Me.Controls.Add(Me.LinkLabelSSS)
        Me.Controls.Add(Me.LinkLabelTVS)
        Me.Controls.Add(Me.ButtonBackS)
        Me.Controls.Add(Me.LinkLabelSeclightsS)
        Me.Controls.Add(Me.LinkLabelMainLightsS)
        Me.Controls.Add(Me.PictureBoxMainLightsS)
        Me.Controls.Add(Me.PictureBoxSeclightsS)
        Me.Controls.Add(Me.PictureBoxSSS)
        Me.Controls.Add(Me.PictureBoxTVS)
        Me.Controls.Add(Me.MenuStripFile)
        Me.Controls.Add(Me.PictureBoxFPS)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "FormSittingRoom"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Sitting Room"
        Me.MenuStripFile.ResumeLayout(False)
        Me.MenuStripFile.PerformLayout()
        CType(Me.NumericUpDownAS, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxAirS, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxMainLightsS, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxSeclightsS, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxSSS, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxTVS, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxFPS, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout

End Sub
    Friend WithEvents MenuStripFile As System.Windows.Forms.MenuStrip
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ContactToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitControlerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DomainUpDownTVS As System.Windows.Forms.DomainUpDown
    Friend WithEvents DomainUpDownSSS As System.Windows.Forms.DomainUpDown
    Friend WithEvents DomainUpDownSLS As System.Windows.Forms.DomainUpDown
    Friend WithEvents DomainUpDownMLS As System.Windows.Forms.DomainUpDown
    Friend WithEvents NumericUpDownAS As System.Windows.Forms.NumericUpDown
    Friend WithEvents LabelTempAS As System.Windows.Forms.Label
    Friend WithEvents LinkLabelAirS As System.Windows.Forms.LinkLabel
    Friend WithEvents PictureBoxAirS As System.Windows.Forms.PictureBox
    Friend WithEvents LinkLabelSSS As System.Windows.Forms.LinkLabel
    Friend WithEvents LinkLabelTVS As System.Windows.Forms.LinkLabel
    Friend WithEvents ButtonBackS As System.Windows.Forms.Button
    Friend WithEvents LinkLabelSeclightsS As System.Windows.Forms.LinkLabel
    Friend WithEvents LinkLabelMainLightsS As System.Windows.Forms.LinkLabel
    Friend WithEvents PictureBoxMainLightsS As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBoxSeclightsS As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBoxSSS As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBoxTVS As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBoxFPS As System.Windows.Forms.PictureBox
    Friend WithEvents DomainUpDownFPS As System.Windows.Forms.DomainUpDown
    Friend WithEvents LinkLabelFPS As System.Windows.Forms.LinkLabel
    Friend WithEvents LogOutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpProvider1 As System.Windows.Forms.HelpProvider
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
End Class
