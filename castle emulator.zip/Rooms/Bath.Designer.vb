﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormBath
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormBath))
        Me.MenuStripFile = New System.Windows.Forms.MenuStrip()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ContactToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LogOutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitControlerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DomainUpDownMLB = New System.Windows.Forms.DomainUpDown()
        Me.NumericUpDownAB = New System.Windows.Forms.NumericUpDown()
        Me.LinkLabelAirB = New System.Windows.Forms.LinkLabel()
        Me.PictureBoxAirB = New System.Windows.Forms.PictureBox()
        Me.LinkLabelSSB = New System.Windows.Forms.LinkLabel()
        Me.LinkLabelMainLightsB = New System.Windows.Forms.LinkLabel()
        Me.PictureBoxMainLightsB = New System.Windows.Forms.PictureBox()
        Me.PictureBoxSSB = New System.Windows.Forms.PictureBox()
        Me.LabelTempAB = New System.Windows.Forms.Label()
        Me.LinkLabelFPB = New System.Windows.Forms.LinkLabel()
        Me.DomainUpDownFPB = New System.Windows.Forms.DomainUpDown()
        Me.PictureBoxFPB = New System.Windows.Forms.PictureBox()
        Me.DomainUpDownSSB = New System.Windows.Forms.DomainUpDown()
        Me.ButtonBackB = New System.Windows.Forms.Button()
        Me.DomainUpDownSLB = New System.Windows.Forms.DomainUpDown()
        Me.LinkLabelSeclightsB = New System.Windows.Forms.LinkLabel()
        Me.PictureBoxSeclightsB = New System.Windows.Forms.PictureBox()
        Me.LabelTempWB = New System.Windows.Forms.Label()
        Me.NumericUpDownWB = New System.Windows.Forms.NumericUpDown()
        Me.LinkLabelWaterB = New System.Windows.Forms.LinkLabel()
        Me.PictureBoxWaterB = New System.Windows.Forms.PictureBox()
        Me.HelpProvider1 = New System.Windows.Forms.HelpProvider()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.MenuStripFile.SuspendLayout()
        CType(Me.NumericUpDownAB, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxAirB, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxMainLightsB, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxSSB, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxFPB, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxSeclightsB, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDownWB, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxWaterB, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'MenuStripFile
        '
        Me.MenuStripFile.BackColor = System.Drawing.Color.Transparent
        Me.MenuStripFile.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.MenuStripFile.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem1})
        Me.MenuStripFile.Location = New System.Drawing.Point(0, 0)
        Me.MenuStripFile.Name = "MenuStripFile"
        Me.MenuStripFile.ShowItemToolTips = True
        Me.MenuStripFile.Size = New System.Drawing.Size(584, 24)
        Me.MenuStripFile.TabIndex = 6
        Me.MenuStripFile.Text = "MenuStrip1"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ContactToolStripMenuItem, Me.HelpToolStripMenuItem, Me.AboutToolStripMenuItem, Me.LogOutToolStripMenuItem, Me.ExitControlerToolStripMenuItem})
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(37, 20)
        Me.ToolStripMenuItem1.Text = "File"
        '
        'ContactToolStripMenuItem
        '
        Me.ContactToolStripMenuItem.Name = "ContactToolStripMenuItem"
        Me.ContactToolStripMenuItem.Size = New System.Drawing.Size(145, 22)
        Me.ContactToolStripMenuItem.Text = "Contact"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(145, 22)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(145, 22)
        Me.AboutToolStripMenuItem.Text = "About"
        '
        'LogOutToolStripMenuItem
        '
        Me.LogOutToolStripMenuItem.Name = "LogOutToolStripMenuItem"
        Me.LogOutToolStripMenuItem.Size = New System.Drawing.Size(145, 22)
        Me.LogOutToolStripMenuItem.Text = "Log Out"
        '
        'ExitControlerToolStripMenuItem
        '
        Me.ExitControlerToolStripMenuItem.Name = "ExitControlerToolStripMenuItem"
        Me.ExitControlerToolStripMenuItem.Size = New System.Drawing.Size(145, 22)
        Me.ExitControlerToolStripMenuItem.Text = "Exit Controler"
        '
        'DomainUpDownMLB
        '
        Me.DomainUpDownMLB.Items.Add("ON")
        Me.DomainUpDownMLB.Items.Add("OFF")
        Me.DomainUpDownMLB.Location = New System.Drawing.Point(147, 59)
        Me.DomainUpDownMLB.Name = "DomainUpDownMLB"
        Me.DomainUpDownMLB.ReadOnly = True
        Me.DomainUpDownMLB.Size = New System.Drawing.Size(65, 20)
        Me.DomainUpDownMLB.TabIndex = 135
        Me.DomainUpDownMLB.Text = "ON/OFF"
        '
        'NumericUpDownAB
        '
        Me.NumericUpDownAB.Location = New System.Drawing.Point(354, 59)
        Me.NumericUpDownAB.Maximum = New Decimal(New Integer() {28, 0, 0, 0})
        Me.NumericUpDownAB.Minimum = New Decimal(New Integer() {16, 0, 0, 0})
        Me.NumericUpDownAB.Name = "NumericUpDownAB"
        Me.NumericUpDownAB.ReadOnly = True
        Me.NumericUpDownAB.Size = New System.Drawing.Size(67, 20)
        Me.NumericUpDownAB.TabIndex = 134
        Me.NumericUpDownAB.Value = New Decimal(New Integer() {16, 0, 0, 0})
        Me.NumericUpDownAB.Visible = False
        '
        'LinkLabelAirB
        '
        Me.LinkLabelAirB.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelAirB.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelAirB.LinkColor = System.Drawing.Color.White
        Me.LinkLabelAirB.Location = New System.Drawing.Point(422, 0)
        Me.LinkLabelAirB.Name = "LinkLabelAirB"
        Me.LinkLabelAirB.Size = New System.Drawing.Size(122, 79)
        Me.LinkLabelAirB.TabIndex = 133
        Me.LinkLabelAirB.TabStop = True
        Me.LinkLabelAirB.Text = "Air"
        Me.LinkLabelAirB.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'PictureBoxAirB
        '
        Me.PictureBoxAirB.BackgroundImage = CType(resources.GetObject("PictureBoxAirB.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxAirB.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxAirB.Location = New System.Drawing.Point(422, 27)
        Me.PictureBoxAirB.Name = "PictureBoxAirB"
        Me.PictureBoxAirB.Size = New System.Drawing.Size(122, 52)
        Me.PictureBoxAirB.TabIndex = 132
        Me.PictureBoxAirB.TabStop = False
        Me.PictureBoxAirB.WaitOnLoad = True
        '
        'LinkLabelSSB
        '
        Me.LinkLabelSSB.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelSSB.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelSSB.LinkColor = System.Drawing.Color.White
        Me.LinkLabelSSB.Location = New System.Drawing.Point(13, 146)
        Me.LinkLabelSSB.Name = "LinkLabelSSB"
        Me.LinkLabelSSB.Size = New System.Drawing.Size(102, 81)
        Me.LinkLabelSSB.TabIndex = 131
        Me.LinkLabelSSB.TabStop = True
        Me.LinkLabelSSB.Text = "Stereo"
        Me.LinkLabelSSB.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'LinkLabelMainLightsB
        '
        Me.LinkLabelMainLightsB.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelMainLightsB.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelMainLightsB.LinkColor = System.Drawing.Color.Yellow
        Me.LinkLabelMainLightsB.Location = New System.Drawing.Point(210, 0)
        Me.LinkLabelMainLightsB.Name = "LinkLabelMainLightsB"
        Me.LinkLabelMainLightsB.Size = New System.Drawing.Size(140, 119)
        Me.LinkLabelMainLightsB.TabIndex = 130
        Me.LinkLabelMainLightsB.TabStop = True
        Me.LinkLabelMainLightsB.Text = "Main Lights"
        Me.LinkLabelMainLightsB.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'PictureBoxMainLightsB
        '
        Me.PictureBoxMainLightsB.BackColor = System.Drawing.Color.Transparent
        Me.PictureBoxMainLightsB.BackgroundImage = CType(resources.GetObject("PictureBoxMainLightsB.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxMainLightsB.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxMainLightsB.Location = New System.Drawing.Point(215, 21)
        Me.PictureBoxMainLightsB.Name = "PictureBoxMainLightsB"
        Me.PictureBoxMainLightsB.Size = New System.Drawing.Size(127, 94)
        Me.PictureBoxMainLightsB.TabIndex = 129
        Me.PictureBoxMainLightsB.TabStop = False
        Me.PictureBoxMainLightsB.WaitOnLoad = True
        '
        'PictureBoxSSB
        '
        Me.PictureBoxSSB.BackgroundImage = CType(resources.GetObject("PictureBoxSSB.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxSSB.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxSSB.Location = New System.Drawing.Point(17, 178)
        Me.PictureBoxSSB.Name = "PictureBoxSSB"
        Me.PictureBoxSSB.Size = New System.Drawing.Size(98, 50)
        Me.PictureBoxSSB.TabIndex = 136
        Me.PictureBoxSSB.TabStop = False
        Me.PictureBoxSSB.WaitOnLoad = True
        '
        'LabelTempAB
        '
        Me.LabelTempAB.AutoSize = True
        Me.LabelTempAB.Location = New System.Drawing.Point(354, 45)
        Me.LabelTempAB.Name = "LabelTempAB"
        Me.LabelTempAB.Size = New System.Drawing.Size(48, 13)
        Me.LabelTempAB.TabIndex = 137
        Me.LabelTempAB.Text = "Temp °C"
        Me.LabelTempAB.Visible = False
        '
        'LinkLabelFPB
        '
        Me.LinkLabelFPB.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelFPB.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelFPB.LinkColor = System.Drawing.Color.White
        Me.LinkLabelFPB.Location = New System.Drawing.Point(399, 263)
        Me.LinkLabelFPB.Name = "LinkLabelFPB"
        Me.LinkLabelFPB.Size = New System.Drawing.Size(118, 131)
        Me.LinkLabelFPB.TabIndex = 140
        Me.LinkLabelFPB.TabStop = True
        Me.LinkLabelFPB.Text = "Fire Place"
        Me.LinkLabelFPB.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'DomainUpDownFPB
        '
        Me.DomainUpDownFPB.Items.Add("ON")
        Me.DomainUpDownFPB.Items.Add("OFF")
        Me.DomainUpDownFPB.Location = New System.Drawing.Point(332, 283)
        Me.DomainUpDownFPB.Name = "DomainUpDownFPB"
        Me.DomainUpDownFPB.ReadOnly = True
        Me.DomainUpDownFPB.Size = New System.Drawing.Size(61, 20)
        Me.DomainUpDownFPB.TabIndex = 139
        Me.DomainUpDownFPB.Text = "ON/OFF"
        '
        'PictureBoxFPB
        '
        Me.PictureBoxFPB.BackgroundImage = CType(resources.GetObject("PictureBoxFPB.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxFPB.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxFPB.Location = New System.Drawing.Point(404, 276)
        Me.PictureBoxFPB.Name = "PictureBoxFPB"
        Me.PictureBoxFPB.Size = New System.Drawing.Size(113, 118)
        Me.PictureBoxFPB.TabIndex = 138
        Me.PictureBoxFPB.TabStop = False
        Me.PictureBoxFPB.WaitOnLoad = True
        '
        'DomainUpDownSSB
        '
        Me.DomainUpDownSSB.Items.Add("ON")
        Me.DomainUpDownSSB.Items.Add("OFF")
        Me.DomainUpDownSSB.Location = New System.Drawing.Point(121, 208)
        Me.DomainUpDownSSB.Name = "DomainUpDownSSB"
        Me.DomainUpDownSSB.ReadOnly = True
        Me.DomainUpDownSSB.Size = New System.Drawing.Size(61, 20)
        Me.DomainUpDownSSB.TabIndex = 141
        Me.DomainUpDownSSB.Text = "ON/OFF"
        '
        'ButtonBackB
        '
        Me.ButtonBackB.Location = New System.Drawing.Point(451, 400)
        Me.ButtonBackB.Name = "ButtonBackB"
        Me.ButtonBackB.Size = New System.Drawing.Size(110, 25)
        Me.ButtonBackB.TabIndex = 142
        Me.ButtonBackB.Text = "Back"
        Me.ButtonBackB.UseVisualStyleBackColor = True
        '
        'DomainUpDownSLB
        '
        Me.DomainUpDownSLB.Items.Add("ON")
        Me.DomainUpDownSLB.Items.Add("OFF")
        Me.DomainUpDownSLB.Location = New System.Drawing.Point(317, 121)
        Me.DomainUpDownSLB.Name = "DomainUpDownSLB"
        Me.DomainUpDownSLB.ReadOnly = True
        Me.DomainUpDownSLB.Size = New System.Drawing.Size(61, 20)
        Me.DomainUpDownSLB.TabIndex = 145
        Me.DomainUpDownSLB.Text = "ON/OFF"
        '
        'LinkLabelSeclightsB
        '
        Me.LinkLabelSeclightsB.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelSeclightsB.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelSeclightsB.LinkColor = System.Drawing.Color.White
        Me.LinkLabelSeclightsB.Location = New System.Drawing.Point(374, 114)
        Me.LinkLabelSeclightsB.Name = "LinkLabelSeclightsB"
        Me.LinkLabelSeclightsB.Size = New System.Drawing.Size(170, 114)
        Me.LinkLabelSeclightsB.TabIndex = 143
        Me.LinkLabelSeclightsB.TabStop = True
        Me.LinkLabelSeclightsB.Text = "Sec Lights"
        Me.LinkLabelSeclightsB.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'PictureBoxSeclightsB
        '
        Me.PictureBoxSeclightsB.BackColor = System.Drawing.Color.Transparent
        Me.PictureBoxSeclightsB.BackgroundImage = CType(resources.GetObject("PictureBoxSeclightsB.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxSeclightsB.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxSeclightsB.Location = New System.Drawing.Point(379, 114)
        Me.PictureBoxSeclightsB.Name = "PictureBoxSeclightsB"
        Me.PictureBoxSeclightsB.Size = New System.Drawing.Size(68, 114)
        Me.PictureBoxSeclightsB.TabIndex = 144
        Me.PictureBoxSeclightsB.TabStop = False
        Me.PictureBoxSeclightsB.WaitOnLoad = True
        '
        'LabelTempWB
        '
        Me.LabelTempWB.AutoSize = True
        Me.LabelTempWB.Location = New System.Drawing.Point(143, 276)
        Me.LabelTempWB.Name = "LabelTempWB"
        Me.LabelTempWB.Size = New System.Drawing.Size(48, 13)
        Me.LabelTempWB.TabIndex = 149
        Me.LabelTempWB.Text = "Temp °C"
        Me.LabelTempWB.Visible = False
        '
        'NumericUpDownWB
        '
        Me.NumericUpDownWB.Increment = New Decimal(New Integer() {10, 0, 0, 0})
        Me.NumericUpDownWB.Location = New System.Drawing.Point(145, 291)
        Me.NumericUpDownWB.Maximum = New Decimal(New Integer() {90, 0, 0, 0})
        Me.NumericUpDownWB.Minimum = New Decimal(New Integer() {50, 0, 0, 0})
        Me.NumericUpDownWB.Name = "NumericUpDownWB"
        Me.NumericUpDownWB.ReadOnly = True
        Me.NumericUpDownWB.Size = New System.Drawing.Size(67, 20)
        Me.NumericUpDownWB.TabIndex = 148
        Me.NumericUpDownWB.Value = New Decimal(New Integer() {50, 0, 0, 0})
        Me.NumericUpDownWB.Visible = False
        '
        'LinkLabelWaterB
        '
        Me.LinkLabelWaterB.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelWaterB.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelWaterB.LinkColor = System.Drawing.Color.White
        Me.LinkLabelWaterB.Location = New System.Drawing.Point(20, 227)
        Me.LinkLabelWaterB.Name = "LinkLabelWaterB"
        Me.LinkLabelWaterB.Size = New System.Drawing.Size(110, 85)
        Me.LinkLabelWaterB.TabIndex = 147
        Me.LinkLabelWaterB.TabStop = True
        Me.LinkLabelWaterB.Text = "Water"
        Me.LinkLabelWaterB.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'PictureBoxWaterB
        '
        Me.PictureBoxWaterB.BackgroundImage = CType(resources.GetObject("PictureBoxWaterB.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxWaterB.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxWaterB.Location = New System.Drawing.Point(36, 249)
        Me.PictureBoxWaterB.Name = "PictureBoxWaterB"
        Me.PictureBoxWaterB.Size = New System.Drawing.Size(94, 63)
        Me.PictureBoxWaterB.TabIndex = 146
        Me.PictureBoxWaterB.TabStop = False
        Me.PictureBoxWaterB.WaitOnLoad = True
        '
        'HelpProvider1
        '
        Me.HelpProvider1.HelpNamespace = "C:\Users\Morpheus\Desktop\Dun.chm"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(53, 395)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(62, 20)
        Me.TextBox1.TabIndex = 150
        Me.TextBox1.Visible = False
        '
        'FormBath
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(584, 452)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.LabelTempWB)
        Me.Controls.Add(Me.NumericUpDownWB)
        Me.Controls.Add(Me.LinkLabelWaterB)
        Me.Controls.Add(Me.PictureBoxWaterB)
        Me.Controls.Add(Me.DomainUpDownSLB)
        Me.Controls.Add(Me.LinkLabelSeclightsB)
        Me.Controls.Add(Me.PictureBoxSeclightsB)
        Me.Controls.Add(Me.ButtonBackB)
        Me.Controls.Add(Me.DomainUpDownSSB)
        Me.Controls.Add(Me.LinkLabelFPB)
        Me.Controls.Add(Me.DomainUpDownFPB)
        Me.Controls.Add(Me.PictureBoxFPB)
        Me.Controls.Add(Me.LabelTempAB)
        Me.Controls.Add(Me.DomainUpDownMLB)
        Me.Controls.Add(Me.NumericUpDownAB)
        Me.Controls.Add(Me.LinkLabelAirB)
        Me.Controls.Add(Me.PictureBoxAirB)
        Me.Controls.Add(Me.LinkLabelSSB)
        Me.Controls.Add(Me.LinkLabelMainLightsB)
        Me.Controls.Add(Me.PictureBoxMainLightsB)
        Me.Controls.Add(Me.MenuStripFile)
        Me.Controls.Add(Me.PictureBoxSSB)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "FormBath"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Bath"
        Me.MenuStripFile.ResumeLayout(False)
        Me.MenuStripFile.PerformLayout()
        CType(Me.NumericUpDownAB, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxAirB, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxMainLightsB, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxSSB, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxFPB, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxSeclightsB, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDownWB, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxWaterB, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStripFile As System.Windows.Forms.MenuStrip
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ContactToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitControlerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DomainUpDownMLB As System.Windows.Forms.DomainUpDown
    Friend WithEvents NumericUpDownAB As System.Windows.Forms.NumericUpDown
    Friend WithEvents LinkLabelAirB As System.Windows.Forms.LinkLabel
    Friend WithEvents PictureBoxAirB As System.Windows.Forms.PictureBox
    Friend WithEvents LinkLabelSSB As System.Windows.Forms.LinkLabel
    Friend WithEvents LinkLabelMainLightsB As System.Windows.Forms.LinkLabel
    Friend WithEvents PictureBoxMainLightsB As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBoxSSB As System.Windows.Forms.PictureBox
    Friend WithEvents LabelTempAB As System.Windows.Forms.Label
    Friend WithEvents LinkLabelFPB As System.Windows.Forms.LinkLabel
    Friend WithEvents DomainUpDownFPB As System.Windows.Forms.DomainUpDown
    Friend WithEvents PictureBoxFPB As System.Windows.Forms.PictureBox
    Friend WithEvents DomainUpDownSSB As System.Windows.Forms.DomainUpDown
    Friend WithEvents ButtonBackB As System.Windows.Forms.Button
    Friend WithEvents DomainUpDownSLB As System.Windows.Forms.DomainUpDown
    Friend WithEvents LinkLabelSeclightsB As System.Windows.Forms.LinkLabel
    Friend WithEvents PictureBoxSeclightsB As System.Windows.Forms.PictureBox
    Friend WithEvents LabelTempWB As System.Windows.Forms.Label
    Friend WithEvents NumericUpDownWB As System.Windows.Forms.NumericUpDown
    Friend WithEvents LinkLabelWaterB As System.Windows.Forms.LinkLabel
    Friend WithEvents PictureBoxWaterB As System.Windows.Forms.PictureBox
    Friend WithEvents LogOutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpProvider1 As System.Windows.Forms.HelpProvider
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
End Class
