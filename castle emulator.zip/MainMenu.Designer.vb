﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormMainMenu
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormMainMenu))
        Me.ButtonContact = New System.Windows.Forms.Button()
        Me.ButtonLogOut = New System.Windows.Forms.Button()
        Me.ButtonShowCaslteMap = New System.Windows.Forms.Button()
        Me.MenuStripFile = New System.Windows.Forms.MenuStrip()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ContactToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LogOutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitControlerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Labelwel = New System.Windows.Forms.Label()
        Me.LinkLabelMMM = New System.Windows.Forms.LinkLabel()
        Me.PictureBoxMMM = New System.Windows.Forms.PictureBox()
        Me.LinkLabelMRM = New System.Windows.Forms.LinkLabel()
        Me.PictureBoxMRM = New System.Windows.Forms.PictureBox()
        Me.LinkLabelDep = New System.Windows.Forms.LinkLabel()
        Me.PictureBoxDep = New System.Windows.Forms.PictureBox()
        Me.TextBoxName = New System.Windows.Forms.TextBox()
        Me.HelpProvider1 = New System.Windows.Forms.HelpProvider()
        Me.ButtonSM = New System.Windows.Forms.Button()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.MenuStripFile.SuspendLayout()
        CType(Me.PictureBoxMMM, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxMRM, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxDep, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ButtonContact
        '
        Me.ButtonContact.Location = New System.Drawing.Point(35, 371)
        Me.ButtonContact.Name = "ButtonContact"
        Me.ButtonContact.Size = New System.Drawing.Size(110, 25)
        Me.ButtonContact.TabIndex = 8
        Me.ButtonContact.Text = "Contact"
        Me.ButtonContact.UseVisualStyleBackColor = True
        '
        'ButtonLogOut
        '
        Me.ButtonLogOut.Location = New System.Drawing.Point(443, 369)
        Me.ButtonLogOut.Name = "ButtonLogOut"
        Me.ButtonLogOut.Size = New System.Drawing.Size(110, 25)
        Me.ButtonLogOut.TabIndex = 10
        Me.ButtonLogOut.Text = "Log Out"
        Me.ButtonLogOut.UseVisualStyleBackColor = True
        '
        'ButtonShowCaslteMap
        '
        Me.ButtonShowCaslteMap.Location = New System.Drawing.Point(443, 402)
        Me.ButtonShowCaslteMap.Name = "ButtonShowCaslteMap"
        Me.ButtonShowCaslteMap.Size = New System.Drawing.Size(110, 25)
        Me.ButtonShowCaslteMap.TabIndex = 12
        Me.ButtonShowCaslteMap.Text = "Show Caslte Map"
        Me.ButtonShowCaslteMap.UseVisualStyleBackColor = True
        '
        'MenuStripFile
        '
        Me.MenuStripFile.BackColor = System.Drawing.Color.Transparent
        Me.MenuStripFile.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.MenuStripFile.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem1})
        Me.MenuStripFile.Location = New System.Drawing.Point(0, 0)
        Me.MenuStripFile.Name = "MenuStripFile"
        Me.MenuStripFile.ShowItemToolTips = True
        Me.MenuStripFile.Size = New System.Drawing.Size(584, 24)
        Me.MenuStripFile.TabIndex = 13
        Me.MenuStripFile.Text = "MenuStrip1"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ContactToolStripMenuItem, Me.HelpToolStripMenuItem, Me.AboutToolStripMenuItem, Me.LogOutToolStripMenuItem, Me.ExitControlerToolStripMenuItem})
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(37, 20)
        Me.ToolStripMenuItem1.Text = "File"
        '
        'ContactToolStripMenuItem
        '
        Me.ContactToolStripMenuItem.Name = "ContactToolStripMenuItem"
        Me.ContactToolStripMenuItem.Size = New System.Drawing.Size(145, 22)
        Me.ContactToolStripMenuItem.Text = "Contact"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(145, 22)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(145, 22)
        Me.AboutToolStripMenuItem.Text = "About"
        '
        'LogOutToolStripMenuItem
        '
        Me.LogOutToolStripMenuItem.Name = "LogOutToolStripMenuItem"
        Me.LogOutToolStripMenuItem.Size = New System.Drawing.Size(145, 22)
        Me.LogOutToolStripMenuItem.Text = "Log Out"
        '
        'ExitControlerToolStripMenuItem
        '
        Me.ExitControlerToolStripMenuItem.Name = "ExitControlerToolStripMenuItem"
        Me.ExitControlerToolStripMenuItem.Size = New System.Drawing.Size(145, 22)
        Me.ExitControlerToolStripMenuItem.Text = "Exit Controler"
        '
        'Labelwel
        '
        Me.Labelwel.AutoSize = True
        Me.Labelwel.BackColor = System.Drawing.Color.Transparent
        Me.Labelwel.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Labelwel.Location = New System.Drawing.Point(281, 34)
        Me.Labelwel.Name = "Labelwel"
        Me.Labelwel.Size = New System.Drawing.Size(0, 25)
        Me.Labelwel.TabIndex = 14
        Me.Labelwel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LinkLabelMMM
        '
        Me.LinkLabelMMM.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelMMM.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelMMM.LinkColor = System.Drawing.Color.Navy
        Me.LinkLabelMMM.Location = New System.Drawing.Point(225, 46)
        Me.LinkLabelMMM.Name = "LinkLabelMMM"
        Me.LinkLabelMMM.Size = New System.Drawing.Size(169, 200)
        Me.LinkLabelMMM.TabIndex = 146
        Me.LinkLabelMMM.TabStop = True
        Me.LinkLabelMMM.Text = "My Moat"
        Me.LinkLabelMMM.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'PictureBoxMMM
        '
        Me.PictureBoxMMM.BackgroundImage = CType(resources.GetObject("PictureBoxMMM.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxMMM.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxMMM.Location = New System.Drawing.Point(230, 70)
        Me.PictureBoxMMM.Name = "PictureBoxMMM"
        Me.PictureBoxMMM.Size = New System.Drawing.Size(155, 167)
        Me.PictureBoxMMM.TabIndex = 145
        Me.PictureBoxMMM.TabStop = False
        '
        'LinkLabelMRM
        '
        Me.LinkLabelMRM.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelMRM.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelMRM.LinkColor = System.Drawing.Color.Navy
        Me.LinkLabelMRM.Location = New System.Drawing.Point(30, 46)
        Me.LinkLabelMRM.Name = "LinkLabelMRM"
        Me.LinkLabelMRM.Size = New System.Drawing.Size(183, 210)
        Me.LinkLabelMRM.TabIndex = 144
        Me.LinkLabelMRM.TabStop = True
        Me.LinkLabelMRM.Text = "My Room"
        Me.LinkLabelMRM.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'PictureBoxMRM
        '
        Me.PictureBoxMRM.BackgroundImage = CType(resources.GetObject("PictureBoxMRM.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxMRM.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxMRM.Location = New System.Drawing.Point(35, 70)
        Me.PictureBoxMRM.Name = "PictureBoxMRM"
        Me.PictureBoxMRM.Size = New System.Drawing.Size(178, 167)
        Me.PictureBoxMRM.TabIndex = 143
        Me.PictureBoxMRM.TabStop = False
        '
        'LinkLabelDep
        '
        Me.LinkLabelDep.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelDep.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelDep.LinkColor = System.Drawing.Color.Navy
        Me.LinkLabelDep.Location = New System.Drawing.Point(400, 46)
        Me.LinkLabelDep.Name = "LinkLabelDep"
        Me.LinkLabelDep.Size = New System.Drawing.Size(172, 200)
        Me.LinkLabelDep.TabIndex = 142
        Me.LinkLabelDep.TabStop = True
        Me.LinkLabelDep.Text = "Departments"
        Me.LinkLabelDep.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'PictureBoxDep
        '
        Me.PictureBoxDep.BackgroundImage = CType(resources.GetObject("PictureBoxDep.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxDep.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxDep.Location = New System.Drawing.Point(413, 70)
        Me.PictureBoxDep.Name = "PictureBoxDep"
        Me.PictureBoxDep.Size = New System.Drawing.Size(140, 167)
        Me.PictureBoxDep.TabIndex = 141
        Me.PictureBoxDep.TabStop = False
        '
        'TextBoxName
        '
        Me.TextBoxName.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TextBoxName.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBoxName.Location = New System.Drawing.Point(425, 10)
        Me.TextBoxName.Name = "TextBoxName"
        Me.TextBoxName.ReadOnly = True
        Me.TextBoxName.Size = New System.Drawing.Size(117, 13)
        Me.TextBoxName.TabIndex = 148
        Me.TextBoxName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'ButtonSM
        '
        Me.ButtonSM.Location = New System.Drawing.Point(35, 402)
        Me.ButtonSM.Name = "ButtonSM"
        Me.ButtonSM.Size = New System.Drawing.Size(110, 25)
        Me.ButtonSM.TabIndex = 149
        Me.ButtonSM.Text = "Sleep Mode"
        Me.ButtonSM.UseVisualStyleBackColor = True
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(35, 243)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(62, 20)
        Me.TextBox1.TabIndex = 151
        Me.TextBox1.Visible = False
        '
        'FormMainMenu
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoValidate = System.Windows.Forms.AutoValidate.Disable
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(584, 452)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.ButtonSM)
        Me.Controls.Add(Me.TextBoxName)
        Me.Controls.Add(Me.LinkLabelMMM)
        Me.Controls.Add(Me.PictureBoxMMM)
        Me.Controls.Add(Me.LinkLabelMRM)
        Me.Controls.Add(Me.PictureBoxMRM)
        Me.Controls.Add(Me.LinkLabelDep)
        Me.Controls.Add(Me.PictureBoxDep)
        Me.Controls.Add(Me.Labelwel)
        Me.Controls.Add(Me.MenuStripFile)
        Me.Controls.Add(Me.ButtonShowCaslteMap)
        Me.Controls.Add(Me.ButtonLogOut)
        Me.Controls.Add(Me.ButtonContact)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "FormMainMenu"
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Main Menu"
        Me.MenuStripFile.ResumeLayout(False)
        Me.MenuStripFile.PerformLayout()
        CType(Me.PictureBoxMMM, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxMRM, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxDep, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ButtonContact As System.Windows.Forms.Button
    Friend WithEvents ButtonLogOut As System.Windows.Forms.Button
    Friend WithEvents ButtonShowCaslteMap As System.Windows.Forms.Button
    Friend WithEvents MenuStripFile As System.Windows.Forms.MenuStrip
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ContactToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitControlerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Labelwel As System.Windows.Forms.Label
    Friend WithEvents LinkLabelMMM As System.Windows.Forms.LinkLabel
    Friend WithEvents PictureBoxMMM As System.Windows.Forms.PictureBox
    Friend WithEvents LinkLabelMRM As System.Windows.Forms.LinkLabel
    Friend WithEvents PictureBoxMRM As System.Windows.Forms.PictureBox
    Friend WithEvents LinkLabelDep As System.Windows.Forms.LinkLabel
    Friend WithEvents PictureBoxDep As System.Windows.Forms.PictureBox
    Friend WithEvents TextBoxName As System.Windows.Forms.TextBox
    Friend WithEvents LogOutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpProvider1 As System.Windows.Forms.HelpProvider
    Friend WithEvents ButtonSM As System.Windows.Forms.Button
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
End Class
