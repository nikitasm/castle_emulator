﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormMyRoom
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormMyRoom))
        Me.ButtonBack = New System.Windows.Forms.Button()
        Me.MenuStripFile = New System.Windows.Forms.MenuStrip()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ContactToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LogOutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitControlerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PictureBoxSR = New System.Windows.Forms.PictureBox()
        Me.LinkLabelSR = New System.Windows.Forms.LinkLabel()
        Me.LinkLabelKR = New System.Windows.Forms.LinkLabel()
        Me.PictureBoxKR = New System.Windows.Forms.PictureBox()
        Me.LinkLabelSBR = New System.Windows.Forms.LinkLabel()
        Me.PictureBoxSBR = New System.Windows.Forms.PictureBox()
        Me.LinkLabelMBR = New System.Windows.Forms.LinkLabel()
        Me.PictureBoxMBR = New System.Windows.Forms.PictureBox()
        Me.LinkLabelBR = New System.Windows.Forms.LinkLabel()
        Me.PictureBoxBR = New System.Windows.Forms.PictureBox()
        Me.LinkLabelMoat = New System.Windows.Forms.LinkLabel()
        Me.PictureBoxMoat = New System.Windows.Forms.PictureBox()
        Me.ButtonBackMSt = New System.Windows.Forms.Button()
        Me.HelpProvider1 = New System.Windows.Forms.HelpProvider()
        Me.MenuStripFile.SuspendLayout()
        CType(Me.PictureBoxSR, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxKR, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxSBR, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxMBR, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxBR, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxMoat, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ButtonBack
        '
        Me.ButtonBack.Location = New System.Drawing.Point(450, 395)
        Me.ButtonBack.Name = "ButtonBack"
        Me.ButtonBack.Size = New System.Drawing.Size(110, 25)
        Me.ButtonBack.TabIndex = 5
        Me.ButtonBack.Text = "Back"
        Me.ButtonBack.UseVisualStyleBackColor = True
        '
        'MenuStripFile
        '
        Me.MenuStripFile.BackColor = System.Drawing.Color.Transparent
        Me.MenuStripFile.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.MenuStripFile.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem1})
        Me.MenuStripFile.Location = New System.Drawing.Point(0, 0)
        Me.MenuStripFile.Name = "MenuStripFile"
        Me.MenuStripFile.ShowItemToolTips = True
        Me.MenuStripFile.Size = New System.Drawing.Size(584, 24)
        Me.MenuStripFile.TabIndex = 6
        Me.MenuStripFile.Text = "MenuStrip1"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ContactToolStripMenuItem, Me.HelpToolStripMenuItem, Me.AboutToolStripMenuItem, Me.LogOutToolStripMenuItem, Me.ExitControlerToolStripMenuItem})
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(37, 20)
        Me.ToolStripMenuItem1.Text = "File"
        '
        'ContactToolStripMenuItem
        '
        Me.ContactToolStripMenuItem.Name = "ContactToolStripMenuItem"
        Me.ContactToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.ContactToolStripMenuItem.Text = "Contact"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.AboutToolStripMenuItem.Text = "About"
        '
        'LogOutToolStripMenuItem
        '
        Me.LogOutToolStripMenuItem.Name = "LogOutToolStripMenuItem"
        Me.LogOutToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.LogOutToolStripMenuItem.Text = "Log Out"
        '
        'ExitControlerToolStripMenuItem
        '
        Me.ExitControlerToolStripMenuItem.Name = "ExitControlerToolStripMenuItem"
        Me.ExitControlerToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.ExitControlerToolStripMenuItem.Text = "Exit Controler"
        '
        'PictureBoxSR
        '
        Me.PictureBoxSR.BackgroundImage = CType(resources.GetObject("PictureBoxSR.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxSR.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxSR.Location = New System.Drawing.Point(283, 90)
        Me.PictureBoxSR.Name = "PictureBoxSR"
        Me.PictureBoxSR.Size = New System.Drawing.Size(231, 176)
        Me.PictureBoxSR.TabIndex = 7
        Me.PictureBoxSR.TabStop = False
        '
        'LinkLabelSR
        '
        Me.LinkLabelSR.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelSR.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelSR.LinkColor = System.Drawing.Color.White
        Me.LinkLabelSR.Location = New System.Drawing.Point(278, 70)
        Me.LinkLabelSR.Name = "LinkLabelSR"
        Me.LinkLabelSR.Size = New System.Drawing.Size(236, 199)
        Me.LinkLabelSR.TabIndex = 132
        Me.LinkLabelSR.TabStop = True
        Me.LinkLabelSR.Text = "Sitting Room"
        Me.LinkLabelSR.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'LinkLabelKR
        '
        Me.LinkLabelKR.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelKR.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelKR.LinkColor = System.Drawing.Color.White
        Me.LinkLabelKR.Location = New System.Drawing.Point(278, 269)
        Me.LinkLabelKR.Name = "LinkLabelKR"
        Me.LinkLabelKR.Size = New System.Drawing.Size(172, 132)
        Me.LinkLabelKR.TabIndex = 134
        Me.LinkLabelKR.TabStop = True
        Me.LinkLabelKR.Text = "Kitchen"
        Me.LinkLabelKR.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'PictureBoxKR
        '
        Me.PictureBoxKR.BackgroundImage = CType(resources.GetObject("PictureBoxKR.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxKR.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxKR.Location = New System.Drawing.Point(281, 305)
        Me.PictureBoxKR.Name = "PictureBoxKR"
        Me.PictureBoxKR.Size = New System.Drawing.Size(167, 96)
        Me.PictureBoxKR.TabIndex = 133
        Me.PictureBoxKR.TabStop = False
        '
        'LinkLabelSBR
        '
        Me.LinkLabelSBR.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelSBR.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelSBR.LinkColor = System.Drawing.Color.White
        Me.LinkLabelSBR.Location = New System.Drawing.Point(155, 189)
        Me.LinkLabelSBR.Name = "LinkLabelSBR"
        Me.LinkLabelSBR.Size = New System.Drawing.Size(115, 169)
        Me.LinkLabelSBR.TabIndex = 136
        Me.LinkLabelSBR.TabStop = True
        Me.LinkLabelSBR.Text = "Sec Bedroom"
        Me.LinkLabelSBR.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'PictureBoxSBR
        '
        Me.PictureBoxSBR.BackgroundImage = CType(resources.GetObject("PictureBoxSBR.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxSBR.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxSBR.Location = New System.Drawing.Point(155, 247)
        Me.PictureBoxSBR.Name = "PictureBoxSBR"
        Me.PictureBoxSBR.Size = New System.Drawing.Size(115, 111)
        Me.PictureBoxSBR.TabIndex = 135
        Me.PictureBoxSBR.TabStop = False
        '
        'LinkLabelMBR
        '
        Me.LinkLabelMBR.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelMBR.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelMBR.LinkColor = System.Drawing.Color.White
        Me.LinkLabelMBR.Location = New System.Drawing.Point(23, 67)
        Me.LinkLabelMBR.Name = "LinkLabelMBR"
        Me.LinkLabelMBR.Size = New System.Drawing.Size(126, 198)
        Me.LinkLabelMBR.TabIndex = 138
        Me.LinkLabelMBR.TabStop = True
        Me.LinkLabelMBR.Text = "Main Bedroom"
        Me.LinkLabelMBR.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'PictureBoxMBR
        '
        Me.PictureBoxMBR.BackgroundImage = CType(resources.GetObject("PictureBoxMBR.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxMBR.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxMBR.Location = New System.Drawing.Point(26, 117)
        Me.PictureBoxMBR.Name = "PictureBoxMBR"
        Me.PictureBoxMBR.Size = New System.Drawing.Size(123, 141)
        Me.PictureBoxMBR.TabIndex = 137
        Me.PictureBoxMBR.TabStop = False
        '
        'LinkLabelBR
        '
        Me.LinkLabelBR.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelBR.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelBR.LinkColor = System.Drawing.Color.White
        Me.LinkLabelBR.Location = New System.Drawing.Point(167, 44)
        Me.LinkLabelBR.Name = "LinkLabelBR"
        Me.LinkLabelBR.Size = New System.Drawing.Size(103, 123)
        Me.LinkLabelBR.TabIndex = 140
        Me.LinkLabelBR.TabStop = True
        Me.LinkLabelBR.Text = "Bath"
        Me.LinkLabelBR.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'PictureBoxBR
        '
        Me.PictureBoxBR.BackgroundImage = CType(resources.GetObject("PictureBoxBR.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxBR.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxBR.Location = New System.Drawing.Point(169, 67)
        Me.PictureBoxBR.Name = "PictureBoxBR"
        Me.PictureBoxBR.Size = New System.Drawing.Size(101, 100)
        Me.PictureBoxBR.TabIndex = 139
        Me.PictureBoxBR.TabStop = False
        '
        'LinkLabelMoat
        '
        Me.LinkLabelMoat.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelMoat.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelMoat.LinkColor = System.Drawing.Color.White
        Me.LinkLabelMoat.Location = New System.Drawing.Point(23, 305)
        Me.LinkLabelMoat.Name = "LinkLabelMoat"
        Me.LinkLabelMoat.Size = New System.Drawing.Size(131, 123)
        Me.LinkLabelMoat.TabIndex = 142
        Me.LinkLabelMoat.TabStop = True
        Me.LinkLabelMoat.Text = "Moat"
        Me.LinkLabelMoat.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'PictureBoxMoat
        '
        Me.PictureBoxMoat.BackgroundImage = CType(resources.GetObject("PictureBoxMoat.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxMoat.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxMoat.Location = New System.Drawing.Point(26, 337)
        Me.PictureBoxMoat.Name = "PictureBoxMoat"
        Me.PictureBoxMoat.Size = New System.Drawing.Size(128, 91)
        Me.PictureBoxMoat.TabIndex = 141
        Me.PictureBoxMoat.TabStop = False
        '
        'ButtonBackMSt
        '
        Me.ButtonBackMSt.Enabled = False
        Me.ButtonBackMSt.Location = New System.Drawing.Point(450, 395)
        Me.ButtonBackMSt.Name = "ButtonBackMSt"
        Me.ButtonBackMSt.Size = New System.Drawing.Size(110, 25)
        Me.ButtonBackMSt.TabIndex = 143
        Me.ButtonBackMSt.Text = "Back"
        Me.ButtonBackMSt.UseVisualStyleBackColor = True
        Me.ButtonBackMSt.Visible = False
        '
        'HelpProvider1
        '
        Me.HelpProvider1.HelpNamespace = "C:\Users\Morpheus\Desktop\Dun.chm"
        '
        'FormMyRoom
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(584, 452)
        Me.Controls.Add(Me.LinkLabelMoat)
        Me.Controls.Add(Me.PictureBoxMoat)
        Me.Controls.Add(Me.LinkLabelBR)
        Me.Controls.Add(Me.PictureBoxBR)
        Me.Controls.Add(Me.LinkLabelMBR)
        Me.Controls.Add(Me.PictureBoxMBR)
        Me.Controls.Add(Me.LinkLabelSBR)
        Me.Controls.Add(Me.PictureBoxSBR)
        Me.Controls.Add(Me.LinkLabelKR)
        Me.Controls.Add(Me.PictureBoxKR)
        Me.Controls.Add(Me.LinkLabelSR)
        Me.Controls.Add(Me.MenuStripFile)
        Me.Controls.Add(Me.ButtonBack)
        Me.Controls.Add(Me.PictureBoxSR)
        Me.Controls.Add(Me.ButtonBackMSt)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "FormMyRoom"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "My Room"
        Me.MenuStripFile.ResumeLayout(False)
        Me.MenuStripFile.PerformLayout()
        CType(Me.PictureBoxSR, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxKR, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxSBR, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxMBR, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxBR, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxMoat, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ButtonBack As System.Windows.Forms.Button
    Friend WithEvents MenuStripFile As System.Windows.Forms.MenuStrip
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ContactToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitControlerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PictureBoxSR As System.Windows.Forms.PictureBox
    Friend WithEvents LinkLabelSR As System.Windows.Forms.LinkLabel
    Friend WithEvents LinkLabelKR As System.Windows.Forms.LinkLabel
    Friend WithEvents PictureBoxKR As System.Windows.Forms.PictureBox
    Friend WithEvents LinkLabelSBR As System.Windows.Forms.LinkLabel
    Friend WithEvents PictureBoxSBR As System.Windows.Forms.PictureBox
    Friend WithEvents LinkLabelMBR As System.Windows.Forms.LinkLabel
    Friend WithEvents PictureBoxMBR As System.Windows.Forms.PictureBox
    Friend WithEvents LinkLabelBR As System.Windows.Forms.LinkLabel
    Friend WithEvents PictureBoxBR As System.Windows.Forms.PictureBox
    Friend WithEvents LinkLabelMoat As System.Windows.Forms.LinkLabel
    Friend WithEvents PictureBoxMoat As System.Windows.Forms.PictureBox
    Friend WithEvents ButtonBackMSt As System.Windows.Forms.Button
    Friend WithEvents LogOutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpProvider1 As System.Windows.Forms.HelpProvider
End Class
