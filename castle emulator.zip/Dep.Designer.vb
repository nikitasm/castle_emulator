﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormDep
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormDep))
        Me.HelpProvider1 = New System.Windows.Forms.HelpProvider()
        Me.LogOutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LinkLabelDepES = New System.Windows.Forms.LinkLabel()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ContactToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitControlerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStripFile = New System.Windows.Forms.MenuStrip()
        Me.LinkLabelDepCB = New System.Windows.Forms.LinkLabel()
        Me.PictureBoxDepRest = New System.Windows.Forms.PictureBox()
        Me.PictureBoxDepCB = New System.Windows.Forms.PictureBox()
        Me.Labelwel = New System.Windows.Forms.Label()
        Me.ButtonBackDep = New System.Windows.Forms.Button()
        Me.LinkLabelDepRest = New System.Windows.Forms.LinkLabel()
        Me.PictureBoxDepES = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.MenuStripFile.SuspendLayout()
        CType(Me.PictureBoxDepRest, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxDepCB, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxDepES, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'HelpProvider1
        '
        Me.HelpProvider1.HelpNamespace = "C:\Users\Morpheus\Desktop\Dun.chm"
        '
        'LogOutToolStripMenuItem
        '
        Me.LogOutToolStripMenuItem.Name = "LogOutToolStripMenuItem"
        Me.LogOutToolStripMenuItem.Size = New System.Drawing.Size(145, 22)
        Me.LogOutToolStripMenuItem.Text = "Log Out"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(145, 22)
        Me.AboutToolStripMenuItem.Text = "About"
        '
        'LinkLabelDepES
        '
        Me.LinkLabelDepES.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelDepES.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelDepES.LinkColor = System.Drawing.Color.Navy
        Me.LinkLabelDepES.Location = New System.Drawing.Point(203, 20)
        Me.LinkLabelDepES.Name = "LinkLabelDepES"
        Me.LinkLabelDepES.Size = New System.Drawing.Size(234, 82)
        Me.LinkLabelDepES.TabIndex = 164
        Me.LinkLabelDepES.TabStop = True
        Me.LinkLabelDepES.Text = "e-Shop"
        Me.LinkLabelDepES.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(145, 22)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'ContactToolStripMenuItem
        '
        Me.ContactToolStripMenuItem.Name = "ContactToolStripMenuItem"
        Me.ContactToolStripMenuItem.Size = New System.Drawing.Size(145, 22)
        Me.ContactToolStripMenuItem.Text = "Contact"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ContactToolStripMenuItem, Me.HelpToolStripMenuItem, Me.AboutToolStripMenuItem, Me.LogOutToolStripMenuItem, Me.ExitControlerToolStripMenuItem})
        Me.ToolStripMenuItem1.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(37, 20)
        Me.ToolStripMenuItem1.Text = "File"
        '
        'ExitControlerToolStripMenuItem
        '
        Me.ExitControlerToolStripMenuItem.Name = "ExitControlerToolStripMenuItem"
        Me.ExitControlerToolStripMenuItem.Size = New System.Drawing.Size(145, 22)
        Me.ExitControlerToolStripMenuItem.Text = "Exit Controler"
        '
        'MenuStripFile
        '
        Me.MenuStripFile.BackColor = System.Drawing.Color.Transparent
        Me.MenuStripFile.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem1})
        Me.MenuStripFile.Location = New System.Drawing.Point(0, 0)
        Me.MenuStripFile.Name = "MenuStripFile"
        Me.MenuStripFile.ShowItemToolTips = True
        Me.MenuStripFile.Size = New System.Drawing.Size(584, 24)
        Me.MenuStripFile.TabIndex = 169
        Me.MenuStripFile.Text = "MenuStrip1"
        '
        'LinkLabelDepCB
        '
        Me.LinkLabelDepCB.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelDepCB.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelDepCB.LinkColor = System.Drawing.Color.Navy
        Me.LinkLabelDepCB.Location = New System.Drawing.Point(136, 168)
        Me.LinkLabelDepCB.Name = "LinkLabelDepCB"
        Me.LinkLabelDepCB.Size = New System.Drawing.Size(189, 210)
        Me.LinkLabelDepCB.TabIndex = 166
        Me.LinkLabelDepCB.TabStop = True
        Me.LinkLabelDepCB.Text = "Coffee - Bar"
        Me.LinkLabelDepCB.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'PictureBoxDepRest
        '
        Me.PictureBoxDepRest.BackgroundImage = CType(resources.GetObject("PictureBoxDepRest.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxDepRest.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxDepRest.Location = New System.Drawing.Point(412, 152)
        Me.PictureBoxDepRest.Name = "PictureBoxDepRest"
        Me.PictureBoxDepRest.Size = New System.Drawing.Size(167, 167)
        Me.PictureBoxDepRest.TabIndex = 167
        Me.PictureBoxDepRest.TabStop = False
        Me.PictureBoxDepRest.WaitOnLoad = True
        '
        'PictureBoxDepCB
        '
        Me.PictureBoxDepCB.BackgroundImage = CType(resources.GetObject("PictureBoxDepCB.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxDepCB.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxDepCB.Location = New System.Drawing.Point(138, 209)
        Me.PictureBoxDepCB.Name = "PictureBoxDepCB"
        Me.PictureBoxDepCB.Size = New System.Drawing.Size(178, 167)
        Me.PictureBoxDepCB.TabIndex = 165
        Me.PictureBoxDepCB.TabStop = False
        Me.PictureBoxDepCB.WaitOnLoad = True
        '
        'Labelwel
        '
        Me.Labelwel.AutoSize = True
        Me.Labelwel.BackColor = System.Drawing.Color.Transparent
        Me.Labelwel.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Labelwel.Location = New System.Drawing.Point(259, 84)
        Me.Labelwel.Name = "Labelwel"
        Me.Labelwel.Size = New System.Drawing.Size(0, 25)
        Me.Labelwel.TabIndex = 163
        Me.Labelwel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ButtonBackDep
        '
        Me.ButtonBackDep.Location = New System.Drawing.Point(484, 419)
        Me.ButtonBackDep.Name = "ButtonBackDep"
        Me.ButtonBackDep.Size = New System.Drawing.Size(88, 21)
        Me.ButtonBackDep.TabIndex = 162
        Me.ButtonBackDep.Text = "Back"
        Me.ButtonBackDep.UseVisualStyleBackColor = True
        '
        'LinkLabelDepRest
        '
        Me.LinkLabelDepRest.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelDepRest.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelDepRest.LinkColor = System.Drawing.Color.Navy
        Me.LinkLabelDepRest.Location = New System.Drawing.Point(390, 123)
        Me.LinkLabelDepRest.Name = "LinkLabelDepRest"
        Me.LinkLabelDepRest.Size = New System.Drawing.Size(197, 198)
        Me.LinkLabelDepRest.TabIndex = 168
        Me.LinkLabelDepRest.TabStop = True
        Me.LinkLabelDepRest.Text = "Restaurant"
        Me.LinkLabelDepRest.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'PictureBoxDepES
        '
        Me.PictureBoxDepES.BackgroundImage = CType(resources.GetObject("PictureBoxDepES.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxDepES.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxDepES.Location = New System.Drawing.Point(208, 23)
        Me.PictureBoxDepES.Name = "PictureBoxDepES"
        Me.PictureBoxDepES.Size = New System.Drawing.Size(229, 79)
        Me.PictureBoxDepES.TabIndex = 170
        Me.PictureBoxDepES.TabStop = False
        Me.PictureBoxDepES.WaitOnLoad = True
        '
        'PictureBox2
        '
        Me.PictureBox2.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox2.BackgroundImage = CType(resources.GetObject("PictureBox2.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox2.Location = New System.Drawing.Point(275, 222)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(22, 44)
        Me.PictureBox2.TabIndex = 181
        Me.PictureBox2.TabStop = False
        Me.PictureBox2.Visible = False
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox1.BackgroundImage = CType(resources.GetObject("PictureBox1.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox1.Location = New System.Drawing.Point(388, 209)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(31, 57)
        Me.PictureBox1.TabIndex = 182
        Me.PictureBox1.TabStop = False
        Me.PictureBox1.Visible = False
        '
        'PictureBox3
        '
        Me.PictureBox3.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox3.BackgroundImage = CType(resources.GetObject("PictureBox3.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox3.Location = New System.Drawing.Point(178, 232)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(15, 35)
        Me.PictureBox3.TabIndex = 183
        Me.PictureBox3.TabStop = False
        Me.PictureBox3.Visible = False
        '
        'PictureBox4
        '
        Me.PictureBox4.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox4.BackgroundImage = CType(resources.GetObject("PictureBox4.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox4.Location = New System.Drawing.Point(12, 272)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(52, 106)
        Me.PictureBox4.TabIndex = 184
        Me.PictureBox4.TabStop = False
        Me.PictureBox4.Visible = False
        '
        'PictureBox5
        '
        Me.PictureBox5.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox5.BackgroundImage = CType(resources.GetObject("PictureBox5.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox5.Location = New System.Drawing.Point(438, 286)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(69, 116)
        Me.PictureBox5.TabIndex = 185
        Me.PictureBox5.TabStop = False
        Me.PictureBox5.Visible = False
        '
        'FormDep
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(584, 452)
        Me.Controls.Add(Me.PictureBox5)
        Me.Controls.Add(Me.PictureBox4)
        Me.Controls.Add(Me.PictureBox3)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.LinkLabelDepES)
        Me.Controls.Add(Me.MenuStripFile)
        Me.Controls.Add(Me.LinkLabelDepCB)
        Me.Controls.Add(Me.PictureBoxDepCB)
        Me.Controls.Add(Me.Labelwel)
        Me.Controls.Add(Me.ButtonBackDep)
        Me.Controls.Add(Me.LinkLabelDepRest)
        Me.Controls.Add(Me.PictureBoxDepRest)
        Me.Controls.Add(Me.PictureBoxDepES)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "FormDep"
        Me.Text = "Departments"
        Me.MenuStripFile.ResumeLayout(False)
        Me.MenuStripFile.PerformLayout()
        CType(Me.PictureBoxDepRest, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxDepCB, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxDepES, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents HelpProvider1 As System.Windows.Forms.HelpProvider
    Friend WithEvents LogOutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LinkLabelDepES As System.Windows.Forms.LinkLabel
    Friend WithEvents HelpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ContactToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitControlerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MenuStripFile As System.Windows.Forms.MenuStrip
    Friend WithEvents LinkLabelDepCB As System.Windows.Forms.LinkLabel
    Friend WithEvents PictureBoxDepRest As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBoxDepCB As System.Windows.Forms.PictureBox
    Friend WithEvents Labelwel As System.Windows.Forms.Label
    Friend WithEvents ButtonBackDep As System.Windows.Forms.Button
    Friend WithEvents LinkLabelDepRest As System.Windows.Forms.LinkLabel
    Friend WithEvents PictureBoxDepES As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox3 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox4 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox5 As System.Windows.Forms.PictureBox
End Class
