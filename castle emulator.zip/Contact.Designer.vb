﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormContact
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormContact))
        Me.ButtonSubmit = New System.Windows.Forms.Button()
        Me.ButtonBackC = New System.Windows.Forms.Button()
        Me.RichTextBoxMessage = New System.Windows.Forms.RichTextBox()
        Me.LabelEnterMessage = New System.Windows.Forms.Label()
        Me.LabelMessage = New System.Windows.Forms.Label()
        Me.PictureBoxStuffK = New System.Windows.Forms.PictureBox()
        Me.PictureBoxStufP = New System.Windows.Forms.PictureBox()
        Me.LinkLabelHello = New System.Windows.Forms.LinkLabel()
        Me.ButtonClear = New System.Windows.Forms.Button()
        Me.MenuStripFile = New System.Windows.Forms.MenuStrip()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ContactToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LogOutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitControlerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TextBoxS = New System.Windows.Forms.TextBox()
        Me.LabelMale = New System.Windows.Forms.Label()
        Me.LabelFemale = New System.Windows.Forms.Label()
        Me.ButtonBackC2 = New System.Windows.Forms.Button()
        Me.HelpProvider1 = New System.Windows.Forms.HelpProvider()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        CType(Me.PictureBoxStuffK, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxStufP, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStripFile.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ButtonSubmit
        '
        Me.ButtonSubmit.Location = New System.Drawing.Point(446, 353)
        Me.ButtonSubmit.Name = "ButtonSubmit"
        Me.ButtonSubmit.Size = New System.Drawing.Size(110, 25)
        Me.ButtonSubmit.TabIndex = 3
        Me.ButtonSubmit.Text = "Submit"
        Me.ButtonSubmit.UseVisualStyleBackColor = True
        '
        'ButtonBackC
        '
        Me.ButtonBackC.Location = New System.Drawing.Point(446, 402)
        Me.ButtonBackC.Name = "ButtonBackC"
        Me.ButtonBackC.Size = New System.Drawing.Size(110, 25)
        Me.ButtonBackC.TabIndex = 143
        Me.ButtonBackC.Text = "Back"
        Me.ButtonBackC.UseVisualStyleBackColor = True
        '
        'RichTextBoxMessage
        '
        Me.RichTextBoxMessage.Location = New System.Drawing.Point(17, 294)
        Me.RichTextBoxMessage.Name = "RichTextBoxMessage"
        Me.RichTextBoxMessage.Size = New System.Drawing.Size(539, 40)
        Me.RichTextBoxMessage.TabIndex = 145
        Me.RichTextBoxMessage.Text = ""
        '
        'LabelEnterMessage
        '
        Me.LabelEnterMessage.AutoSize = True
        Me.LabelEnterMessage.BackColor = System.Drawing.Color.Transparent
        Me.LabelEnterMessage.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LabelEnterMessage.ForeColor = System.Drawing.Color.Black
        Me.LabelEnterMessage.Location = New System.Drawing.Point(163, 51)
        Me.LabelEnterMessage.Name = "LabelEnterMessage"
        Me.LabelEnterMessage.Size = New System.Drawing.Size(256, 29)
        Me.LabelEnterMessage.TabIndex = 146
        Me.LabelEnterMessage.Text = "Write Your Message!"
        '
        'LabelMessage
        '
        Me.LabelMessage.AutoSize = True
        Me.LabelMessage.BackColor = System.Drawing.Color.Transparent
        Me.LabelMessage.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LabelMessage.Location = New System.Drawing.Point(234, 343)
        Me.LabelMessage.Name = "LabelMessage"
        Me.LabelMessage.Size = New System.Drawing.Size(117, 24)
        Me.LabelMessage.TabIndex = 147
        Me.LabelMessage.Text = "Thank You!"
        '
        'PictureBoxStuffK
        '
        Me.PictureBoxStuffK.BackColor = System.Drawing.Color.Transparent
        Me.PictureBoxStuffK.BackgroundImage = CType(resources.GetObject("PictureBoxStuffK.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxStuffK.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxStuffK.Location = New System.Drawing.Point(215, 108)
        Me.PictureBoxStuffK.Name = "PictureBoxStuffK"
        Me.PictureBoxStuffK.Size = New System.Drawing.Size(149, 147)
        Me.PictureBoxStuffK.TabIndex = 148
        Me.PictureBoxStuffK.TabStop = False
        '
        'PictureBoxStufP
        '
        Me.PictureBoxStufP.BackColor = System.Drawing.Color.Transparent
        Me.PictureBoxStufP.BackgroundImage = CType(resources.GetObject("PictureBoxStufP.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxStufP.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxStufP.Location = New System.Drawing.Point(215, 108)
        Me.PictureBoxStufP.Name = "PictureBoxStufP"
        Me.PictureBoxStufP.Size = New System.Drawing.Size(149, 147)
        Me.PictureBoxStufP.TabIndex = 149
        Me.PictureBoxStufP.TabStop = False
        '
        'LinkLabelHello
        '
        Me.LinkLabelHello.BackColor = System.Drawing.Color.Transparent
        Me.LinkLabelHello.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.LinkLabelHello.LinkColor = System.Drawing.Color.Yellow
        Me.LinkLabelHello.Location = New System.Drawing.Point(215, 29)
        Me.LinkLabelHello.Name = "LinkLabelHello"
        Me.LinkLabelHello.Size = New System.Drawing.Size(149, 234)
        Me.LinkLabelHello.TabIndex = 150
        Me.LinkLabelHello.TabStop = True
        Me.LinkLabelHello.Text = "Hello!!!"
        Me.LinkLabelHello.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'ButtonClear
        '
        Me.ButtonClear.Location = New System.Drawing.Point(17, 353)
        Me.ButtonClear.Name = "ButtonClear"
        Me.ButtonClear.Size = New System.Drawing.Size(110, 25)
        Me.ButtonClear.TabIndex = 154
        Me.ButtonClear.Text = "Clear"
        Me.ButtonClear.UseVisualStyleBackColor = True
        '
        'MenuStripFile
        '
        Me.MenuStripFile.BackColor = System.Drawing.Color.Transparent
        Me.MenuStripFile.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.MenuStripFile.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem1})
        Me.MenuStripFile.Location = New System.Drawing.Point(0, 0)
        Me.MenuStripFile.Name = "MenuStripFile"
        Me.MenuStripFile.ShowItemToolTips = True
        Me.MenuStripFile.Size = New System.Drawing.Size(584, 24)
        Me.MenuStripFile.TabIndex = 155
        Me.MenuStripFile.Text = "MenuStrip1"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ContactToolStripMenuItem, Me.HelpToolStripMenuItem, Me.AboutToolStripMenuItem, Me.LogOutToolStripMenuItem, Me.ExitControlerToolStripMenuItem})
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(37, 20)
        Me.ToolStripMenuItem1.Text = "File"
        '
        'ContactToolStripMenuItem
        '
        Me.ContactToolStripMenuItem.Enabled = False
        Me.ContactToolStripMenuItem.Name = "ContactToolStripMenuItem"
        Me.ContactToolStripMenuItem.Size = New System.Drawing.Size(161, 22)
        Me.ContactToolStripMenuItem.Text = "$safeitemname$"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(161, 22)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(161, 22)
        Me.AboutToolStripMenuItem.Text = "About"
        '
        'LogOutToolStripMenuItem
        '
        Me.LogOutToolStripMenuItem.Name = "LogOutToolStripMenuItem"
        Me.LogOutToolStripMenuItem.Size = New System.Drawing.Size(161, 22)
        Me.LogOutToolStripMenuItem.Text = "Log Out"
        '
        'ExitControlerToolStripMenuItem
        '
        Me.ExitControlerToolStripMenuItem.Name = "ExitControlerToolStripMenuItem"
        Me.ExitControlerToolStripMenuItem.Size = New System.Drawing.Size(161, 22)
        Me.ExitControlerToolStripMenuItem.Text = "Exit Controler"
        '
        'TextBoxS
        '
        Me.TextBoxS.Location = New System.Drawing.Point(477, 175)
        Me.TextBoxS.Name = "TextBoxS"
        Me.TextBoxS.Size = New System.Drawing.Size(79, 20)
        Me.TextBoxS.TabIndex = 156
        Me.TextBoxS.Visible = False
        '
        'LabelMale
        '
        Me.LabelMale.AutoSize = True
        Me.LabelMale.Location = New System.Drawing.Point(480, 95)
        Me.LabelMale.Name = "LabelMale"
        Me.LabelMale.Size = New System.Drawing.Size(29, 13)
        Me.LabelMale.TabIndex = 157
        Me.LabelMale.Text = "male"
        Me.LabelMale.Visible = False
        '
        'LabelFemale
        '
        Me.LabelFemale.AutoSize = True
        Me.LabelFemale.Location = New System.Drawing.Point(480, 131)
        Me.LabelFemale.Name = "LabelFemale"
        Me.LabelFemale.Size = New System.Drawing.Size(38, 13)
        Me.LabelFemale.TabIndex = 158
        Me.LabelFemale.Text = "female"
        Me.LabelFemale.Visible = False
        '
        'ButtonBackC2
        '
        Me.ButtonBackC2.Enabled = False
        Me.ButtonBackC2.Location = New System.Drawing.Point(446, 402)
        Me.ButtonBackC2.Name = "ButtonBackC2"
        Me.ButtonBackC2.Size = New System.Drawing.Size(110, 25)
        Me.ButtonBackC2.TabIndex = 160
        Me.ButtonBackC2.Text = "Back"
        Me.ButtonBackC2.UseVisualStyleBackColor = True
        '
        'HelpProvider1
        '
        Me.HelpProvider1.HelpNamespace = "C:\Users\Morpheus\Desktop\Dun.chm"
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox1.BackgroundImage = CType(resources.GetObject("PictureBox1.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox1.Location = New System.Drawing.Point(365, 83)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(54, 100)
        Me.PictureBox1.TabIndex = 180
        Me.PictureBox1.TabStop = False
        Me.PictureBox1.Visible = False
        '
        'PictureBox2
        '
        Me.PictureBox2.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox2.BackgroundImage = CType(resources.GetObject("PictureBox2.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox2.Location = New System.Drawing.Point(155, 83)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(54, 100)
        Me.PictureBox2.TabIndex = 181
        Me.PictureBox2.TabStop = False
        Me.PictureBox2.Visible = False
        '
        'FormContact
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(584, 452)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.LabelFemale)
        Me.Controls.Add(Me.LabelMale)
        Me.Controls.Add(Me.TextBoxS)
        Me.Controls.Add(Me.MenuStripFile)
        Me.Controls.Add(Me.LabelEnterMessage)
        Me.Controls.Add(Me.ButtonClear)
        Me.Controls.Add(Me.LinkLabelHello)
        Me.Controls.Add(Me.LabelMessage)
        Me.Controls.Add(Me.RichTextBoxMessage)
        Me.Controls.Add(Me.ButtonBackC)
        Me.Controls.Add(Me.ButtonSubmit)
        Me.Controls.Add(Me.PictureBoxStufP)
        Me.Controls.Add(Me.PictureBoxStuffK)
        Me.Controls.Add(Me.ButtonBackC2)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "FormContact"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Reception"
        CType(Me.PictureBoxStuffK, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxStufP, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStripFile.ResumeLayout(False)
        Me.MenuStripFile.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ButtonSubmit As System.Windows.Forms.Button
    Friend WithEvents ButtonBackC As System.Windows.Forms.Button
    Friend WithEvents RichTextBoxMessage As System.Windows.Forms.RichTextBox
    Friend WithEvents LabelEnterMessage As System.Windows.Forms.Label
    Friend WithEvents LabelMessage As System.Windows.Forms.Label
    Friend WithEvents PictureBoxStuffK As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBoxStufP As System.Windows.Forms.PictureBox
    Friend WithEvents LinkLabelHello As System.Windows.Forms.LinkLabel
    Friend WithEvents ButtonClear As System.Windows.Forms.Button
    Friend WithEvents MenuStripFile As System.Windows.Forms.MenuStrip
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ContactToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitControlerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TextBoxS As System.Windows.Forms.TextBox
    Friend WithEvents LabelMale As System.Windows.Forms.Label
    Friend WithEvents LabelFemale As System.Windows.Forms.Label
    Friend WithEvents ButtonBackC2 As System.Windows.Forms.Button
    Friend WithEvents LogOutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpProvider1 As System.Windows.Forms.HelpProvider
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
End Class
