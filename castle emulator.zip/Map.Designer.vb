﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormMap
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormMap))
        Me.ButtonBack = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label1M = New System.Windows.Forms.Label()
        Me.Label2M = New System.Windows.Forms.Label()
        Me.Label3M = New System.Windows.Forms.Label()
        Me.Label4M = New System.Windows.Forms.Label()
        Me.Label5M = New System.Windows.Forms.Label()
        Me.Label6M = New System.Windows.Forms.Label()
        Me.Label7M = New System.Windows.Forms.Label()
        Me.Label8M = New System.Windows.Forms.Label()
        Me.Label9M = New System.Windows.Forms.Label()
        Me.Label10M = New System.Windows.Forms.Label()
        Me.MenuStripFile = New System.Windows.Forms.MenuStrip()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ContactToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LogOutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitControlerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpProvider1 = New System.Windows.Forms.HelpProvider()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.ButtonBackS = New System.Windows.Forms.Button()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStripFile.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ButtonBack
        '
        Me.ButtonBack.Location = New System.Drawing.Point(462, 415)
        Me.ButtonBack.Name = "ButtonBack"
        Me.ButtonBack.Size = New System.Drawing.Size(110, 25)
        Me.ButtonBack.TabIndex = 6
        Me.ButtonBack.Text = "Back"
        Me.ButtonBack.UseVisualStyleBackColor = True
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.ImageLocation = ""
        Me.PictureBox1.Location = New System.Drawing.Point(3, 22)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(579, 427)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 7
        Me.PictureBox1.TabStop = False
        '
        'Label1M
        '
        Me.Label1M.AutoSize = True
        Me.Label1M.BackColor = System.Drawing.Color.Transparent
        Me.Label1M.Location = New System.Drawing.Point(28, 136)
        Me.Label1M.Name = "Label1M"
        Me.Label1M.Size = New System.Drawing.Size(88, 13)
        Me.Label1M.TabIndex = 8
        Me.Label1M.Text = "Rooms 100 - 499"
        '
        'Label2M
        '
        Me.Label2M.AutoSize = True
        Me.Label2M.BackColor = System.Drawing.Color.Transparent
        Me.Label2M.Location = New System.Drawing.Point(133, 78)
        Me.Label2M.Name = "Label2M"
        Me.Label2M.Size = New System.Drawing.Size(88, 13)
        Me.Label2M.TabIndex = 9
        Me.Label2M.Text = "Rooms 500 - 999"
        '
        'Label3M
        '
        Me.Label3M.AutoSize = True
        Me.Label3M.BackColor = System.Drawing.Color.Transparent
        Me.Label3M.Location = New System.Drawing.Point(306, 58)
        Me.Label3M.Name = "Label3M"
        Me.Label3M.Size = New System.Drawing.Size(100, 13)
        Me.Label3M.TabIndex = 10
        Me.Label3M.Text = "Rooms 1000 - 1499"
        '
        'Label4M
        '
        Me.Label4M.AutoSize = True
        Me.Label4M.BackColor = System.Drawing.Color.Transparent
        Me.Label4M.Location = New System.Drawing.Point(430, 90)
        Me.Label4M.Name = "Label4M"
        Me.Label4M.Size = New System.Drawing.Size(100, 13)
        Me.Label4M.TabIndex = 11
        Me.Label4M.Text = "Rooms 1500 - 2000"
        '
        'Label5M
        '
        Me.Label5M.AutoSize = True
        Me.Label5M.BackColor = System.Drawing.Color.Transparent
        Me.Label5M.Location = New System.Drawing.Point(265, 157)
        Me.Label5M.Name = "Label5M"
        Me.Label5M.Size = New System.Drawing.Size(56, 13)
        Me.Label5M.TabIndex = 12
        Me.Label5M.Text = "Reception"
        '
        'Label6M
        '
        Me.Label6M.AutoSize = True
        Me.Label6M.BackColor = System.Drawing.Color.Transparent
        Me.Label6M.Location = New System.Drawing.Point(459, 184)
        Me.Label6M.Name = "Label6M"
        Me.Label6M.Size = New System.Drawing.Size(28, 13)
        Me.Label6M.TabIndex = 13
        Me.Label6M.Text = "Gym"
        '
        'Label7M
        '
        Me.Label7M.AutoSize = True
        Me.Label7M.BackColor = System.Drawing.Color.Transparent
        Me.Label7M.Location = New System.Drawing.Point(200, 211)
        Me.Label7M.Name = "Label7M"
        Me.Label7M.Size = New System.Drawing.Size(59, 13)
        Me.Label7M.TabIndex = 14
        Me.Label7M.Text = "Restaurant"
        '
        'Label8M
        '
        Me.Label8M.AutoSize = True
        Me.Label8M.BackColor = System.Drawing.Color.Transparent
        Me.Label8M.Location = New System.Drawing.Point(147, 240)
        Me.Label8M.Name = "Label8M"
        Me.Label8M.Size = New System.Drawing.Size(48, 13)
        Me.Label8M.TabIndex = 15
        Me.Label8M.Text = "Cafe Bar"
        '
        'Label9M
        '
        Me.Label9M.AutoSize = True
        Me.Label9M.BackColor = System.Drawing.Color.Transparent
        Me.Label9M.Location = New System.Drawing.Point(174, 136)
        Me.Label9M.Name = "Label9M"
        Me.Label9M.Size = New System.Drawing.Size(66, 13)
        Me.Label9M.TabIndex = 16
        Me.Label9M.Text = "MAIN GATE"
        '
        'Label10M
        '
        Me.Label10M.AutoSize = True
        Me.Label10M.BackColor = System.Drawing.Color.Transparent
        Me.Label10M.Location = New System.Drawing.Point(340, 259)
        Me.Label10M.Name = "Label10M"
        Me.Label10M.Size = New System.Drawing.Size(67, 13)
        Me.Label10M.TabIndex = 17
        Me.Label10M.Text = "Departments"
        '
        'MenuStripFile
        '
        Me.MenuStripFile.BackColor = System.Drawing.Color.Transparent
        Me.MenuStripFile.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.MenuStripFile.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem1})
        Me.MenuStripFile.Location = New System.Drawing.Point(0, 0)
        Me.MenuStripFile.Name = "MenuStripFile"
        Me.MenuStripFile.ShowItemToolTips = True
        Me.MenuStripFile.Size = New System.Drawing.Size(584, 24)
        Me.MenuStripFile.TabIndex = 18
        Me.MenuStripFile.Text = "MenuStrip1"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ContactToolStripMenuItem, Me.HelpToolStripMenuItem, Me.AboutToolStripMenuItem, Me.LogOutToolStripMenuItem, Me.ExitControlerToolStripMenuItem})
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(37, 20)
        Me.ToolStripMenuItem1.Text = "File"
        '
        'ContactToolStripMenuItem
        '
        Me.ContactToolStripMenuItem.Name = "ContactToolStripMenuItem"
        Me.ContactToolStripMenuItem.Size = New System.Drawing.Size(145, 22)
        Me.ContactToolStripMenuItem.Text = "Contact"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(145, 22)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(145, 22)
        Me.AboutToolStripMenuItem.Text = "About"
        '
        'LogOutToolStripMenuItem
        '
        Me.LogOutToolStripMenuItem.Name = "LogOutToolStripMenuItem"
        Me.LogOutToolStripMenuItem.Size = New System.Drawing.Size(145, 22)
        Me.LogOutToolStripMenuItem.Text = "Log Out"
        '
        'ExitControlerToolStripMenuItem
        '
        Me.ExitControlerToolStripMenuItem.Name = "ExitControlerToolStripMenuItem"
        Me.ExitControlerToolStripMenuItem.Size = New System.Drawing.Size(145, 22)
        Me.ExitControlerToolStripMenuItem.Text = "Exit Controler"
        '
        'HelpProvider1
        '
        Me.HelpProvider1.HelpNamespace = "C:\Users\Morpheus\Desktop\Dun.chm"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(54, 379)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(62, 20)
        Me.TextBox1.TabIndex = 152
        Me.TextBox1.Visible = False
        '
        'ButtonBackS
        '
        Me.ButtonBackS.Location = New System.Drawing.Point(462, 415)
        Me.ButtonBackS.Name = "ButtonBackS"
        Me.ButtonBackS.Size = New System.Drawing.Size(110, 25)
        Me.ButtonBackS.TabIndex = 153
        Me.ButtonBackS.Text = "Back"
        Me.ButtonBackS.UseVisualStyleBackColor = True
        '
        'PictureBox2
        '
        Me.PictureBox2.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox2.BackgroundImage = CType(resources.GetObject("PictureBox2.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox2.Location = New System.Drawing.Point(110, 87)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(22, 44)
        Me.PictureBox2.TabIndex = 180
        Me.PictureBox2.TabStop = False
        Me.PictureBox2.Visible = False
        '
        'PictureBox3
        '
        Me.PictureBox3.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox3.BackgroundImage = CType(resources.GetObject("PictureBox3.BackgroundImage"), System.Drawing.Image)
        Me.PictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox3.Location = New System.Drawing.Point(175, 56)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(22, 44)
        Me.PictureBox3.TabIndex = 181
        Me.PictureBox3.TabStop = False
        Me.PictureBox3.Visible = False
        '
        'FormMap
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(584, 452)
        Me.Controls.Add(Me.Label2M)
        Me.Controls.Add(Me.PictureBox3)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.ButtonBackS)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.MenuStripFile)
        Me.Controls.Add(Me.Label10M)
        Me.Controls.Add(Me.Label9M)
        Me.Controls.Add(Me.Label8M)
        Me.Controls.Add(Me.Label7M)
        Me.Controls.Add(Me.Label6M)
        Me.Controls.Add(Me.Label5M)
        Me.Controls.Add(Me.Label4M)
        Me.Controls.Add(Me.Label3M)
        Me.Controls.Add(Me.Label1M)
        Me.Controls.Add(Me.ButtonBack)
        Me.Controls.Add(Me.PictureBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "FormMap"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Castle Map "
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStripFile.ResumeLayout(False)
        Me.MenuStripFile.PerformLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ButtonBack As System.Windows.Forms.Button
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Label1M As System.Windows.Forms.Label
    Friend WithEvents Label2M As System.Windows.Forms.Label
    Friend WithEvents Label3M As System.Windows.Forms.Label
    Friend WithEvents Label4M As System.Windows.Forms.Label
    Friend WithEvents Label5M As System.Windows.Forms.Label
    Friend WithEvents Label6M As System.Windows.Forms.Label
    Friend WithEvents Label7M As System.Windows.Forms.Label
    Friend WithEvents Label8M As System.Windows.Forms.Label
    Friend WithEvents Label9M As System.Windows.Forms.Label
    Friend WithEvents Label10M As System.Windows.Forms.Label
    Friend WithEvents MenuStripFile As System.Windows.Forms.MenuStrip
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ContactToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitControlerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LogOutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpProvider1 As System.Windows.Forms.HelpProvider
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents ButtonBackS As System.Windows.Forms.Button
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox3 As System.Windows.Forms.PictureBox
End Class
