﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("Castle Emulator")> 
<Assembly: AssemblyDescription("An interaction app between users and a virtual castle town.                                                            From:                                                       Giodampalis Evaggelos                                               Mahmudis Nikitas                                       Zaharis Sotiris                       Contact:                                                    aggelos_gate7@yahoo.gr                         nikitasmhs@gmail.com                        sotiris.7@hotmail.com")> 
<Assembly: AssemblyCompany("A.G.MA.N")> 
<Assembly: AssemblyProduct("Emulator Solution")> 
<Assembly: AssemblyCopyright("Copyright ©  2014")> 
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(False)> 

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("8bfebb33-6acc-4bff-9c01-9cec02b3e356")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("1.0.0.14")> 
<Assembly: AssemblyFileVersion("1.0.0.14")> 
