﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormDungeonControl
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FormDungeonControl))
        Me.ButtonLogIn = New System.Windows.Forms.Button()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.MenuStripFile = New System.Windows.Forms.MenuStrip()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ContactToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LogOutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitControlerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CheckBoxCon = New System.Windows.Forms.CheckBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.LabelStaff = New System.Windows.Forms.Label()
        Me.LabelCustomer = New System.Windows.Forms.Label()
        Me.TextBoxT = New System.Windows.Forms.TextBox()
        Me.PictureBoxOG = New System.Windows.Forms.PictureBox()
        Me.PictureBoxCG = New System.Windows.Forms.PictureBox()
        Me.TimerSp = New System.Windows.Forms.Timer(Me.components)
        Me.HelpProvider1 = New System.Windows.Forms.HelpProvider()
        Me.MenuStripFile.SuspendLayout()
        CType(Me.PictureBoxOG, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxCG, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ButtonLogIn
        '
        Me.ButtonLogIn.AccessibleName = "log"
        Me.ButtonLogIn.Location = New System.Drawing.Point(497, 402)
        Me.ButtonLogIn.Name = "ButtonLogIn"
        Me.ButtonLogIn.Size = New System.Drawing.Size(61, 27)
        Me.ButtonLogIn.TabIndex = 1
        Me.ButtonLogIn.Text = "Log In"
        Me.ButtonLogIn.UseVisualStyleBackColor = True
        '
        'TextBox1
        '
        Me.TextBox1.ForeColor = System.Drawing.SystemColors.ActiveBorder
        Me.TextBox1.Location = New System.Drawing.Point(240, 237)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(168, 20)
        Me.TextBox1.TabIndex = 3
        Me.TextBox1.Text = "username"
        Me.TextBox1.Visible = False
        '
        'TextBox2
        '
        Me.TextBox2.ForeColor = System.Drawing.SystemColors.ActiveBorder
        Me.TextBox2.Location = New System.Drawing.Point(240, 276)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(167, 20)
        Me.TextBox2.TabIndex = 4
        Me.TextBox2.Text = "password"
        Me.TextBox2.Visible = False
        '
        'MenuStripFile
        '
        Me.MenuStripFile.BackColor = System.Drawing.Color.Transparent
        Me.MenuStripFile.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem1})
        Me.MenuStripFile.Location = New System.Drawing.Point(0, 0)
        Me.MenuStripFile.Name = "MenuStripFile"
        Me.MenuStripFile.ShowItemToolTips = True
        Me.MenuStripFile.Size = New System.Drawing.Size(584, 24)
        Me.MenuStripFile.TabIndex = 5
        Me.MenuStripFile.Text = "MenuStrip1"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ContactToolStripMenuItem, Me.HelpToolStripMenuItem, Me.AboutToolStripMenuItem, Me.LogOutToolStripMenuItem, Me.ExitControlerToolStripMenuItem})
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(37, 20)
        Me.ToolStripMenuItem1.Text = "File"
        '
        'ContactToolStripMenuItem
        '
        Me.ContactToolStripMenuItem.Name = "ContactToolStripMenuItem"
        Me.ContactToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.ContactToolStripMenuItem.Text = "Contact"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.AboutToolStripMenuItem.Text = "About"
        '
        'LogOutToolStripMenuItem
        '
        Me.LogOutToolStripMenuItem.Enabled = False
        Me.LogOutToolStripMenuItem.Name = "LogOutToolStripMenuItem"
        Me.LogOutToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.LogOutToolStripMenuItem.Text = "Log Out"
        '
        'ExitControlerToolStripMenuItem
        '
        Me.ExitControlerToolStripMenuItem.Name = "ExitControlerToolStripMenuItem"
        Me.ExitControlerToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.ExitControlerToolStripMenuItem.Text = "Exit Controler"
        '
        'CheckBoxCon
        '
        Me.CheckBoxCon.AutoSize = True
        Me.CheckBoxCon.Location = New System.Drawing.Point(240, 312)
        Me.CheckBoxCon.Name = "CheckBoxCon"
        Me.CheckBoxCon.Size = New System.Drawing.Size(112, 17)
        Me.CheckBoxCon.TabIndex = 6
        Me.CheckBoxCon.Text = "Connect to Server"
        Me.CheckBoxCon.UseVisualStyleBackColor = True
        Me.CheckBoxCon.Visible = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(161, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Black
        Me.Label1.Location = New System.Drawing.Point(104, 36)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(392, 26)
        Me.Label1.TabIndex = 7
        Me.Label1.Text = "WELCOME TO DUNGEON CONTROL"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'LabelStaff
        '
        Me.LabelStaff.AutoSize = True
        Me.LabelStaff.Location = New System.Drawing.Point(494, 271)
        Me.LabelStaff.Name = "LabelStaff"
        Me.LabelStaff.Size = New System.Drawing.Size(27, 13)
        Me.LabelStaff.TabIndex = 158
        Me.LabelStaff.Text = "staff"
        Me.LabelStaff.Visible = False
        '
        'LabelCustomer
        '
        Me.LabelCustomer.AutoSize = True
        Me.LabelCustomer.Location = New System.Drawing.Point(494, 296)
        Me.LabelCustomer.Name = "LabelCustomer"
        Me.LabelCustomer.Size = New System.Drawing.Size(50, 13)
        Me.LabelCustomer.TabIndex = 159
        Me.LabelCustomer.Text = "customer"
        Me.LabelCustomer.Visible = False
        '
        'TextBoxT
        '
        Me.TextBoxT.Location = New System.Drawing.Point(493, 326)
        Me.TextBoxT.Name = "TextBoxT"
        Me.TextBoxT.Size = New System.Drawing.Size(79, 20)
        Me.TextBoxT.TabIndex = 160
        Me.TextBoxT.Visible = False
        '
        'PictureBoxOG
        '
        Me.PictureBoxOG.BackColor = System.Drawing.Color.Transparent
        Me.PictureBoxOG.BackgroundImage = CType(resources.GetObject("PictureBoxOG.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxOG.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxOG.Location = New System.Drawing.Point(0, 0)
        Me.PictureBoxOG.Name = "PictureBoxOG"
        Me.PictureBoxOG.Size = New System.Drawing.Size(584, 451)
        Me.PictureBoxOG.TabIndex = 161
        Me.PictureBoxOG.TabStop = False
        '
        'PictureBoxCG
        '
        Me.PictureBoxCG.BackgroundImage = CType(resources.GetObject("PictureBoxCG.BackgroundImage"), System.Drawing.Image)
        Me.PictureBoxCG.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBoxCG.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBoxCG.Location = New System.Drawing.Point(0, 0)
        Me.PictureBoxCG.Name = "PictureBoxCG"
        Me.PictureBoxCG.Size = New System.Drawing.Size(584, 451)
        Me.PictureBoxCG.TabIndex = 162
        Me.PictureBoxCG.TabStop = False
        '
        'TimerSp
        '
        Me.TimerSp.Enabled = True
        Me.TimerSp.Interval = 1000
        '
        'HelpProvider1
        '
        Me.HelpProvider1.HelpNamespace = "C:\Users\Morpheus\Desktop\Dun.chm"
        '
        'FormDungeonControl
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(584, 452)
        Me.Controls.Add(Me.MenuStripFile)
        Me.Controls.Add(Me.ButtonLogIn)
        Me.Controls.Add(Me.PictureBoxCG)
        Me.Controls.Add(Me.CheckBoxCon)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.TextBoxT)
        Me.Controls.Add(Me.LabelCustomer)
        Me.Controls.Add(Me.LabelStaff)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.PictureBoxOG)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.HelpButton = True
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "FormDungeonControl"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Dungeon Control"
        Me.MenuStripFile.ResumeLayout(False)
        Me.MenuStripFile.PerformLayout()
        CType(Me.PictureBoxOG, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxCG, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ButtonLogIn As System.Windows.Forms.Button
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents MenuStripFile As System.Windows.Forms.MenuStrip
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ContactToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitControlerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CheckBoxCon As System.Windows.Forms.CheckBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents LabelStaff As System.Windows.Forms.Label
    Friend WithEvents LabelCustomer As System.Windows.Forms.Label
    Friend WithEvents TextBoxT As System.Windows.Forms.TextBox
    Friend WithEvents PictureBoxOG As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBoxCG As System.Windows.Forms.PictureBox
    Friend WithEvents TimerSp As System.Windows.Forms.Timer
    Friend WithEvents LogOutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpProvider1 As System.Windows.Forms.HelpProvider

End Class
